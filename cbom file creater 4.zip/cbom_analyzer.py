#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CBOM Comparison and Analysis Tool
=================================

Desktop utility that parses CycloneDX Cryptography Bills of Materials (CBOM)
produced by:

    1. SCANOSS crypto-finder  (external tool)
    2. Internal CBOM Generator (in-house tool)

and emits one Excel workbook per supplied input:

    SCANOSS_Output.xlsx    ->  Crypto Assets | Occurrences | Asset Name - Properties
    Internal_Output.xlsx   ->  Crypto Assets | Occurrences | Asset Name - Properties

Either input may be omitted; the tool processes whatever is supplied.

Build a single-file Windows executable with:
    pyinstaller --onefile --windowed --name CBOM_Analyzer cbom_analyzer.py

Author: generated for EY SAM / OSS compliance tooling
"""

from __future__ import annotations

import json
import os
import queue
import re
import sys
import threading
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Third-party (bundled into the .exe by PyInstaller)
# ---------------------------------------------------------------------------
try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.worksheet import Worksheet
except ImportError:  # pragma: no cover - surfaced to the user at startup
    Workbook = None  # type: ignore


APP_NAME = "CBOM Comparison & Analysis"
APP_VERSION = "1.0.0"

SHEET_ASSETS = "Crypto Assets"
SHEET_OCCURRENCES = "Occurrences"
SHEET_PROPERTIES = "Asset Name - Properties"  # ':' and '/' are illegal in sheet names

LIBRARY_TYPE = "library"


# ===========================================================================
# 1.  TOLERANT JSON LOADING
# ===========================================================================

_JSON_LITERAL_RE = re.compile(
    r"^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)$"
)
_OBJECT_MEMBER_RE = re.compile(r'^(\s*"(?:[^"\\]|\\.)*"\s*:\s*)(\S.*?)(,?)\s*$')
_ARRAY_ELEMENT_RE = re.compile(r'^(\s*)([^\s"\'{}\[\],:][^,]*?)(,?)\s*$')


class CBOMParseError(Exception):
    """Raised when a CBOM file cannot be read even after repair."""


def repair_json_text(text: str) -> Tuple[str, List[str]]:
    """
    Repair the malformed-JSON patterns commonly seen in hand-edited or
    template-generated CBOM files.

    Currently handles:
      * unquoted scalar values, e.g.  "bom-ref": crypto/algorithm/eddsa@1.3.101.112
      * unquoted array elements
      * UTF-8 BOM, trailing commas, // and /* */ comments

    Returns (repaired_text, list_of_human_readable_fix_descriptions).
    """
    fixes: List[str] = []

    if text.startswith("\ufeff"):
        text = text.lstrip("\ufeff")
        fixes.append("Stripped UTF-8 byte-order mark")

    # -- strip comments (not legal JSON, but tools sometimes emit them) ------
    without_comments, n_comments = re.subn(
        r"/\*.*?\*/", "", text, flags=re.DOTALL
    )
    if n_comments:
        text = without_comments
        fixes.append(f"Removed {n_comments} block comment(s)")

    lines = text.splitlines()
    out_lines: List[str] = []

    for idx, line in enumerate(lines, start=1):
        # line comments, only when the line is entirely a comment
        if line.lstrip().startswith("//"):
            fixes.append(f"Line {idx}: removed line comment")
            continue

        repaired = _repair_line(line)
        if repaired is not None:
            fixes.append(
                f"Line {idx}: quoted unquoted value -> {repaired.strip()[:90]}"
            )
            out_lines.append(repaired)
        else:
            out_lines.append(line)

    text = "\n".join(out_lines)

    # -- trailing commas before a closing brace/bracket ----------------------
    text, n_trailing = re.subn(r",(\s*[}\]])", r"\1", text)
    if n_trailing:
        fixes.append(f"Removed {n_trailing} trailing comma(s)")

    return text, fixes


def _repair_line(line: str) -> Optional[str]:
    """Return a repaired copy of *line*, or None if no repair was needed."""
    match = _OBJECT_MEMBER_RE.match(line)
    if match:
        prefix, value, comma = match.groups()
        fixed = _quote_if_bare(value)
        if fixed is not None:
            return f"{prefix}{fixed}{comma}"
        return None

    match = _ARRAY_ELEMENT_RE.match(line)
    if match:
        indent, value, comma = match.groups()
        fixed = _quote_if_bare(value)
        if fixed is not None:
            return f"{indent}{fixed}{comma}"
    return None


def _quote_if_bare(value: str) -> Optional[str]:
    """Wrap *value* in quotes if it is a bare (unquoted) scalar."""
    value = value.strip()
    if not value:
        return None
    if value[0] in '"{}[]':
        return None
    if _JSON_LITERAL_RE.match(value):
        return None
    return json.dumps(value)


def load_cbom(path: str) -> Tuple[Dict[str, Any], List[str]]:
    """
    Load a CBOM JSON document, repairing common malformations if necessary.

    Returns (document, notes). *notes* describes any repairs performed so the
    caller can surface them to the user - silent repair would hide real
    defects in the generating tool.
    """
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            raw = handle.read()
    except OSError as exc:
        raise CBOMParseError(f"Cannot read file:\n{path}\n\n{exc}") from exc

    if not raw.strip():
        raise CBOMParseError(f"File is empty:\n{path}")

    try:
        return json.loads(raw), []
    except json.JSONDecodeError as first_error:
        repaired, fixes = repair_json_text(raw)
        try:
            document = json.loads(repaired)
        except json.JSONDecodeError as second_error:
            raise CBOMParseError(
                f"'{os.path.basename(path)}' is not valid JSON and could not be "
                f"auto-repaired.\n\n"
                f"Original error : line {first_error.lineno}, "
                f"column {first_error.colno} - {first_error.msg}\n"
                f"After repair   : line {second_error.lineno}, "
                f"column {second_error.colno} - {second_error.msg}"
            ) from second_error

        notes = [
            f"'{os.path.basename(path)}' contained invalid JSON and was "
            f"auto-repaired ({len(fixes)} fix(es)):"
        ]
        notes.extend(f"    - {fix}" for fix in fixes[:25])
        if len(fixes) > 25:
            notes.append(f"    - ...and {len(fixes) - 25} more")
        return document, notes


# ===========================================================================
# 2.  SAFE ACCESSORS
# ===========================================================================


def dig(source: Any, *keys: str, default: Any = None) -> Any:
    """Walk nested dicts safely: dig(comp, 'cryptoProperties', 'oid')."""
    current = source
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    return current if current is not None else default


def as_text(value: Any, separator: str = ", ") -> str:
    """Flatten a CycloneDX value into something a spreadsheet cell can hold."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        return separator.join(as_text(item, separator) for item in value if item is not None)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def coerce_cell(value: Any, separator: str = ", ") -> Any:
    """
    Convert a CycloneDX value into something openpyxl can write with the
    correct Excel type: numbers stay numeric, booleans stay boolean, strings
    stay text, lists become comma-joined text, dicts become JSON, None
    becomes an empty string.

    Use this whenever a cell might hold a number (e.g. classicalSecurityLevel,
    nistQuantumSecurityLevel, key size, timestamps as epoch). Using `as_text`
    for these fields is what causes Excel's "number stored as text" warning.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        parts = [
            str(coerce_cell(item, separator))
            for item in value
            if item is not None and item != ""
        ]
        return separator.join(parts)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def component_list(document: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return the top-level components array, flattening nested components."""
    collected: List[Dict[str, Any]] = []

    def walk(items: Any) -> None:
        if not isinstance(items, list):
            return
        for item in items:
            if isinstance(item, dict):
                collected.append(item)
                walk(item.get("components"))

    walk(document.get("components"))
    return collected


# ===========================================================================
# 3.  EXTRACTION MODEL
# ===========================================================================


@dataclass
class SheetData:
    """A single output sheet: ordered headers plus row dictionaries."""

    name: str
    headers: List[str]
    rows: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ExtractionResult:
    label: str                       # "SCANOSS" / "Internal"
    output_filename: str
    sheets: List[SheetData]
    removed_libraries: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def total_rows(self) -> int:
        return sum(len(sheet.rows) for sheet in self.sheets)


# --------------------------------------------------------------------------
# 3a.  SCANOSS
# --------------------------------------------------------------------------

SCANOSS_ASSET_HEADERS = [
    "bom-ref",
    "type",
    "name",
    "description",
    "assetType",
    "primitive",
    "parameterSetIdentifier",
    "executionEnvironment",
    "implementationPlatform",
    "cryptoFunctions",
    "oid",
    "relatedCryptoMaterialType",
    "scanossCryptoFunction",
    "Occurrence Count",
    "Identity Evidence Count",
]

SCANOSS_OCCURRENCE_HEADERS = [
    "Asset Name",
    "bom-ref",
    "Location",
    "Line",
    "Additional Context",
]

SCANOSS_IDENTITY_HEADERS = [
    "Asset Name",
    "bom-ref",
    "Field",
    "Identity Confidence",
    "Technique",
    "Method Confidence",
    "Method Value",
]


def extract_scanoss(document: Dict[str, Any]) -> ExtractionResult:
    """Build the three SCANOSS sheets from a parsed CycloneDX document."""
    assets = SheetData(SHEET_ASSETS, list(SCANOSS_ASSET_HEADERS))
    occurrences = SheetData(SHEET_OCCURRENCES, list(SCANOSS_OCCURRENCE_HEADERS))
    identity = SheetData(SHEET_PROPERTIES, list(SCANOSS_IDENTITY_HEADERS))

    removed_refs: set = set()
    removed_names: set = set()
    removed_labels: List[str] = []

    for component in component_list(document):
        comp_type = coerce_cell(component.get("type")).strip()
        bom_ref = coerce_cell(component.get("bom-ref"))
        name = coerce_cell(component.get("name"))

        # ---- filtering rule: drop libraries entirely ----------------------
        if comp_type.lower() == LIBRARY_TYPE:
            if bom_ref:
                removed_refs.add(bom_ref)
            if name:
                removed_names.add(name)
            removed_labels.append(f"{name or '(unnamed)'} [{bom_ref or 'no bom-ref'}]")
            continue

        crypto = component.get("cryptoProperties") or {}
        algorithm = crypto.get("algorithmProperties") or {}
        evidence = component.get("evidence") or {}
        occurrence_items = evidence.get("occurrences") or []
        identity_items = evidence.get("identity") or []

        scanoss_functions = [
            coerce_cell(prop.get("value"))
            for prop in (component.get("properties") or [])
            if isinstance(prop, dict)
            and coerce_cell(prop.get("name")).lower() == "scanoss:cryptofunction"
        ]

        assets.rows.append(
            {
                "bom-ref": bom_ref,
                "type": comp_type,
                "name": name,
                "description": coerce_cell(component.get("description")),
                "assetType": coerce_cell(crypto.get("assetType")),
                "primitive": coerce_cell(algorithm.get("primitive")),
                "parameterSetIdentifier": coerce_cell(algorithm.get("parameterSetIdentifier")),
                "executionEnvironment": coerce_cell(algorithm.get("executionEnvironment")),
                "implementationPlatform": coerce_cell(algorithm.get("implementationPlatform")),
                "cryptoFunctions": coerce_cell(algorithm.get("cryptoFunctions")),
                "oid": coerce_cell(crypto.get("oid")),
                "relatedCryptoMaterialType": coerce_cell(
                    dig(crypto, "relatedCryptoMaterialProperties", "type")
                ),
                "scanossCryptoFunction": coerce_cell(scanoss_functions),
                "Occurrence Count": len(occurrence_items),
                "Identity Evidence Count": len(identity_items),
            }
        )

        for occurrence in occurrence_items:
            if not isinstance(occurrence, dict):
                continue
            occurrences.rows.append(
                {
                    "Asset Name": name,
                    "bom-ref": bom_ref,
                    "Location": coerce_cell(occurrence.get("location")),
                    "Line": occurrence.get("line", ""),
                    "Additional Context": coerce_cell(occurrence.get("additionalContext")),
                }
            )

        for entry in identity_items:
            if not isinstance(entry, dict):
                continue
            methods = entry.get("methods") or []
            if not methods:
                identity.rows.append(
                    {
                        "Asset Name": name,
                        "bom-ref": bom_ref,
                        "Field": coerce_cell(entry.get("field")),
                        "Identity Confidence": entry.get("confidence", ""),
                        "Technique": "",
                        "Method Confidence": "",
                        "Method Value": "",
                    }
                )
                continue
            for method in methods:
                if not isinstance(method, dict):
                    continue
                identity.rows.append(
                    {
                        "Asset Name": name,
                        "bom-ref": bom_ref,
                        "Field": coerce_cell(entry.get("field")),
                        "Identity Confidence": entry.get("confidence", ""),
                        "Technique": coerce_cell(method.get("technique")),
                        "Method Confidence": method.get("confidence", ""),
                        "Method Value": coerce_cell(method.get("value")),
                    }
                )

    _drop_orphans(occurrences, "Asset Name", removed_refs, removed_names)
    _drop_orphans(identity, "Asset Name", removed_refs, removed_names)

    return ExtractionResult(
        label="SCANOSS",
        output_filename="SCANOSS_Output.xlsx",
        sheets=[assets, occurrences, identity],
        removed_libraries=removed_labels,
    )


# --------------------------------------------------------------------------
# 3b.  INTERNAL TOOL
# --------------------------------------------------------------------------

INTERNAL_ASSET_HEADERS = [
    "bom-ref",
    "Type",
    "Group",
    "Name",
    "Version",
    "Description",
    "PURL",
    "Crypto Asset Type",
    "Primitive",
    "Parameter Set",
    "Execution Environment",
    "Implementation Platform",
    "Crypto Functions",
    "OID",
    "Related Material Type",
    "Protocol Type",
    "Certificate Subject",
    "Occurrence Count",
    "Property Count",
]

INTERNAL_OCCURRENCE_HEADERS = [
    "Component",
    "bom-ref",
    "Location",
    "Line",
    "Offset",
    "Additional Context",
]

INTERNAL_PROPERTY_HEADERS = [
    "Component",
    "bom-ref",
    "Property Name",
    "Property Value",
]


def extract_internal(document: Dict[str, Any]) -> ExtractionResult:
    """Build the three Internal-tool sheets from a parsed CycloneDX document."""
    assets = SheetData(SHEET_ASSETS, list(INTERNAL_ASSET_HEADERS))
    occurrences = SheetData(SHEET_OCCURRENCES, list(INTERNAL_OCCURRENCE_HEADERS))
    properties = SheetData(SHEET_PROPERTIES, list(INTERNAL_PROPERTY_HEADERS))

    removed_refs: set = set()
    removed_names: set = set()
    removed_labels: List[str] = []

    for component in component_list(document):
        comp_type = coerce_cell(component.get("type")).strip()
        bom_ref = coerce_cell(component.get("bom-ref"))
        name = coerce_cell(component.get("name"))

        if comp_type.lower() == LIBRARY_TYPE:
            if bom_ref:
                removed_refs.add(bom_ref)
            if name:
                removed_names.add(name)
            removed_labels.append(f"{name or '(unnamed)'} [{bom_ref or 'no bom-ref'}]")
            continue

        crypto = component.get("cryptoProperties") or {}
        algorithm = crypto.get("algorithmProperties") or {}
        evidence = component.get("evidence") or {}
        occurrence_items = evidence.get("occurrences") or []
        property_items = [
            prop for prop in (component.get("properties") or []) if isinstance(prop, dict)
        ]

        assets.rows.append(
            {
                "bom-ref": bom_ref,
                "Type": comp_type,
                "Group": coerce_cell(component.get("group")),
                "Name": name,
                "Version": coerce_cell(component.get("version")),
                "Description": coerce_cell(component.get("description")),
                "PURL": coerce_cell(component.get("purl")),
                "Crypto Asset Type": coerce_cell(crypto.get("assetType")),
                "Primitive": coerce_cell(algorithm.get("primitive")),
                "Parameter Set": coerce_cell(algorithm.get("parameterSetIdentifier")),
                "Execution Environment": coerce_cell(algorithm.get("executionEnvironment")),
                "Implementation Platform": coerce_cell(algorithm.get("implementationPlatform")),
                "Crypto Functions": coerce_cell(algorithm.get("cryptoFunctions")),
                "OID": coerce_cell(crypto.get("oid")),
                "Related Material Type": coerce_cell(
                    dig(crypto, "relatedCryptoMaterialProperties", "type")
                ),
                "Protocol Type": coerce_cell(dig(crypto, "protocolProperties", "type")),
                "Certificate Subject": coerce_cell(
                    dig(crypto, "certificateProperties", "subjectName")
                ),
                "Occurrence Count": len(occurrence_items),
                "Property Count": len(property_items),
            }
        )

        for occurrence in occurrence_items:
            if not isinstance(occurrence, dict):
                continue
            occurrences.rows.append(
                {
                    "Component": name,
                    "bom-ref": bom_ref,
                    "Location": coerce_cell(occurrence.get("location")),
                    "Line": occurrence.get("line", ""),
                    "Offset": occurrence.get("offset", ""),
                    "Additional Context": coerce_cell(occurrence.get("additionalContext")),
                }
            )

        for prop in property_items:
            properties.rows.append(
                {
                    "Component": name,
                    "bom-ref": bom_ref,
                    "Property Name": coerce_cell(prop.get("name")),
                    "Property Value": coerce_cell(prop.get("value")),
                }
            )

    _drop_orphans(occurrences, "Component", removed_refs, removed_names)
    _drop_orphans(properties, "Component", removed_refs, removed_names)

    return ExtractionResult(
        label="Internal",
        output_filename="Internal_Output.xlsx",
        sheets=[assets, occurrences, properties],
        removed_libraries=removed_labels,
    )


def _drop_orphans(
    sheet: SheetData,
    name_column: str,
    removed_refs: set,
    removed_names: set,
) -> None:
    """Remove rows belonging to components filtered out of the assets sheet."""
    if not removed_refs and not removed_names:
        return
    sheet.rows = [
        row
        for row in sheet.rows
        if row.get("bom-ref") not in removed_refs
        and row.get(name_column) not in removed_names
    ]


# --------------------------------------------------------------------------
# 3c.  Format detection (advisory only)
# --------------------------------------------------------------------------


def detect_flavour(document: Dict[str, Any]) -> str:
    """Guess whether a document came from SCANOSS or the internal generator."""
    blob = json.dumps(document.get("metadata", {}), ensure_ascii=False).lower()
    if "scanoss" in blob or "crypto-finder" in blob:
        return "SCANOSS"
    if "cbom-generator" in blob or "cbom:" in json.dumps(
        document.get("components", []), ensure_ascii=False
    )[:20000].lower():
        return "Internal"
    for component in component_list(document):
        for prop in component.get("properties") or []:
            if isinstance(prop, dict):
                prop_name = as_text(prop.get("name")).lower()
                if prop_name.startswith("scanoss:"):
                    return "SCANOSS"
                if prop_name.startswith("cbom:"):
                    return "Internal"
    return "Unknown"


# ===========================================================================
# 3d.  CERT-In CBOM TABLE MODEL
# ===========================================================================
#
# CERT-In's "Technical Guidelines on SBOM, QBOM, CBOM, AIBOM and HBOM"
# expresses a CBOM as four tables, one per cryptographic asset type.
# The column sets below reproduce those tables exactly.
#
# ---------------------------------------------------------------------------
# ASSUMPTION - please confirm before using this for a client deliverable.
#
# The last column of the CERT-In "Algorithms" table reads "List" in the source
# screenshot. There is no CycloneDX algorithmProperties field of that name.
# It sits immediately after "Classical security level", whose natural
# CycloneDX companion is `nistQuantumSecurityLevel`, so that is what this tool
# populates it with. If CERT-In means something else, change the single
# extractor on ALGORITHM_LIST_COLUMN below - nothing else needs to move.
# ---------------------------------------------------------------------------

ALGORITHM_LIST_COLUMN = "List"
ALGORITHM_LIST_SOURCE = "cryptoProperties.algorithmProperties.nistQuantumSecurityLevel"
ALGORITHM_LIST_ASSUMED = True  # set False once the header is confirmed


@dataclass(frozen=True)
class CertInField:
    """One column of a CERT-In table."""

    label: str
    source: str                                   # documented CycloneDX path
    extract: Callable[[Dict[str, Any]], Any]


@dataclass(frozen=True)
class CertInTable:
    """One of the four CERT-In cryptographic asset tables."""

    name: str
    asset_types: Tuple[str, ...]
    fields: Tuple[CertInField, ...]

    @property
    def labels(self) -> List[str]:
        return [field_.label for field_ in self.fields]


def _algo(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "algorithmProperties", *path)


def _material(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "relatedCryptoMaterialProperties", *path)


def _protocol(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "protocolProperties", *path)


def _certificate(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "certificateProperties", *path)


def _cipher_suites(comp: Dict[str, Any]) -> str:
    """protocolProperties.cipherSuites[] is an array of objects, not strings."""
    suites = dig(comp, "cryptoProperties", "protocolProperties", "cipherSuites", default=[])
    if not isinstance(suites, list):
        return as_text(suites)
    names: List[str] = []
    for suite in suites:
        if isinstance(suite, dict):
            names.append(as_text(suite.get("name") or suite.get("identifiers")))
        else:
            names.append(as_text(suite))
    return ", ".join(name for name in names if name)


_NAME = CertInField("Name", "component.name", lambda comp: comp.get("name"))
_ASSET_TYPE = CertInField(
    "Asset Type", "cryptoProperties.assetType",
    lambda comp: dig(comp, "cryptoProperties", "assetType"),
)
_OID = CertInField("OID", "cryptoProperties.oid", lambda comp: dig(comp, "cryptoProperties", "oid"))


CERTIN_TABLES: Tuple[CertInTable, ...] = (
    CertInTable(
        name="Algorithms",
        asset_types=("algorithm",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField("Primitive", "algorithmProperties.primitive", _algo("primitive")),
            CertInField("Mode", "algorithmProperties.mode", _algo("mode")),
            CertInField(
                "Crypto Functions", "algorithmProperties.cryptoFunctions",
                _algo("cryptoFunctions"),
            ),
            CertInField(
                "Classical security level", "algorithmProperties.classicalSecurityLevel",
                _algo("classicalSecurityLevel"),
            ),
            _OID,
            CertInField(
                ALGORITHM_LIST_COLUMN,
                ALGORITHM_LIST_SOURCE + (" (ASSUMED)" if ALGORITHM_LIST_ASSUMED else ""),
                _algo("nistQuantumSecurityLevel"),
            ),
        ),
    ),
    CertInTable(
        name="Keys",
        asset_types=("related-crypto-material",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField("id", "relatedCryptoMaterialProperties.id", _material("id")),
            CertInField("state", "relatedCryptoMaterialProperties.state", _material("state")),
            CertInField("size", "relatedCryptoMaterialProperties.size", _material("size")),
            CertInField(
                "Creation Date", "relatedCryptoMaterialProperties.creationDate",
                _material("creationDate"),
            ),
            CertInField(
                "Activation Date", "relatedCryptoMaterialProperties.activationDate",
                _material("activationDate"),
            ),
        ),
    ),
    CertInTable(
        name="Protocols",
        asset_types=("protocol",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField("Version", "protocolProperties.version", _protocol("version")),
            CertInField("Cipher Suites", "protocolProperties.cipherSuites[].name", _cipher_suites),
            _OID,
        ),
    ),
    CertInTable(
        name="Certificates",
        asset_types=("certificate",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField(
                "Subject Name", "certificateProperties.subjectName", _certificate("subjectName")
            ),
            CertInField(
                "Issuer Name", "certificateProperties.issuerName", _certificate("issuerName")
            ),
            CertInField(
                "Not Valid Before", "certificateProperties.notValidBefore",
                _certificate("notValidBefore"),
            ),
            CertInField(
                "Not Valid After", "certificateProperties.notValidAfter",
                _certificate("notValidAfter"),
            ),
            CertInField(
                "Signature Algorithm Reference", "certificateProperties.signatureAlgorithmRef",
                _certificate("signatureAlgorithmRef"),
            ),
            CertInField(
                "Subject Public Key Reference", "certificateProperties.subjectPublicKeyRef",
                _certificate("subjectPublicKeyRef"),
            ),
            CertInField(
                "Certificate Format", "certificateProperties.certificateFormat",
                _certificate("certificateFormat"),
            ),
            CertInField(
                "Certificate Extension", "certificateProperties.certificateExtension",
                _certificate("certificateExtension"),
            ),
        ),
    ),
)

CERTIN_MAX_COLUMNS = max(len(table.fields) for table in CERTIN_TABLES)


@dataclass
class CertInExtraction:
    """CERT-In view of one tool's CBOM (or a placeholder when none supplied)."""

    label: str                                  # "SCANOSS" / "Internal"
    source_file: str = ""
    supplied: bool = False
    tables: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    unclassified: List[str] = field(default_factory=list)

    def rows_for(self, table_name: str) -> List[Dict[str, Any]]:
        return self.tables.get(table_name, [])


def is_populated(value: Any) -> bool:
    """A field counts as captured when it carries a real value (0 counts)."""
    if value is None:
        return False
    if isinstance(value, (list, tuple, dict)):
        return len(value) > 0
    return str(value).strip() != ""


def build_certin_extraction(
    label: str, document: Dict[str, Any], source_file: str
) -> CertInExtraction:
    """Project a CycloneDX CBOM onto the four CERT-In tables."""
    extraction = CertInExtraction(
        label=label,
        source_file=source_file,
        supplied=True,
        tables={table.name: [] for table in CERTIN_TABLES},
    )

    by_asset_type: Dict[str, CertInTable] = {}
    for table in CERTIN_TABLES:
        for asset_type in table.asset_types:
            by_asset_type[asset_type] = table

    for component in component_list(document):
        if as_text(component.get("type")).strip().lower() == LIBRARY_TYPE:
            continue

        asset_type = as_text(dig(component, "cryptoProperties", "assetType")).strip().lower()
        table = by_asset_type.get(asset_type)
        if table is None:
            extraction.unclassified.append(
                f"{as_text(component.get('name')) or '(unnamed)'} "
                f"(assetType='{asset_type or 'absent'}')"
            )
            continue

        extraction.tables[table.name].append(
            {field_.label: coerce_cell(field_.extract(component)) for field_ in table.fields}
        )

    return extraction


# --------------------------------------------------------------------------
# Field-capture coverage
# --------------------------------------------------------------------------


@dataclass
class CoverageRow:
    table: str
    tool: str
    status: str
    records: Any
    total_fields: int
    captured: Any
    not_captured: Any
    percentage: Any
    captured_fields: str
    missing_fields: str


def compute_coverage(
    table: CertInTable, extraction: CertInExtraction
) -> Tuple[CoverageRow, Dict[str, int]]:
    """
    Count how many CERT-In fields the tool actually populates.

    A field is 'captured' when at least one record carries a value for it.
    Also returns the per-field populated-record counts.
    """
    rows = extraction.rows_for(table.name)
    per_field = {
        field_.label: sum(1 for row in rows if is_populated(row.get(field_.label)))
        for field_ in table.fields
    }
    total = len(table.fields)

    if not extraction.supplied:
        return (
            CoverageRow(
                table=table.name,
                tool=extraction.label,
                status="File not supplied",
                records="-",
                total_fields=total,
                captured="-",
                not_captured="-",
                percentage="-",
                captured_fields="-",
                missing_fields="-",
            ),
            per_field,
        )

    captured = [label for label, count in per_field.items() if count > 0]
    missing = [label for label, count in per_field.items() if count == 0]

    if not rows:
        status = "No assets of this type"
    elif not missing:
        status = "Fully captured"
    elif not captured:
        status = "Not captured"
    else:
        status = "Partially captured"

    return (
        CoverageRow(
            table=table.name,
            tool=extraction.label,
            status=status,
            records=len(rows),
            total_fields=total,
            captured=len(captured),
            not_captured=len(missing),
            percentage=round(len(captured) / total * 100, 1) if total else 0.0,
            captured_fields=", ".join(captured) if captured else "-",
            missing_fields=", ".join(missing) if missing else "-",
        ),
        per_field,
    )




HEADER_FILL = "FF2E5C8A"
HEADER_FONT_COLOUR = "FFFFFFFF"
MAX_COLUMN_WIDTH = 70
MIN_COLUMN_WIDTH = 10
EXCEL_CELL_LIMIT = 32767


def write_workbook(result: ExtractionResult, output_dir: str) -> str:
    """Write one ExtractionResult to <output_dir>/<result.output_filename>."""
    if Workbook is None:
        raise RuntimeError(
            "openpyxl is not installed. Run:  pip install openpyxl"
        )

    workbook = Workbook()
    workbook.remove(workbook.active)

    for sheet_data in result.sheets:
        worksheet = workbook.create_sheet(title=sheet_data.name[:31])
        _write_sheet(worksheet, sheet_data)

    destination = os.path.join(output_dir, result.output_filename)
    try:
        workbook.save(destination)
    except PermissionError as exc:
        raise RuntimeError(
            f"Cannot write '{result.output_filename}'.\n\n"
            f"The file is most likely open in Excel - close it and try again."
        ) from exc
    return destination


def _write_sheet(worksheet: "Worksheet", sheet_data: SheetData) -> None:
    header_font = Font(bold=True, color=HEADER_FONT_COLOUR)
    header_fill = PatternFill("solid", fgColor=HEADER_FILL)
    header_alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="FFB8C4D4")
    header_border = Border(bottom=thin)

    worksheet.append(sheet_data.headers)
    for cell in worksheet[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = header_border

    widths = [len(str(header)) for header in sheet_data.headers]

    for row in sheet_data.rows:
        values: List[Any] = []
        for index, header in enumerate(sheet_data.headers):
            value = row.get(header, "")
            if isinstance(value, str) and len(value) > EXCEL_CELL_LIMIT:
                value = value[: EXCEL_CELL_LIMIT - 20] + " ...[truncated]"
            values.append(value)
            widths[index] = max(widths[index], min(len(as_text(value)), MAX_COLUMN_WIDTH))
        worksheet.append(values)

    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = max(
            MIN_COLUMN_WIDTH, min(width + 2, MAX_COLUMN_WIDTH)
        )

    worksheet.freeze_panes = "A2"
    if sheet_data.rows:
        worksheet.auto_filter.ref = (
            f"A1:{get_column_letter(len(sheet_data.headers))}{len(sheet_data.rows) + 1}"
        )


# --------------------------------------------------------------------------
# 4b.  CERT-In workbooks
# --------------------------------------------------------------------------

CERTIN_TITLE_FILL = "FF1F3864"
SECTION_FILL = "FFDCE6F1"
MUTED = "FF808080"

CERTIN_CBOM_FILENAME = "CERTIN_CBOM.xlsx"
CERTIN_COVERAGE_FILENAME = "CERTIN_Field_Coverage.xlsx"


def write_certin_workbook(
    extractions: Sequence[CertInExtraction], output_dir: str
) -> str:
    """
    One sheet per tool, each carrying the four CERT-In tables stacked in the
    order used by the CERT-In guideline (Algorithms, Keys, Protocols,
    Certificates). Tools with no file supplied still get a sheet holding the
    blank CERT-In template, so the workbook shape never changes.
    """
    workbook = Workbook()
    workbook.remove(workbook.active)

    for extraction in extractions:
        worksheet = workbook.create_sheet(title=extraction.label[:31])
        _write_certin_sheet(worksheet, extraction)

    destination = os.path.join(output_dir, CERTIN_CBOM_FILENAME)
    _save(workbook, destination, CERTIN_CBOM_FILENAME)
    return destination


def _write_certin_sheet(worksheet: "Worksheet", extraction: CertInExtraction) -> None:
    last_column = get_column_letter(CERTIN_MAX_COLUMNS)
    thin = Side(style="thin", color="FF9BB0C9")
    cell_border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # ---- title block -----------------------------------------------------
    worksheet.merge_cells(f"A1:{last_column}1")
    title = worksheet["A1"]
    title.value = f"CBOM as per CERT-In  -  {extraction.label}"
    title.font = Font(bold=True, size=14, color=HEADER_FONT_COLOUR)
    title.fill = PatternFill("solid", fgColor=CERTIN_TITLE_FILL)
    title.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    worksheet.row_dimensions[1].height = 24

    worksheet.merge_cells(f"A2:{last_column}2")
    subtitle = worksheet["A2"]
    subtitle.value = (
        f"Source: {os.path.basename(extraction.source_file)}"
        if extraction.supplied
        else "No file supplied for this tool - blank CERT-In template shown."
    )
    subtitle.font = Font(italic=True, color=MUTED, size=9)

    worksheet["A4"] = "Cryptographic Asset Type :"
    worksheet["A4"].font = Font(bold=True, size=11)

    row_index = 6

    for table in CERTIN_TABLES:
        # ---- section heading ---------------------------------------------
        heading = worksheet.cell(row=row_index, column=1, value=table.name)
        heading.font = Font(bold=True, size=12)
        row_index += 1

        # ---- header row ---------------------------------------------------
        for column_index, field_ in enumerate(table.fields, start=1):
            cell = worksheet.cell(row=row_index, column=column_index, value=field_.label)
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor=SECTION_FILL)
            cell.border = cell_border
            cell.alignment = Alignment(wrap_text=True, vertical="center")
        worksheet.row_dimensions[row_index].height = 28
        row_index += 1

        # ---- data rows ----------------------------------------------------
        rows = extraction.rows_for(table.name)
        if rows:
            for record in rows:
                for column_index, field_ in enumerate(table.fields, start=1):
                    value = record.get(field_.label, "")
                    cell = worksheet.cell(row=row_index, column=column_index, value=value)
                    cell.border = cell_border
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
                row_index += 1
        else:
            message = (
                f"No {table.name.lower()} identified in this CBOM."
                if extraction.supplied
                else "Not supplied."
            )
            worksheet.merge_cells(
                start_row=row_index, start_column=1,
                end_row=row_index, end_column=len(table.fields),
            )
            cell = worksheet.cell(row=row_index, column=1, value=message)
            cell.font = Font(italic=True, color=MUTED)
            cell.border = cell_border
            row_index += 1

        row_index += 2  # breathing room between tables

    # ---- unclassified footnote -------------------------------------------
    if extraction.unclassified:
        worksheet.cell(
            row=row_index, column=1,
            value=(
                f"Note: {len(extraction.unclassified)} component(s) carried no recognised "
                f"cryptoProperties.assetType and could not be placed in a CERT-In table: "
                + "; ".join(extraction.unclassified[:20])
            ),
        ).font = Font(italic=True, color="FFB07000", size=9)

    _autosize_certin_columns(worksheet)


def _autosize_certin_columns(worksheet: "Worksheet") -> None:
    widths = [14] * CERTIN_MAX_COLUMNS
    for row in worksheet.iter_rows(
        min_row=6, max_col=CERTIN_MAX_COLUMNS, values_only=False
    ):
        for cell in row:
            if cell.value is None or cell.column > CERTIN_MAX_COLUMNS:
                continue
            text = as_text(cell.value)
            if len(text) > 120:      # merged notes must not stretch column A
                continue
            widths[cell.column - 1] = max(widths[cell.column - 1], min(len(text) + 2, 34))
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = width


COVERAGE_SUMMARY_HEADERS = [
    "CERT-In Table",
    "Tool",
    "Status",
    "Records",
    "Total Fields",
    "Fields Captured",
    "Fields Not Captured",
    "Coverage %",
    "Captured Fields",
    "Missing Fields",
]

COVERAGE_DETAIL_HEADERS = [
    "CERT-In Table",
    "CERT-In Field",
    "CycloneDX Source Path",
    "SCANOSS - Records Populated",
    "SCANOSS - Captured",
    "Internal - Records Populated",
    "Internal - Captured",
]


def write_coverage_workbook(
    extractions: Sequence[CertInExtraction], output_dir: str
) -> str:
    """
    Two rows per CERT-In table - one for SCANOSS, one for the Internal tool -
    counting how many of that table's fields each tool actually populates,
    plus a per-field breakdown showing exactly which fields are missing.
    """
    by_label = {extraction.label: extraction for extraction in extractions}
    ordered = [by_label["SCANOSS"], by_label["Internal"]]

    workbook = Workbook()
    workbook.remove(workbook.active)

    summary = workbook.create_sheet("Coverage Summary")
    _write_header_row(summary, COVERAGE_SUMMARY_HEADERS)

    detail_rows: List[List[Any]] = []
    totals = {extraction.label: [0, 0, 0] for extraction in ordered}  # captured, total, records

    for table in CERTIN_TABLES:
        per_field_by_tool: Dict[str, Dict[str, int]] = {}
        for extraction in ordered:
            coverage, per_field = compute_coverage(table, extraction)
            per_field_by_tool[extraction.label] = per_field
            summary.append(
                [
                    coverage.table,
                    coverage.tool,
                    coverage.status,
                    coerce_cell(coverage.records),
                    coerce_cell(coverage.total_fields),
                    coerce_cell(coverage.captured),
                    coerce_cell(coverage.not_captured),
                    coerce_cell(coverage.percentage),
                    coverage.captured_fields,
                    coverage.missing_fields,
                ]
            )
            if extraction.supplied:
                totals[extraction.label][0] += int(coverage.captured)
                totals[extraction.label][1] += coverage.total_fields
                totals[extraction.label][2] += int(coverage.records)

        for field_ in table.fields:
            scanoss_count = per_field_by_tool["SCANOSS"].get(field_.label, 0)
            internal_count = per_field_by_tool["Internal"].get(field_.label, 0)
            detail_rows.append(
                [
                    table.name,
                    field_.label,
                    field_.source,
                    scanoss_count if by_label["SCANOSS"].supplied else "-",
                    _yes_no(scanoss_count, by_label["SCANOSS"].supplied),
                    internal_count if by_label["Internal"].supplied else "-",
                    _yes_no(internal_count, by_label["Internal"].supplied),
                ]
            )

    # ---- overall totals, visually separated from the eight required rows --
    summary.append([])
    for extraction in ordered:
        captured, total, records = totals[extraction.label]
        summary.append(
            [
                "TOTAL (all four tables)",
                extraction.label,
                "File not supplied" if not extraction.supplied else "Overall",
                records if extraction.supplied else "-",
                total if extraction.supplied else sum(len(t.fields) for t in CERTIN_TABLES),
                captured if extraction.supplied else "-",
                (total - captured) if extraction.supplied else "-",
                round(captured / total * 100, 1) if extraction.supplied and total else "-",
                "",
                "",
            ]
        )

    # ---- typography and number formats -----------------------------------
    for row in summary.iter_rows(min_row=2, max_row=summary.max_row):
        is_total = row[0].value and str(row[0].value).startswith("TOTAL")
        if is_total:
            for cell in row:
                cell.font = Font(bold=True)
        # Column H (index 7) is Coverage % - format numeric cells as "62.5%"
        percent_cell = row[7]
        if isinstance(percent_cell.value, (int, float)):
            percent_cell.number_format = '0.0"%"'

    _finalise_sheet(summary, COVERAGE_SUMMARY_HEADERS)

    detail = workbook.create_sheet("Field Detail")
    _write_header_row(detail, COVERAGE_DETAIL_HEADERS)
    for row in detail_rows:
        detail.append(row)
    _finalise_sheet(detail, COVERAGE_DETAIL_HEADERS)

    notes = workbook.create_sheet("Method")
    for line in _coverage_method_notes(ordered):
        notes.append([line])
    notes.column_dimensions["A"].width = 120
    notes["A1"].font = Font(bold=True, size=12)

    destination = os.path.join(output_dir, CERTIN_COVERAGE_FILENAME)
    _save(workbook, destination, CERTIN_COVERAGE_FILENAME)
    return destination


def _yes_no(count: int, supplied: bool) -> str:
    if not supplied:
        return "-"
    return "Yes" if count > 0 else "No"


def _coverage_method_notes(extractions: Sequence[CertInExtraction]) -> List[str]:
    lines = [
        "How this coverage was calculated",
        "",
        "A CERT-In field counts as CAPTURED when at least one record in that table carries a",
        "non-empty value for it. A field present in the schema but blank in every record counts",
        "as NOT captured, because it gives a reviewer nothing to assess.",
        "",
        "Records are drawn from cryptoProperties.assetType:",
        "    algorithm                -> Algorithms table",
        "    related-crypto-material  -> Keys table",
        "    protocol                 -> Protocols table",
        "    certificate              -> Certificates table",
        "",
        "Components of type 'library' are excluded, matching the filtering rule applied to the",
        "per-tool detail workbooks. Components with no recognised assetType are excluded and",
        "listed as a footnote on the corresponding CERT-In sheet.",
        "",
    ]
    if ALGORITHM_LIST_ASSUMED:
        lines += [
            "ASSUMPTION - the final Algorithms column ('List')",
            f"    Mapped to {ALGORITHM_LIST_SOURCE}.",
            "    No CycloneDX field is named 'List'. This column sits directly after 'Classical",
            "    security level', whose CycloneDX companion is nistQuantumSecurityLevel, so that",
            "    is what has been used. Confirm against the CERT-In guideline before issuing this",
            "    workbook to a client.",
            "",
        ]
    lines.append("Inputs used for this run:")
    for extraction in extractions:
        lines.append(
            f"    {extraction.label}: "
            + (os.path.basename(extraction.source_file) if extraction.supplied else "not supplied")
        )
    return lines


def _write_header_row(worksheet: "Worksheet", headers: Sequence[str]) -> None:
    worksheet.append(list(headers))
    thin = Side(style="thin", color="FFB8C4D4")
    for cell in worksheet[1]:
        cell.font = Font(bold=True, color=HEADER_FONT_COLOUR)
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        cell.border = Border(bottom=thin)
    worksheet.row_dimensions[1].height = 30


def _finalise_sheet(worksheet: "Worksheet", headers: Sequence[str]) -> None:
    widths = [len(str(header)) for header in headers]
    for row in worksheet.iter_rows(min_row=2, values_only=True):
        for index, value in enumerate(row):
            if index < len(widths) and value is not None:
                widths[index] = max(widths[index], min(len(as_text(value)), MAX_COLUMN_WIDTH))
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = max(
            MIN_COLUMN_WIDTH, min(width + 2, MAX_COLUMN_WIDTH)
        )
    worksheet.freeze_panes = "A2"


def _save(workbook: "Workbook", destination: str, filename: str) -> None:
    try:
        workbook.save(destination)
    except PermissionError as exc:
        raise RuntimeError(
            f"Cannot write '{filename}'.\n\n"
            f"The file is most likely open in Excel - close it and try again."
        ) from exc


# ===========================================================================
# 5.  ORCHESTRATION (headless-safe - importable and testable)
# ===========================================================================

ProgressCallback = Callable[[int, str], None]


def process_inputs(
    scanoss_path: Optional[str],
    internal_path: Optional[str],
    output_dir: str,
    progress: Optional[ProgressCallback] = None,
    include_certin: bool = True,
) -> Tuple[List[str], List[str]]:
    """
    Process whichever inputs were supplied.

    Returns (written_file_paths, log_messages). Raises RuntimeError with a
    user-facing message on unrecoverable failures.
    """

    def report(percent: int, message: str) -> None:
        if progress:
            progress(percent, message)

    if not scanoss_path and not internal_path:
        raise RuntimeError("Select at least one CBOM file before processing.")

    if not output_dir:
        raise RuntimeError("Select an output folder before processing.")

    if not os.path.isdir(output_dir):
        try:
            os.makedirs(output_dir, exist_ok=True)
        except OSError as exc:
            raise RuntimeError(f"Cannot create output folder:\n{output_dir}\n\n{exc}")

    jobs: List[Tuple[str, str, Callable[[Dict[str, Any]], ExtractionResult]]] = []
    if scanoss_path:
        jobs.append(("SCANOSS", scanoss_path, extract_scanoss))
    if internal_path:
        jobs.append(("Internal", internal_path, extract_internal))

    written: List[str] = []
    log: List[str] = []
    certin: Dict[str, CertInExtraction] = {
        "SCANOSS": CertInExtraction(label="SCANOSS"),
        "Internal": CertInExtraction(label="Internal"),
    }

    step = 0
    total_steps = len(jobs) * 3 + (2 if include_certin else 0)

    for label, path, extractor in jobs:
        step += 1
        report(int(step / total_steps * 100), f"Reading {label} file...")
        log.append(f"[{label}] Reading {os.path.basename(path)}")

        document, notes = load_cbom(path)
        log.extend(notes)

        detected = detect_flavour(document)
        if detected != "Unknown" and detected != label:
            log.append(
                f"[{label}] WARNING: this file does not look like a {label} CBOM "
                f"(detected format: {detected}). Check it was loaded into the correct slot."
            )

        spec_version = as_text(document.get("specVersion"))
        bom_format = as_text(document.get("bomFormat"))
        if bom_format and bom_format.lower() != "cyclonedx":
            log.append(f"[{label}] WARNING: bomFormat is '{bom_format}', expected CycloneDX.")
        log.append(f"[{label}] CycloneDX spec version {spec_version or 'unspecified'}")

        step += 1
        report(int(step / total_steps * 100), f"Extracting {label} components...")
        result = extractor(document)

        if result.removed_libraries:
            log.append(
                f"[{label}] Filtered out {len(result.removed_libraries)} component(s) "
                f"of type 'library':"
            )
            log.extend(f"    - {item}" for item in result.removed_libraries)
        else:
            log.append(f"[{label}] No 'library' components to filter.")

        for sheet in result.sheets:
            log.append(f"[{label}] {sheet.name}: {len(sheet.rows)} row(s)")

        if result.total_rows == 0:
            log.append(
                f"[{label}] WARNING: no rows extracted - the file may not contain "
                f"cryptographic-asset components."
            )

        if include_certin:
            certin[label] = build_certin_extraction(label, document, path)

        step += 1
        report(int(step / total_steps * 100), f"Writing {result.output_filename}...")
        destination = write_workbook(result, output_dir)
        written.append(destination)
        log.append(f"[{label}] Wrote {destination}")

    # ---- CERT-In workbooks ------------------------------------------------
    if include_certin:
        extractions = [certin["SCANOSS"], certin["Internal"]]

        for extraction in extractions:
            if not extraction.supplied:
                log.append(
                    f"[CERT-In] {extraction.label}: no file supplied - blank template sheet "
                    f"and 'File not supplied' coverage rows will be written."
                )
                continue
            counts = ", ".join(
                f"{table.name} {len(extraction.rows_for(table.name))}"
                for table in CERTIN_TABLES
            )
            log.append(f"[CERT-In] {extraction.label}: {counts}")
            if extraction.unclassified:
                log.append(
                    f"[CERT-In] WARNING: {extraction.label} has "
                    f"{len(extraction.unclassified)} component(s) with no recognised "
                    f"cryptoProperties.assetType - excluded from all four tables:"
                )
                log.extend(f"    - {item}" for item in extraction.unclassified[:20])

        if ALGORITHM_LIST_ASSUMED:
            log.append(
                "[CERT-In] WARNING: the final Algorithms column ('List') has no matching "
                f"CycloneDX field; mapped to {ALGORITHM_LIST_SOURCE} as an assumption. "
                "Confirm before issuing to a client - see the Method sheet."
            )

        step += 1
        report(int(step / total_steps * 100), f"Writing {CERTIN_CBOM_FILENAME}...")
        destination = write_certin_workbook(extractions, output_dir)
        written.append(destination)
        log.append(f"[CERT-In] Wrote {destination}")

        step += 1
        report(int(step / total_steps * 100), f"Writing {CERTIN_COVERAGE_FILENAME}...")
        destination = write_coverage_workbook(extractions, output_dir)
        written.append(destination)
        log.append(f"[CERT-In] Wrote {destination}")

    report(100, "Done.")
    return written, log


# ===========================================================================
# 6.  GUI
# ===========================================================================


def launch_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    class CBOMApp:
        def __init__(self, root: "tk.Tk") -> None:
            self.root = root
            self.root.title(f"{APP_NAME}  v{APP_VERSION}")
            self.root.geometry("880x620")
            self.root.minsize(760, 560)

            self.scanoss_var = tk.StringVar()
            self.internal_var = tk.StringVar()
            self.output_var = tk.StringVar(
                value=os.path.join(os.path.expanduser("~"), "Desktop")
                if os.path.isdir(os.path.join(os.path.expanduser("~"), "Desktop"))
                else os.getcwd()
            )
            self.certin_var = tk.BooleanVar(value=True)
            self.status_var = tk.StringVar(value="Ready. Select at least one CBOM file.")

            self.events: "queue.Queue[Tuple[str, Any]]" = queue.Queue()
            self.worker: Optional[threading.Thread] = None

            self._build_ui(ttk, tk)
            self.root.after(100, self._drain_events)

        # ---------------- layout ----------------
        def _build_ui(self, ttk, tk) -> None:
            style = ttk.Style()
            try:
                style.theme_use("clam")
            except Exception:
                pass
            style.configure("Header.TLabel", font=("Segoe UI", 15, "bold"))
            style.configure("Sub.TLabel", foreground="#555555")
            style.configure("Run.TButton", font=("Segoe UI", 10, "bold"))

            container = ttk.Frame(self.root, padding=16)
            container.pack(fill="both", expand=True)
            container.columnconfigure(0, weight=1)

            header = ttk.Frame(container)
            header.grid(row=0, column=0, sticky="ew")
            ttk.Label(header, text="CBOM Comparison & Analysis", style="Header.TLabel").pack(
                anchor="w"
            )
            ttk.Label(
                header,
                text="Parses CycloneDX CBOM reports from SCANOSS and the internal "
                "generator into review-ready workbooks.",
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(2, 0))

            # ---- inputs ----
            inputs = ttk.LabelFrame(container, text=" Inputs ", padding=12)
            inputs.grid(row=1, column=0, sticky="ew", pady=(14, 0))
            inputs.columnconfigure(1, weight=1)

            self._file_row(
                ttk, inputs, 0, "SCANOSS CBOM (.json)", self.scanoss_var, self._browse_scanoss
            )
            self._file_row(
                ttk, inputs, 1, "Internal CBOM (.json)", self.internal_var, self._browse_internal
            )

            ttk.Label(
                inputs,
                text="Either input may be left blank - a workbook is produced for each file supplied.",
                style="Sub.TLabel",
            ).grid(row=2, column=0, columnspan=4, sticky="w", pady=(8, 0))

            # ---- output ----
            output = ttk.LabelFrame(container, text=" Output ", padding=12)
            output.grid(row=2, column=0, sticky="ew", pady=(12, 0))
            output.columnconfigure(1, weight=1)
            self._file_row(
                ttk, output, 0, "Output folder", self.output_var, self._browse_output,
                clearable=False,
            )
            ttk.Checkbutton(
                output,
                text="Also generate CERT-In workbooks  (CERTIN_CBOM.xlsx  +  "
                "CERTIN_Field_Coverage.xlsx)",
                variable=self.certin_var,
            ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(8, 0))

            # ---- actions ----
            actions = ttk.Frame(container)
            actions.grid(row=3, column=0, sticky="ew", pady=(14, 0))
            actions.columnconfigure(1, weight=1)

            self.process_button = ttk.Button(
                actions, text="Process", style="Run.TButton", command=self._start
            )
            self.process_button.grid(row=0, column=0, ipadx=18, ipady=3)

            self.progress = ttk.Progressbar(actions, mode="determinate", maximum=100)
            self.progress.grid(row=0, column=1, sticky="ew", padx=(14, 14))

            ttk.Button(actions, text="Open output folder", command=self._open_output).grid(
                row=0, column=2
            )

            ttk.Label(container, textvariable=self.status_var).grid(
                row=4, column=0, sticky="w", pady=(10, 0)
            )

            # ---- log ----
            log_frame = ttk.LabelFrame(container, text=" Activity log ", padding=8)
            log_frame.grid(row=5, column=0, sticky="nsew", pady=(10, 0))
            container.rowconfigure(5, weight=1)
            log_frame.columnconfigure(0, weight=1)
            log_frame.rowconfigure(0, weight=1)

            self.log_widget = tk.Text(
                log_frame, height=12, wrap="none", font=("Consolas", 9),
                background="#1E1E1E", foreground="#DCDCDC", insertbackground="#DCDCDC",
                relief="flat",
            )
            self.log_widget.grid(row=0, column=0, sticky="nsew")
            scroll_y = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_widget.yview)
            scroll_y.grid(row=0, column=1, sticky="ns")
            scroll_x = ttk.Scrollbar(log_frame, orient="horizontal", command=self.log_widget.xview)
            scroll_x.grid(row=1, column=0, sticky="ew")
            self.log_widget.configure(
                yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set, state="disabled"
            )
            self.log_widget.tag_configure("warn", foreground="#F0C674")
            self.log_widget.tag_configure("error", foreground="#F08080")
            self.log_widget.tag_configure("ok", foreground="#9CD67C")

        def _file_row(self, ttk, parent, row, label, variable, command, clearable=True):
            ttk.Label(parent, text=label, width=22).grid(row=row, column=0, sticky="w", pady=4)
            entry = ttk.Entry(parent, textvariable=variable)
            entry.grid(row=row, column=1, sticky="ew", padx=(6, 6), pady=4)
            ttk.Button(parent, text="Browse...", command=command).grid(row=row, column=2, pady=4)
            if clearable:
                ttk.Button(
                    parent, text="Clear", command=lambda v=variable: v.set("")
                ).grid(row=row, column=3, padx=(6, 0), pady=4)

        # ---------------- browsing ----------------
        def _browse_json(self, title):
            return filedialog.askopenfilename(
                title=title,
                filetypes=[
                    ("CBOM files", "*.json *.cdx.json *.txt"),
                    ("JSON files", "*.json"),
                    ("All files", "*.*"),
                ],
            )

        def _browse_scanoss(self) -> None:
            path = self._browse_json("Select the SCANOSS CBOM")
            if path:
                self.scanoss_var.set(path)
                self._set_status(f"SCANOSS file selected: {os.path.basename(path)}")

        def _browse_internal(self) -> None:
            path = self._browse_json("Select the Internal tool CBOM")
            if path:
                self.internal_var.set(path)
                self._set_status(f"Internal file selected: {os.path.basename(path)}")

        def _browse_output(self) -> None:
            path = filedialog.askdirectory(title="Select the output folder")
            if path:
                self.output_var.set(path)

        def _open_output(self) -> None:
            folder = self.output_var.get().strip()
            if not folder or not os.path.isdir(folder):
                messagebox.showwarning(APP_NAME, "That output folder does not exist yet.")
                return
            try:
                if sys.platform.startswith("win"):
                    os.startfile(folder)  # type: ignore[attr-defined]
                elif sys.platform == "darwin":
                    os.system(f'open "{folder}"')
                else:
                    os.system(f'xdg-open "{folder}"')
            except Exception as exc:
                messagebox.showwarning(APP_NAME, f"Could not open the folder:\n{exc}")

        # ---------------- logging ----------------
        def _log(self, message: str, tag: str = "") -> None:
            lowered = message.lower()
            if not tag:
                if "warning" in lowered:
                    tag = "warn"
                elif "error" in lowered or "cannot" in lowered:
                    tag = "error"
                elif message.startswith("Wrote") or " Wrote " in message:
                    tag = "ok"
            self.log_widget.configure(state="normal")
            stamp = datetime.now().strftime("%H:%M:%S")
            line = f"{stamp}  {message}\n"
            if tag:
                self.log_widget.insert("end", line, tag)
            else:
                self.log_widget.insert("end", line)
            self.log_widget.see("end")
            self.log_widget.configure(state="disabled")

        def _set_status(self, message: str) -> None:
            self.status_var.set(message)

        # ---------------- run ----------------
        def _start(self) -> None:
            if self.worker and self.worker.is_alive():
                return

            scanoss = self.scanoss_var.get().strip() or None
            internal = self.internal_var.get().strip() or None
            output_dir = self.output_var.get().strip()

            for label, path in (("SCANOSS", scanoss), ("Internal", internal)):
                if path and not os.path.isfile(path):
                    messagebox.showerror(
                        APP_NAME, f"The {label} file does not exist:\n{path}"
                    )
                    return

            if not scanoss and not internal:
                messagebox.showwarning(
                    APP_NAME, "Select at least one CBOM file before processing."
                )
                return

            if not output_dir:
                messagebox.showwarning(APP_NAME, "Select an output folder before processing.")
                return

            self.process_button.configure(state="disabled")
            self.progress["value"] = 0
            self.log_widget.configure(state="normal")
            self.log_widget.delete("1.0", "end")
            self.log_widget.configure(state="disabled")
            self._log(f"Run started - {datetime.now():%Y-%m-%d %H:%M:%S}")

            self.worker = threading.Thread(
                target=self._run_job,
                args=(scanoss, internal, output_dir, bool(self.certin_var.get())),
                daemon=True,
            )
            self.worker.start()

        def _run_job(self, scanoss, internal, output_dir, include_certin) -> None:
            def progress(percent: int, message: str) -> None:
                self.events.put(("progress", (percent, message)))

            try:
                written, log = process_inputs(
                    scanoss, internal, output_dir, progress, include_certin
                )
                self.events.put(("log", log))
                self.events.put(("done", written))
            except Exception as exc:  # noqa: BLE001 - surfaced to the user
                detail = str(exc) if str(exc) else traceback.format_exc()
                self.events.put(("failed", detail))

        def _drain_events(self) -> None:
            try:
                while True:
                    kind, payload = self.events.get_nowait()
                    if kind == "progress":
                        percent, message = payload
                        self.progress["value"] = percent
                        self._set_status(message)
                    elif kind == "log":
                        for line in payload:
                            self._log(line)
                    elif kind == "done":
                        self._finish_success(payload)
                    elif kind == "failed":
                        self._finish_failure(payload)
            except queue.Empty:
                pass
            self.root.after(100, self._drain_events)

        def _finish_success(self, written: Sequence[str]) -> None:
            self.progress["value"] = 100
            self.process_button.configure(state="normal")
            names = "\n".join(f"  - {os.path.basename(p)}" for p in written)
            self._set_status(f"Completed - {len(written)} workbook(s) written.")
            self._log("Run completed successfully.", "ok")
            messagebox.showinfo(
                APP_NAME,
                f"Processing complete.\n\n{len(written)} workbook(s) written to:\n"
                f"{os.path.dirname(written[0]) if written else ''}\n\n{names}",
            )

        def _finish_failure(self, detail: str) -> None:
            self.progress["value"] = 0
            self.process_button.configure(state="normal")
            self._set_status("Failed - see the activity log.")
            for line in detail.splitlines():
                self._log(line, "error")
            messagebox.showerror(APP_NAME, detail)

    root = tk.Tk()
    if Workbook is None:
        from tkinter import messagebox as mb

        mb.showerror(
            APP_NAME,
            "openpyxl is not installed.\n\nRun:  pip install openpyxl",
        )
        root.destroy()
        return
    CBOMApp(root)
    root.mainloop()


# ===========================================================================
# 7.  CLI FALLBACK
# ===========================================================================


def main(argv: Sequence[str]) -> int:
    if len(argv) > 1 and argv[1] in {"--cli", "-c"}:
        import argparse

        parser = argparse.ArgumentParser(description=APP_NAME)
        parser.add_argument("--cli", action="store_true")
        parser.add_argument("--scanoss", help="Path to the SCANOSS CBOM JSON")
        parser.add_argument("--internal", help="Path to the internal CBOM JSON")
        parser.add_argument("--out", default=os.getcwd(), help="Output folder")
        parser.add_argument(
            "--no-certin", action="store_true",
            help="Skip CERTIN_CBOM.xlsx and CERTIN_Field_Coverage.xlsx",
        )
        args = parser.parse_args(argv[1:])

        try:
            written, log = process_inputs(
                args.scanoss,
                args.internal,
                args.out,
                lambda pct, msg: print(f"[{pct:3d}%] {msg}"),
                include_certin=not args.no_certin,
            )
        except Exception as exc:  # noqa: BLE001
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1

        for line in log:
            print(line)
        print("\nWritten:")
        for path in written:
            print(f"  {path}")
        return 0

    launch_gui()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
