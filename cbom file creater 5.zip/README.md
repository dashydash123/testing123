# CBOM Comparison & Analysis Tool

Desktop utility that turns CycloneDX Cryptography Bills of Materials into
review-ready Excel workbooks. Supports CBOMs from **SCANOSS crypto-finder**
and the **internal CBOM Generator**, together or individually.

---

## Files

| File | Purpose |
|---|---|
| `cbom_analyzer.py` | The entire application (GUI + parser + Excel writer) |
| `build_exe.bat` | One-click PyInstaller build for a standalone `.exe` |
| `requirements.txt` | Runtime dependency (`openpyxl`) |

---

## Running from source

```bat
pip install -r requirements.txt
python cbom_analyzer.py
```

A headless mode is included for scripting and batch runs:

```bat
python cbom_analyzer.py --cli --scanoss scanoss.json --internal internal.json --out C:\Reports
```

Either `--scanoss` or `--internal` may be omitted.

## Building the executable

Double-click `build_exe.bat`, or run:

```bat
pip install openpyxl pyinstaller
pyinstaller --onefile --windowed --name CBOM_Analyzer cbom_analyzer.py
```

The result is `dist\CBOM_Analyzer.exe` — a single file, no Python required on
the target machine. Expect roughly 15–25 MB and a 3–8 second first launch
(the onefile bundle unpacks to `%TEMP%` on start).

> **Corporate build note:** some endpoint agents quarantine freshly built
> PyInstaller binaries because they are unsigned. If EY policy requires it, get
> the artifact code-signed, or distribute the `.py` plus `requirements.txt` and
> let users run it under an approved Python install.

---

## Outputs

| Inputs supplied | Workbooks produced |
|---|---|
| SCANOSS only | `SCANOSS_Output.xlsx` |
| Internal only | `Internal_Output.xlsx` |
| Both | `SCANOSS_Output.xlsx` **and** `Internal_Output.xlsx` |

Plus, in every case, `CERTIN_CBOM.xlsx` and `CERTIN_Field_Coverage.xlsx` —
see the CERT-In section below.

Every workbook contains exactly three sheets:

1. `Crypto Assets`
2. `Occurrences`
3. `Asset Name - Properties`

Sheet 3 is named with a hyphen rather than a slash because Excel forbids
`/ \ ? * [ ] :` in sheet names.

---

## Field mapping

### SCANOSS — Crypto Assets

| Column | CycloneDX source |
|---|---|
| bom-ref | `component["bom-ref"]` |
| type | `component.type` |
| name | `component.name` |
| description | `component.description` |
| assetType | `cryptoProperties.assetType` |
| primitive | `cryptoProperties.algorithmProperties.primitive` |
| parameterSetIdentifier | `…algorithmProperties.parameterSetIdentifier` |
| executionEnvironment | `…algorithmProperties.executionEnvironment` |
| implementationPlatform | `…algorithmProperties.implementationPlatform` |
| cryptoFunctions | `…algorithmProperties.cryptoFunctions` (joined) |
| oid | `cryptoProperties.oid` |
| relatedCryptoMaterialType | `cryptoProperties.relatedCryptoMaterialProperties.type` |
| scanossCryptoFunction | `properties[name = "scanoss:cryptoFunction"].value` |
| Occurrence Count | `len(evidence.occurrences)` |
| Identity Evidence Count | `len(evidence.identity)` |

### Internal — Crypto Assets

Adds `Group`, `Version`, `PURL`, `Protocol Type`
(`cryptoProperties.protocolProperties.type`), `Certificate Subject`
(`cryptoProperties.certificateProperties.subjectName`) and `Property Count`
(`len(properties)`).

### Occurrences

One row per `evidence.occurrences[]` entry. The Internal sheet additionally
carries `Offset`.

### Sheet 3

* **SCANOSS** — flattened `evidence.identity[]`, one row per
  `identity[] × methods[]` pair.
* **Internal** — flattened `component.properties[]`, one row per name/value pair.

---

## Filtering rules

Any component whose `type` is `library` is dropped from **Crypto Assets**, and
its rows are then removed from **Occurrences** and **Sheet 3** by matching on
`bom-ref` *or* component name. The activity log names every component removed
this way, so the deletion is auditable rather than silent.

In the pynacl samples this removes `libsodium` from the Internal workbook
(6 components → 5 assets, 16 → 13 occurrences, 15 → 12 property rows). The
SCANOSS sample has no `library` components, so nothing is filtered there.

---

## Malformed-input handling

The supplied Internal sample is **not valid JSON** — the EdDSA `bom-ref` is
unquoted in three places:

```json
"bom-ref": crypto/algorithm/eddsa@1.3.101.112,
```

`json.load()` rejects this outright. The loader therefore retries with a
repair pass covering unquoted scalars, unquoted array elements, trailing
commas, comments, and a UTF-8 BOM. Repairs are **reported in the activity
log**, never applied silently — the underlying generator bug still needs
fixing at source.

Other defensive behaviour:

* Missing input → that workbook is simply not produced; no crash.
* Empty file, or JSON that cannot be repaired → clear error naming the line
  and column.
* A file loaded into the wrong slot → format-detection warning
  (`scanoss:` vs `cbom:` property prefixes, tool metadata).
* Output file open in Excel → explicit "close it and try again" message
  rather than a `PermissionError` traceback.
* Cells beyond Excel's 32,767-character limit are truncated with a marker.
* Nested `components[]` arrays are flattened, so sub-components are not lost.


---

## CERT-In workbooks

Two further workbooks are produced whenever at least one input is supplied
(uncheck the box in the GUI, or pass `--no-certin`, to skip them).

### `CERTIN_CBOM.xlsx` — the CERT-In tables, filled

One sheet per tool (`SCANOSS`, `Internal`), each holding the four CERT-In
cryptographic asset tables stacked in guideline order. Both sheets are always
present: if a tool's file was not supplied, its sheet carries the blank CERT-In
template rather than disappearing, so the workbook shape never changes.

Records are routed by `cryptoProperties.assetType`:

| CERT-In table | CycloneDX assetType |
|---|---|
| Algorithms | `algorithm` |
| Keys | `related-crypto-material` |
| Protocols | `protocol` |
| Certificates | `certificate` |

Column mappings:

* **Algorithms** — Name, Asset Type, Primitive (`algorithmProperties.primitive`),
  Mode (`.mode`), Crypto Functions (`.cryptoFunctions`), Classical security level
  (`.classicalSecurityLevel`), OID (`cryptoProperties.oid`), List (see assumption below)
* **Keys** — Name, Asset Type, then `relatedCryptoMaterialProperties`: `id`,
  `state`, `size`, `creationDate`, `activationDate`
* **Protocols** — Name, Asset Type, `protocolProperties.version`,
  `protocolProperties.cipherSuites[].name`, `cryptoProperties.oid`
* **Certificates** — Name, Asset Type, then `certificateProperties`:
  `subjectName`, `issuerName`, `notValidBefore`, `notValidAfter`,
  `signatureAlgorithmRef`, `subjectPublicKeyRef`, `certificateFormat`,
  `certificateExtension`

Components of type `library` are excluded, as elsewhere. Components carrying no
recognised `assetType` are excluded too, and named in a footnote at the bottom
of the sheet so nothing disappears silently.

> **Open assumption — the "List" column.**
> The final Algorithms column reads *List* in the CERT-In source, and no
> CycloneDX `algorithmProperties` field has that name. It sits directly after
> *Classical security level*, whose CycloneDX companion is
> `nistQuantumSecurityLevel`, so that is what populates it. Change the single
> extractor at `ALGORITHM_LIST_COLUMN` near the top of `cbom_analyzer.py` if
> CERT-In means something else, and set `ALGORITHM_LIST_ASSUMED = False` to
> silence the warning. The assumption is restated on the Method sheet of the
> coverage workbook.

### `CERTIN_Field_Coverage.xlsx` — field capture counts

* **Coverage Summary** — two rows per CERT-In table, one per tool (eight rows),
  with record count, total fields, fields captured, fields not captured,
  coverage %, and the named captured/missing fields. Two `TOTAL` rows follow
  after a blank separator.
* **Field Detail** — one row per CERT-In field showing the CycloneDX source
  path and, for each tool, how many records populate it. This is where you see
  *which* fields are missing rather than just how many.
* **Method** — how coverage is defined, the assetType routing, and the open
  assumption above.

A field counts as **captured** when at least one record in that table carries a
non-empty value. A field that exists in the schema but is blank in every record
counts as not captured, since it gives a reviewer nothing to assess. Zero is
treated as a value, not a blank — relevant for `nistQuantumSecurityLevel: 0`.

### Result on the pynacl samples

| CERT-In table | Tool | Records | Fields captured | Coverage |
|---|---|---|---|---|
| Algorithms | SCANOSS | 5 | 5 / 8 | 62.5% |
| Algorithms | Internal | 5 | 7 / 8 | 87.5% |
| Keys | SCANOSS | 2 | 2 / 7 | 28.6% |
| Keys | Internal | 0 | 0 / 7 | 0% |
| Protocols | both | 0 | 0 / 5 | 0% |
| Certificates | both | 0 | 0 / 10 | 0% |

Neither tool emits `Mode` for any algorithm. SCANOSS reaches the Keys table
(via its `private-key` and `signature` related-crypto-material entries) but
populates only Name and Asset Type — no `id`, `state`, `size` or dates. The
internal tool captures more algorithm detail (`classicalSecurityLevel`,
`nistQuantumSecurityLevel`) but produces no non-algorithm assets at all.


---

## Comparative dashboard

Two more outputs, generated whenever at least one input is supplied (uncheck
the box in the GUI, or pass `--no-dashboard`, to skip them):

* **`dashboard_data.json`** — the data contract. A small, self-describing
  JSON document distilled from the same extraction and CERT-In logic used
  everywhere else in this tool. No raw CycloneDX passes through it.
* **`CBOM_Dashboard.html`** — that JSON inlined into a single, self-contained
  HTML file styled to match OSS Nexus (blue/black/white, pill badges,
  monospace nav labels). No external CSS/JS/CDN dependency, so it is safe to
  drop into an `<iframe>` on `oss-nexus-ten.vercel.app` or open directly from
  disk. Nothing is fetched at runtime — the data is baked in at generation
  time.

### What it shows

1. **Overview** — total crypto assets per tool, overlap count, and a CERT-In
   readiness ring per tool (% of the 30 CERT-In fields captured across all
   four tables).
2. **Asset Comparison** — every crypto asset found by both tools, SCANOSS
   only, and Internal only, plus a proportional overlap bar. Matched by
   **normalised name** (case/whitespace-insensitive) — bom-ref schemes are
   incompatible across tools (SCANOSS uses UUIDs, Internal uses
   `crypto/algorithm/name@id`), so name is the only usable join key. This is
   stated on the dashboard itself, not hidden in the numbers.
3. **CERT-In · Components** — per CERT-In table (Algorithms/Keys/Protocols/
   Certificates), which named components each tool placed there and where
   they disagree.
4. **CERT-In · Fields** — a field × tool heatmap reusing the exact coverage
   engine behind `CERTIN_Field_Coverage.xlsx`, so the numbers always agree
   with that workbook.

An expandable "Assumptions & methodology" panel on the Overview tab restates
the name-matching caveat and the CERT-In "List" column assumption, so anyone
opening the dashboard cold sees the same caveats as this README.

### On the pynacl samples

SCANOSS and the Internal tool found **zero overlapping algorithm names** —
SCANOSS surfaced Argon2i, BLAKE2b, ECDSA, X25519, XSalsa20-Poly1305,
private-key, signature; Internal surfaced AES, ChaCha20, EdDSA, scrypt,
os.urandom. That's a real finding from this sample pair, not a matching bug —
the two tools scanned for genuinely different algorithm families here.
CERT-In readiness came out identical by coincidence: 7/30 fields (23.3%) for
both tools, though the underlying record counts differ (7 vs 5).

### Verified

* All 21 open/close HTML tags balance; the embedded JSON parses and matches
  `dashboard_data.json` byte-for-byte.
* Rendered with `wkhtmltoimage` across all four tabs and the single-input
  case — confirmed non-blank, no leaked `undefined`, "File not supplied"
  renders correctly when a tool's CBOM wasn't provided.
* `--no-certin` with the dashboard still on produces correct CERT-In figures
  internally (the dashboard needs that data even when the standalone CERT-In
  workbooks are skipped).

---

## Verified against the samples

| | Crypto Assets | Occurrences | Sheet 3 |
|---|---|---|---|
| `SCANOSS_Output.xlsx` | 7 | 21 | 11 |
| `Internal_Output.xlsx` | 5 | 13 | 12 |

`CERTIN_CBOM.xlsx` — 2 sheets; SCANOSS 5 algorithms + 2 keys, Internal 5 algorithms.
`CERTIN_Field_Coverage.xlsx` — 8 summary rows + 2 totals, 30 field-detail rows.

All three input scenarios verified: SCANOSS only, Internal only, and both.
