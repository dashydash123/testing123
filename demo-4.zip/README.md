# xBOM Readiness Dashboard

One self-contained HTML file. No build step, no server, no CDN calls — open it by
double-clicking, or ship it inside an extract-and-run bundle. All parsing, scoring and
charting happen in the browser, so no BOM content leaves the machine.

## Colours

The palette follows the OSS Nexus product theme: white surfaces, `#2563EB` primary, mint
cards for a loaded/complete state, and the amber / blue / violet / pink / teal accent
family for chips and categories. Semantic colours are consistent across every figure —
green permissive, teal weak copyleft, amber strong copyleft, red use-restricted, slate
undeclared — so a colour means the same thing in the sankey, the treemap, the waffle and
the quadrant. All of it lives in the `:root` block at the top of the file.

## Files

| File | Format | Contents |
|---|---|---|
| `xbom-readiness-dashboard.html` | — | The dashboard. All five samples are embedded, so it demos with zero setup. |
| `samples/sample-sbom.cdx.json` | CycloneDX 1.6 | Container image, 12 components, licence and provenance gaps, 2 CVEs. |
| `samples/sample-aibom.cdx.json` | CycloneDX 1.6 | 3 models, 2 datasets, 4 libraries, one unresolved licence, one research-only model. |
| `samples/sample-cbom.cdx.json` | CycloneDX 1.6 | 5 algorithms, 3 keys, 3 protocols, 3 certificates — incl. SHA-1, TLS 1.1, ML-KEM-768. |
| `samples/sample-sbom.spdx.json` | SPDX 2.3 | 9 packages, NOASSERTION licences, GPL-with-exception, a `LicenseRef` restricted font. |
| `samples/sample-aibom.spdx3.json` | SPDX 3.0 | AI and dataset profiles — `ai_AIPackage`, `dataset_DatasetPackage`, relationship-based licensing. |

## Loading documents

Three slots — **SBOM**, **AIBOM**, **CBOM** — one document each. Drop a file on a slot or
use its Upload button. You say which BOM type it is; the tool works out the format.

Each slot shows the detected format, the subject and the item count once loaded, and warns
you when the contents don't match:

- *No AIBOM assets found in this document* — you loaded the wrong file into the slot.
- *Also carries CBOM assets* — a merged xBOM; load the same file into that slot too.

Slots are independent. Add, replace or remove one and every figure recomputes.

## Input formats

Each file is sniffed independently, so the three slots can hold three different formats.

| Signal | Parsed as |
|---|---|
| `bomFormat: "CycloneDX"` | CycloneDX 1.4–1.6 |
| `spdxVersion: "SPDX-2.x"` | SPDX 2.2 / 2.3 JSON |
| `@graph` / `@context` | SPDX 3.0 JSON-LD |

Everything normalises into one internal model — `{id, name, version, type, purl, licenses[],
supplier, refs[], model, dataset, crypto}` — and the evaluators only ever see that model.
Adding a format means writing one `fromX()` function; nothing downstream changes.

**What each format can carry:**

| | CycloneDX 1.6 | SPDX 2.3 | SPDX 3.0 |
|---|---|---|---|
| SBOM | full | full | full |
| AIBOM | `machine-learning-model` + `modelCard` | inferred from `pkg:huggingface/` and `pkg:dataset/` purls | `ai_AIPackage`, `dataset_DatasetPackage` |
| CBOM | `cryptographic-asset` + `cryptoProperties` | not representable | not representable |
| Vulnerabilities | `vulnerabilities[]` with VEX analysis | not representable | not representable |

Where a BOM type can't exist in the source format the dashboard says so rather than
scoring a false zero — load an SPDX SBOM on its own and a note appears explaining that
cryptography coverage needs a CycloneDX CBOM.

## Dimensions

The five dimensions per BOM type mirror the OSS Nexus BOM Analysis categories, and each
score measures the thing it is named after rather than just whether a field is populated:

| SBOM | AIBOM | CBOM |
|---|---|---|
| Component Identification | Model Card Lineage | Algorithm Risk |
| License Compliance | Model & Dataset License | Key Management |
| Dependency Graph | Dataset Provenance | Protocol Hygiene |
| CVE Triage | Library Compliance | Certificate Expiry |
| Supplier Provenance | Supply Chain Risk | PQC Readiness |

Worth being precise about what a few of them count, because the naive version would score
too generously:

- **Algorithm Risk** — characterised (primitive + parameter set) **and** not a retired
  primitive. SHA-1 with a full record still fails.
- **Protocol Hygiene** — versioned **and** at TLS 1.2 or above. A recorded TLS 1.1 fails.
- **Certificate Expiry** — dated **and** more than 45 days out. A certificate expiring
  tomorrow is not coverage.
- **Model Card Lineage** — a model card **and** a declared link to the training data. A
  card with no dataset relationship stops the lineage at the weights.
- **License Compliance** — a licence that classifies to something usable, not merely a
  populated field. `NOASSERTION` and bare `LicenseRef-` do not count as cleared.

## What's on the dashboard

- **Gauge + gate** — composite coverage and a pass/conditional/blocked verdict.
- **KPI tiles** — items in scope, licence coverage against a 95% target, undeclared
  licences, obligations attached (strong / weak / restricted), blocking findings. Two more
  appear when a CBOM is loaded: days to next certificate expiry, and quantum-safe algorithm
  ratio. The tile set adapts to what you gave it.
- **Coverage matrix** — BOM type × dimension heatmap, colour intensity scaled to coverage.
- **Per-panel radar** — the five dimensions of each BOM type at a glance, numbered to match
  the rows beneath it.
- **Licence risk distribution** — every licence expression classified as permissive, weak
  copyleft, strong copyleft, use-restricted or undeclared, as a 100% stacked bar.
- **Component mix donut** — libraries, models, datasets, crypto assets, OS packages.
Figures are grouped into a shared overview and then one section per BOM type, so each
chart sits next to the BOM that justifies it. Sections for BOM types you did not load are
not rendered at all.

**Overview (all BOM types)**

- **Arc gauge** — composite readiness with a pass/conditional/blocked gate.
- **KPI tiles with bullet bars** — value, target marker and qualitative bands, so licence
  coverage and PQC readiness are read against where they need to be, not in isolation.
- **Readiness matrix** — BOM type × dimension heatmap.
- **Dumbbell chart** — every dimension plotted as today's dot, the 90% target rule and the
  connector between them, worst first. The connector is the work.
- **Radar per panel** — the five dimensions with the target ring dashed behind them.

**SBOM**

- **Sankey** — every component routed from its ecosystem to the obligation class its terms
  create. Ribbon thickness is component count; the undeclared ribbon is what cannot ship.
- **Treemap** — squarified footprint, tiles grouped by ecosystem and coloured by licence
  risk, so an unresolved cluster is visible as an area rather than a row in a table.
- **CVE triage matrix** — severity against analysis state, with triaged/open counts.

**AIBOM**

- **Arc lineage diagram** — models, the datasets they were trained on and the libraries
  they load on one axis, with arcs for declared relationships. A model with no arc to a
  dataset has no evidenced training-data provenance.
- **Model risk quadrant** — licence permissiveness against evidence completeness, bubble
  size by dataset links, with the blocking quadrant shaded. Reads as a portfolio view.
- **Waffle chart** — one square per percent of models and datasets by strictest term.

**CBOM**

- **Dot plot in risk bands** — every algorithm placed in retired / classical / quantum-safe.
- **Radial bar chart** — algorithms by NIST quantum security level, L0 outward, with the
  quantum-safe ratio in the centre.
- **Expiry horizon** — each certificate as a lollipop on an 18-month runway with 45- and
  120-day risk bands; undated certificates sit on a dashed rail because they cannot be
  scheduled at all.

Everything is hand-drawn SVG and CSS — treemap, sankey and radar included. No chart
library, nothing to fetch, still one file.

## Scoring

Coverage per dimension = share of declared items carrying the required evidence.

| Panel | Dimensions |
|---|---|
| SBOM | purl + version · declared licences · dependency relationships · CVE triage · supplier attribution |
| AIBOM | model metadata · model licences · dataset terms or governance · library licences · provenance references |
| CBOM | algorithm primitives + parameter sets · key size and state · protocol versions · certificate validity windows · NIST quantum security level |

Thresholds: **≥ 90% pass**, **50–89% partial**, **< 50% fail**. Panel coverage is the mean of
its dimensions; composite is the mean across panels. The gate reads **blocked** on any
critical or high finding, **conditional** below 85% composite, **clear** otherwise.

## Licence risk classes

| Class | Matches |
|---|---|
| Permissive | MIT, Apache, BSD, ISC, Zlib, CC0, CC-BY-4.0, CDLA-Permissive |
| Weak copyleft | LGPL, MPL, EPL, CDDL, CC-BY-SA, ODbL |
| Strong copyleft | GPL-2/3, AGPL, SSPL, OSL, EUPL |
| Use-restricted | non-commercial, CC-BY-NC, research-only, RAIL, no-derivatives, bare `LicenseRef-` |
| Undeclared | empty, `NOASSERTION`, `NONE` |

Anything unrecognised falls to use-restricted rather than permissive, so unknown terms
surface instead of quietly passing.

## Extending it

The script is in seven labelled sections: intake and normalisation, licence classification,
classification and evaluators, analysis and KPIs, charts, render, wiring.

- **New format** — write `fromX(raw)` returning the internal model, add a signal to
  `detectFormat()`. Nothing else changes.
- **New dimension** — one `dim(label, short, done, total, wording, sub)` call. Meter, radar
  axis, matrix cell and panel average all follow.
- **New BOM type** (HBOM, SaaSBOM, QBOM) — a rule in `classify()`, an `evalXBOM()` returning
  `{key, title, kind, count, dims, findings}`, and one line in `analyse()`.
- **New KPI** — push `{k, v, d, bar?, tone?}` onto `kpis` in `analyse()`.
- **New figure** — compute its data in `analyse()`, build the markup with one of the chart
  primitives in section 5 (`gauge`, `radar`, `sankey`, `squarify`/`treemapChart`, `waffle`,
  `arcLineage`, `quadrant`, `pqcRadial`, `algoDotPlot`, `expiryHorizon`, `dumbbell`,
  `countMatrix`), then add a `box()` to the relevant section in `render()`.
- **Chart sizing** — each SVG's viewBox is chosen to match the width of the slot it renders
  in, so text lands near its nominal size. Move a figure between a full-width row and a
  column and its viewBox should be resized with it.
- **Licence rules** — the regexes in `licenceClass()`.
- **Thresholds** — the `rate()` helper.

`Export report` writes the whole analysis — sections, dimensions, coverage, KPIs, licence
mix, findings — as JSON for downstream reporting.

To rebuild after editing the samples, re-inline them into the `SAMPLES` constant at the top
of the script.
