#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CBOM Comparison and Analysis Tool
=================================

Desktop utility that parses CycloneDX Cryptography Bills of Materials (CBOM)
produced by:

    1. SCANOSS crypto-finder  (external tool)
    2. Internal CBOM Generator (in-house tool)

and emits one Excel workbook per supplied input:

    SCANOSS_Output.xlsx    ->  Crypto Assets | Occurrences | Asset Name - Properties
    Internal_Output.xlsx   ->  Crypto Assets | Occurrences | Asset Name - Properties

Either input may be omitted; the tool processes whatever is supplied.

Build a single-file Windows executable with:
    pyinstaller --onefile --windowed --name CBOM_Analyzer cbom_analyzer.py

Author: generated for EY SAM / OSS compliance tooling
"""

from __future__ import annotations

import json
import os
import queue
import re
import sys
import threading
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Third-party (bundled into the .exe by PyInstaller)
# ---------------------------------------------------------------------------
try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.worksheet import Worksheet
except ImportError:  # pragma: no cover - surfaced to the user at startup
    Workbook = None  # type: ignore


APP_NAME = "CBOM Comparison & Analysis"
APP_VERSION = "1.0.0"

SHEET_ASSETS = "Crypto Assets"
SHEET_OCCURRENCES = "Occurrences"
SHEET_PROPERTIES = "Asset Name - Properties"  # ':' and '/' are illegal in sheet names

LIBRARY_TYPE = "library"


# ===========================================================================
# 1.  TOLERANT JSON LOADING
# ===========================================================================

_JSON_LITERAL_RE = re.compile(
    r"^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)$"
)
_OBJECT_MEMBER_RE = re.compile(r'^(\s*"(?:[^"\\]|\\.)*"\s*:\s*)(\S.*?)(,?)\s*$')
_ARRAY_ELEMENT_RE = re.compile(r'^(\s*)([^\s"\'{}\[\],:][^,]*?)(,?)\s*$')


class CBOMParseError(Exception):
    """Raised when a CBOM file cannot be read even after repair."""


def repair_json_text(text: str) -> Tuple[str, List[str]]:
    """
    Repair the malformed-JSON patterns commonly seen in hand-edited or
    template-generated CBOM files.

    Currently handles:
      * unquoted scalar values, e.g.  "bom-ref": crypto/algorithm/eddsa@1.3.101.112
      * unquoted array elements
      * UTF-8 BOM, trailing commas, // and /* */ comments

    Returns (repaired_text, list_of_human_readable_fix_descriptions).
    """
    fixes: List[str] = []

    if text.startswith("\ufeff"):
        text = text.lstrip("\ufeff")
        fixes.append("Stripped UTF-8 byte-order mark")

    # -- strip comments (not legal JSON, but tools sometimes emit them) ------
    without_comments, n_comments = re.subn(
        r"/\*.*?\*/", "", text, flags=re.DOTALL
    )
    if n_comments:
        text = without_comments
        fixes.append(f"Removed {n_comments} block comment(s)")

    lines = text.splitlines()
    out_lines: List[str] = []

    for idx, line in enumerate(lines, start=1):
        # line comments, only when the line is entirely a comment
        if line.lstrip().startswith("//"):
            fixes.append(f"Line {idx}: removed line comment")
            continue

        repaired = _repair_line(line)
        if repaired is not None:
            fixes.append(
                f"Line {idx}: quoted unquoted value -> {repaired.strip()[:90]}"
            )
            out_lines.append(repaired)
        else:
            out_lines.append(line)

    text = "\n".join(out_lines)

    # -- trailing commas before a closing brace/bracket ----------------------
    text, n_trailing = re.subn(r",(\s*[}\]])", r"\1", text)
    if n_trailing:
        fixes.append(f"Removed {n_trailing} trailing comma(s)")

    return text, fixes


def _repair_line(line: str) -> Optional[str]:
    """Return a repaired copy of *line*, or None if no repair was needed."""
    match = _OBJECT_MEMBER_RE.match(line)
    if match:
        prefix, value, comma = match.groups()
        fixed = _quote_if_bare(value)
        if fixed is not None:
            return f"{prefix}{fixed}{comma}"
        return None

    match = _ARRAY_ELEMENT_RE.match(line)
    if match:
        indent, value, comma = match.groups()
        fixed = _quote_if_bare(value)
        if fixed is not None:
            return f"{indent}{fixed}{comma}"
    return None


def _quote_if_bare(value: str) -> Optional[str]:
    """Wrap *value* in quotes if it is a bare (unquoted) scalar."""
    value = value.strip()
    if not value:
        return None
    if value[0] in '"{}[]':
        return None
    if _JSON_LITERAL_RE.match(value):
        return None
    return json.dumps(value)


def load_cbom(path: str) -> Tuple[Dict[str, Any], List[str]]:
    """
    Load a CBOM JSON document, repairing common malformations if necessary.

    Returns (document, notes). *notes* describes any repairs performed so the
    caller can surface them to the user - silent repair would hide real
    defects in the generating tool.
    """
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            raw = handle.read()
    except OSError as exc:
        raise CBOMParseError(f"Cannot read file:\n{path}\n\n{exc}") from exc

    if not raw.strip():
        raise CBOMParseError(f"File is empty:\n{path}")

    try:
        return json.loads(raw), []
    except json.JSONDecodeError as first_error:
        repaired, fixes = repair_json_text(raw)
        try:
            document = json.loads(repaired)
        except json.JSONDecodeError as second_error:
            raise CBOMParseError(
                f"'{os.path.basename(path)}' is not valid JSON and could not be "
                f"auto-repaired.\n\n"
                f"Original error : line {first_error.lineno}, "
                f"column {first_error.colno} - {first_error.msg}\n"
                f"After repair   : line {second_error.lineno}, "
                f"column {second_error.colno} - {second_error.msg}"
            ) from second_error

        notes = [
            f"'{os.path.basename(path)}' contained invalid JSON and was "
            f"auto-repaired ({len(fixes)} fix(es)):"
        ]
        notes.extend(f"    - {fix}" for fix in fixes[:25])
        if len(fixes) > 25:
            notes.append(f"    - ...and {len(fixes) - 25} more")
        return document, notes


# ===========================================================================
# 2.  SAFE ACCESSORS
# ===========================================================================


def dig(source: Any, *keys: str, default: Any = None) -> Any:
    """Walk nested dicts safely: dig(comp, 'cryptoProperties', 'oid')."""
    current = source
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    return current if current is not None else default


def as_text(value: Any, separator: str = ", ") -> str:
    """Flatten a CycloneDX value into something a spreadsheet cell can hold."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        return separator.join(as_text(item, separator) for item in value if item is not None)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def coerce_cell(value: Any, separator: str = ", ") -> Any:
    """
    Convert a CycloneDX value into something openpyxl can write with the
    correct Excel type: numbers stay numeric, booleans stay boolean, strings
    stay text, lists become comma-joined text, dicts become JSON, None
    becomes an empty string.

    Use this whenever a cell might hold a number (e.g. classicalSecurityLevel,
    nistQuantumSecurityLevel, key size, timestamps as epoch). Using `as_text`
    for these fields is what causes Excel's "number stored as text" warning.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)):
        parts = [
            str(coerce_cell(item, separator))
            for item in value
            if item is not None and item != ""
        ]
        return separator.join(parts)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def component_list(document: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return the top-level components array, flattening nested components."""
    collected: List[Dict[str, Any]] = []

    def walk(items: Any) -> None:
        if not isinstance(items, list):
            return
        for item in items:
            if isinstance(item, dict):
                collected.append(item)
                walk(item.get("components"))

    walk(document.get("components"))
    return collected


# ===========================================================================
# 3.  EXTRACTION MODEL
# ===========================================================================


@dataclass
class SheetData:
    """A single output sheet: ordered headers plus row dictionaries."""

    name: str
    headers: List[str]
    rows: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ExtractionResult:
    label: str                       # "SCANOSS" / "Internal"
    output_filename: str
    sheets: List[SheetData]
    removed_libraries: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def total_rows(self) -> int:
        return sum(len(sheet.rows) for sheet in self.sheets)


# --------------------------------------------------------------------------
# 3a.  SCANOSS
# --------------------------------------------------------------------------

SCANOSS_ASSET_HEADERS = [
    "bom-ref",
    "type",
    "name",
    "description",
    "assetType",
    "primitive",
    "parameterSetIdentifier",
    "executionEnvironment",
    "implementationPlatform",
    "cryptoFunctions",
    "oid",
    "relatedCryptoMaterialType",
    "scanossCryptoFunction",
    "Occurrence Count",
    "Identity Evidence Count",
]

SCANOSS_OCCURRENCE_HEADERS = [
    "Asset Name",
    "bom-ref",
    "Location",
    "Line",
    "Additional Context",
]

SCANOSS_IDENTITY_HEADERS = [
    "Asset Name",
    "bom-ref",
    "Field",
    "Identity Confidence",
    "Technique",
    "Method Confidence",
    "Method Value",
]


def extract_scanoss(document: Dict[str, Any]) -> ExtractionResult:
    """Build the three SCANOSS sheets from a parsed CycloneDX document."""
    assets = SheetData(SHEET_ASSETS, list(SCANOSS_ASSET_HEADERS))
    occurrences = SheetData(SHEET_OCCURRENCES, list(SCANOSS_OCCURRENCE_HEADERS))
    identity = SheetData(SHEET_PROPERTIES, list(SCANOSS_IDENTITY_HEADERS))

    removed_refs: set = set()
    removed_names: set = set()
    removed_labels: List[str] = []

    for component in component_list(document):
        comp_type = coerce_cell(component.get("type")).strip()
        bom_ref = coerce_cell(component.get("bom-ref"))
        name = coerce_cell(component.get("name"))

        # ---- filtering rule: drop libraries entirely ----------------------
        if comp_type.lower() == LIBRARY_TYPE:
            if bom_ref:
                removed_refs.add(bom_ref)
            if name:
                removed_names.add(name)
            removed_labels.append(f"{name or '(unnamed)'} [{bom_ref or 'no bom-ref'}]")
            continue

        crypto = component.get("cryptoProperties") or {}
        algorithm = crypto.get("algorithmProperties") or {}
        evidence = component.get("evidence") or {}
        occurrence_items = evidence.get("occurrences") or []
        identity_items = evidence.get("identity") or []

        scanoss_functions = [
            coerce_cell(prop.get("value"))
            for prop in (component.get("properties") or [])
            if isinstance(prop, dict)
            and coerce_cell(prop.get("name")).lower() == "scanoss:cryptofunction"
        ]

        assets.rows.append(
            {
                "bom-ref": bom_ref,
                "type": comp_type,
                "name": name,
                "description": coerce_cell(component.get("description")),
                "assetType": coerce_cell(crypto.get("assetType")),
                "primitive": coerce_cell(algorithm.get("primitive")),
                "parameterSetIdentifier": coerce_cell(algorithm.get("parameterSetIdentifier")),
                "executionEnvironment": coerce_cell(algorithm.get("executionEnvironment")),
                "implementationPlatform": coerce_cell(algorithm.get("implementationPlatform")),
                "cryptoFunctions": coerce_cell(algorithm.get("cryptoFunctions")),
                "oid": coerce_cell(crypto.get("oid")),
                "relatedCryptoMaterialType": coerce_cell(
                    dig(crypto, "relatedCryptoMaterialProperties", "type")
                ),
                "scanossCryptoFunction": coerce_cell(scanoss_functions),
                "Occurrence Count": len(occurrence_items),
                "Identity Evidence Count": len(identity_items),
            }
        )

        for occurrence in occurrence_items:
            if not isinstance(occurrence, dict):
                continue
            occurrences.rows.append(
                {
                    "Asset Name": name,
                    "bom-ref": bom_ref,
                    "Location": coerce_cell(occurrence.get("location")),
                    "Line": occurrence.get("line", ""),
                    "Additional Context": coerce_cell(occurrence.get("additionalContext")),
                }
            )

        for entry in identity_items:
            if not isinstance(entry, dict):
                continue
            methods = entry.get("methods") or []
            if not methods:
                identity.rows.append(
                    {
                        "Asset Name": name,
                        "bom-ref": bom_ref,
                        "Field": coerce_cell(entry.get("field")),
                        "Identity Confidence": entry.get("confidence", ""),
                        "Technique": "",
                        "Method Confidence": "",
                        "Method Value": "",
                    }
                )
                continue
            for method in methods:
                if not isinstance(method, dict):
                    continue
                identity.rows.append(
                    {
                        "Asset Name": name,
                        "bom-ref": bom_ref,
                        "Field": coerce_cell(entry.get("field")),
                        "Identity Confidence": entry.get("confidence", ""),
                        "Technique": coerce_cell(method.get("technique")),
                        "Method Confidence": method.get("confidence", ""),
                        "Method Value": coerce_cell(method.get("value")),
                    }
                )

    _drop_orphans(occurrences, "Asset Name", removed_refs, removed_names)
    _drop_orphans(identity, "Asset Name", removed_refs, removed_names)

    return ExtractionResult(
        label="SCANOSS",
        output_filename="SCANOSS_Output.xlsx",
        sheets=[assets, occurrences, identity],
        removed_libraries=removed_labels,
    )


# --------------------------------------------------------------------------
# 3b.  INTERNAL TOOL
# --------------------------------------------------------------------------

INTERNAL_ASSET_HEADERS = [
    "bom-ref",
    "Type",
    "Group",
    "Name",
    "Version",
    "Description",
    "PURL",
    "Crypto Asset Type",
    "Primitive",
    "Parameter Set",
    "Execution Environment",
    "Implementation Platform",
    "Crypto Functions",
    "OID",
    "Related Material Type",
    "Protocol Type",
    "Certificate Subject",
    "Occurrence Count",
    "Property Count",
]

INTERNAL_OCCURRENCE_HEADERS = [
    "Component",
    "bom-ref",
    "Location",
    "Line",
    "Offset",
    "Additional Context",
]

INTERNAL_PROPERTY_HEADERS = [
    "Component",
    "bom-ref",
    "Property Name",
    "Property Value",
]


def extract_internal(document: Dict[str, Any]) -> ExtractionResult:
    """Build the three Internal-tool sheets from a parsed CycloneDX document."""
    assets = SheetData(SHEET_ASSETS, list(INTERNAL_ASSET_HEADERS))
    occurrences = SheetData(SHEET_OCCURRENCES, list(INTERNAL_OCCURRENCE_HEADERS))
    properties = SheetData(SHEET_PROPERTIES, list(INTERNAL_PROPERTY_HEADERS))

    removed_refs: set = set()
    removed_names: set = set()
    removed_labels: List[str] = []

    for component in component_list(document):
        comp_type = coerce_cell(component.get("type")).strip()
        bom_ref = coerce_cell(component.get("bom-ref"))
        name = coerce_cell(component.get("name"))

        if comp_type.lower() == LIBRARY_TYPE:
            if bom_ref:
                removed_refs.add(bom_ref)
            if name:
                removed_names.add(name)
            removed_labels.append(f"{name or '(unnamed)'} [{bom_ref or 'no bom-ref'}]")
            continue

        crypto = component.get("cryptoProperties") or {}
        algorithm = crypto.get("algorithmProperties") or {}
        evidence = component.get("evidence") or {}
        occurrence_items = evidence.get("occurrences") or []
        property_items = [
            prop for prop in (component.get("properties") or []) if isinstance(prop, dict)
        ]

        assets.rows.append(
            {
                "bom-ref": bom_ref,
                "Type": comp_type,
                "Group": coerce_cell(component.get("group")),
                "Name": name,
                "Version": coerce_cell(component.get("version")),
                "Description": coerce_cell(component.get("description")),
                "PURL": coerce_cell(component.get("purl")),
                "Crypto Asset Type": coerce_cell(crypto.get("assetType")),
                "Primitive": coerce_cell(algorithm.get("primitive")),
                "Parameter Set": coerce_cell(algorithm.get("parameterSetIdentifier")),
                "Execution Environment": coerce_cell(algorithm.get("executionEnvironment")),
                "Implementation Platform": coerce_cell(algorithm.get("implementationPlatform")),
                "Crypto Functions": coerce_cell(algorithm.get("cryptoFunctions")),
                "OID": coerce_cell(crypto.get("oid")),
                "Related Material Type": coerce_cell(
                    dig(crypto, "relatedCryptoMaterialProperties", "type")
                ),
                "Protocol Type": coerce_cell(dig(crypto, "protocolProperties", "type")),
                "Certificate Subject": coerce_cell(
                    dig(crypto, "certificateProperties", "subjectName")
                ),
                "Occurrence Count": len(occurrence_items),
                "Property Count": len(property_items),
            }
        )

        for occurrence in occurrence_items:
            if not isinstance(occurrence, dict):
                continue
            occurrences.rows.append(
                {
                    "Component": name,
                    "bom-ref": bom_ref,
                    "Location": coerce_cell(occurrence.get("location")),
                    "Line": occurrence.get("line", ""),
                    "Offset": occurrence.get("offset", ""),
                    "Additional Context": coerce_cell(occurrence.get("additionalContext")),
                }
            )

        for prop in property_items:
            properties.rows.append(
                {
                    "Component": name,
                    "bom-ref": bom_ref,
                    "Property Name": coerce_cell(prop.get("name")),
                    "Property Value": coerce_cell(prop.get("value")),
                }
            )

    _drop_orphans(occurrences, "Component", removed_refs, removed_names)
    _drop_orphans(properties, "Component", removed_refs, removed_names)

    return ExtractionResult(
        label="Internal",
        output_filename="Internal_Output.xlsx",
        sheets=[assets, occurrences, properties],
        removed_libraries=removed_labels,
    )


def _drop_orphans(
    sheet: SheetData,
    name_column: str,
    removed_refs: set,
    removed_names: set,
) -> None:
    """Remove rows belonging to components filtered out of the assets sheet."""
    if not removed_refs and not removed_names:
        return
    sheet.rows = [
        row
        for row in sheet.rows
        if row.get("bom-ref") not in removed_refs
        and row.get(name_column) not in removed_names
    ]


# --------------------------------------------------------------------------
# 3c.  Format detection (advisory only)
# --------------------------------------------------------------------------


def detect_flavour(document: Dict[str, Any]) -> str:
    """Guess whether a document came from SCANOSS or the internal generator."""
    blob = json.dumps(document.get("metadata", {}), ensure_ascii=False).lower()
    if "scanoss" in blob or "crypto-finder" in blob:
        return "SCANOSS"
    if "cbom-generator" in blob or "cbom:" in json.dumps(
        document.get("components", []), ensure_ascii=False
    )[:20000].lower():
        return "Internal"
    for component in component_list(document):
        for prop in component.get("properties") or []:
            if isinstance(prop, dict):
                prop_name = as_text(prop.get("name")).lower()
                if prop_name.startswith("scanoss:"):
                    return "SCANOSS"
                if prop_name.startswith("cbom:"):
                    return "Internal"
    return "Unknown"


# ===========================================================================
# 3d.  CERT-In CBOM TABLE MODEL
# ===========================================================================
#
# CERT-In's "Technical Guidelines on SBOM, QBOM, CBOM, AIBOM and HBOM"
# expresses a CBOM as four tables, one per cryptographic asset type.
# The column sets below reproduce those tables exactly.
#
# ---------------------------------------------------------------------------
# ASSUMPTION - please confirm before using this for a client deliverable.
#
# The last column of the CERT-In "Algorithms" table reads "List" in the source
# screenshot. There is no CycloneDX algorithmProperties field of that name.
# It sits immediately after "Classical security level", whose natural
# CycloneDX companion is `nistQuantumSecurityLevel`, so that is what this tool
# populates it with. If CERT-In means something else, change the single
# extractor on ALGORITHM_LIST_COLUMN below - nothing else needs to move.
# ---------------------------------------------------------------------------

ALGORITHM_LIST_COLUMN = "List"
ALGORITHM_LIST_SOURCE = "cryptoProperties.algorithmProperties.nistQuantumSecurityLevel"
ALGORITHM_LIST_ASSUMED = True  # set False once the header is confirmed


@dataclass(frozen=True)
class CertInField:
    """One column of a CERT-In table."""

    label: str
    source: str                                   # documented CycloneDX path
    extract: Callable[[Dict[str, Any]], Any]


@dataclass(frozen=True)
class CertInTable:
    """One of the four CERT-In cryptographic asset tables."""

    name: str
    asset_types: Tuple[str, ...]
    fields: Tuple[CertInField, ...]

    @property
    def labels(self) -> List[str]:
        return [field_.label for field_ in self.fields]


def _algo(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "algorithmProperties", *path)


def _material(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "relatedCryptoMaterialProperties", *path)


def _protocol(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "protocolProperties", *path)


def _certificate(*path: str) -> Callable[[Dict[str, Any]], Any]:
    return lambda comp: dig(comp, "cryptoProperties", "certificateProperties", *path)


def _cipher_suites(comp: Dict[str, Any]) -> str:
    """protocolProperties.cipherSuites[] is an array of objects, not strings."""
    suites = dig(comp, "cryptoProperties", "protocolProperties", "cipherSuites", default=[])
    if not isinstance(suites, list):
        return as_text(suites)
    names: List[str] = []
    for suite in suites:
        if isinstance(suite, dict):
            names.append(as_text(suite.get("name") or suite.get("identifiers")))
        else:
            names.append(as_text(suite))
    return ", ".join(name for name in names if name)


_NAME = CertInField("Name", "component.name", lambda comp: comp.get("name"))
_ASSET_TYPE = CertInField(
    "Asset Type", "cryptoProperties.assetType",
    lambda comp: dig(comp, "cryptoProperties", "assetType"),
)
_OID = CertInField("OID", "cryptoProperties.oid", lambda comp: dig(comp, "cryptoProperties", "oid"))


CERTIN_TABLES: Tuple[CertInTable, ...] = (
    CertInTable(
        name="Algorithms",
        asset_types=("algorithm",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField("Primitive", "algorithmProperties.primitive", _algo("primitive")),
            CertInField("Mode", "algorithmProperties.mode", _algo("mode")),
            CertInField(
                "Crypto Functions", "algorithmProperties.cryptoFunctions",
                _algo("cryptoFunctions"),
            ),
            CertInField(
                "Classical security level", "algorithmProperties.classicalSecurityLevel",
                _algo("classicalSecurityLevel"),
            ),
            _OID,
            CertInField(
                ALGORITHM_LIST_COLUMN,
                ALGORITHM_LIST_SOURCE + (" (ASSUMED)" if ALGORITHM_LIST_ASSUMED else ""),
                _algo("nistQuantumSecurityLevel"),
            ),
        ),
    ),
    CertInTable(
        name="Keys",
        asset_types=("related-crypto-material",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField("id", "relatedCryptoMaterialProperties.id", _material("id")),
            CertInField("state", "relatedCryptoMaterialProperties.state", _material("state")),
            CertInField("size", "relatedCryptoMaterialProperties.size", _material("size")),
            CertInField(
                "Creation Date", "relatedCryptoMaterialProperties.creationDate",
                _material("creationDate"),
            ),
            CertInField(
                "Activation Date", "relatedCryptoMaterialProperties.activationDate",
                _material("activationDate"),
            ),
        ),
    ),
    CertInTable(
        name="Protocols",
        asset_types=("protocol",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField("Version", "protocolProperties.version", _protocol("version")),
            CertInField("Cipher Suites", "protocolProperties.cipherSuites[].name", _cipher_suites),
            _OID,
        ),
    ),
    CertInTable(
        name="Certificates",
        asset_types=("certificate",),
        fields=(
            _NAME,
            _ASSET_TYPE,
            CertInField(
                "Subject Name", "certificateProperties.subjectName", _certificate("subjectName")
            ),
            CertInField(
                "Issuer Name", "certificateProperties.issuerName", _certificate("issuerName")
            ),
            CertInField(
                "Not Valid Before", "certificateProperties.notValidBefore",
                _certificate("notValidBefore"),
            ),
            CertInField(
                "Not Valid After", "certificateProperties.notValidAfter",
                _certificate("notValidAfter"),
            ),
            CertInField(
                "Signature Algorithm Reference", "certificateProperties.signatureAlgorithmRef",
                _certificate("signatureAlgorithmRef"),
            ),
            CertInField(
                "Subject Public Key Reference", "certificateProperties.subjectPublicKeyRef",
                _certificate("subjectPublicKeyRef"),
            ),
            CertInField(
                "Certificate Format", "certificateProperties.certificateFormat",
                _certificate("certificateFormat"),
            ),
            CertInField(
                "Certificate Extension", "certificateProperties.certificateExtension",
                _certificate("certificateExtension"),
            ),
        ),
    ),
)

CERTIN_MAX_COLUMNS = max(len(table.fields) for table in CERTIN_TABLES)


@dataclass
class CertInExtraction:
    """CERT-In view of one tool's CBOM (or a placeholder when none supplied)."""

    label: str                                  # "SCANOSS" / "Internal"
    source_file: str = ""
    supplied: bool = False
    tables: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    unclassified: List[str] = field(default_factory=list)

    def rows_for(self, table_name: str) -> List[Dict[str, Any]]:
        return self.tables.get(table_name, [])


def is_populated(value: Any) -> bool:
    """A field counts as captured when it carries a real value (0 counts)."""
    if value is None:
        return False
    if isinstance(value, (list, tuple, dict)):
        return len(value) > 0
    return str(value).strip() != ""


def build_certin_extraction(
    label: str, document: Dict[str, Any], source_file: str
) -> CertInExtraction:
    """Project a CycloneDX CBOM onto the four CERT-In tables."""
    extraction = CertInExtraction(
        label=label,
        source_file=source_file,
        supplied=True,
        tables={table.name: [] for table in CERTIN_TABLES},
    )

    by_asset_type: Dict[str, CertInTable] = {}
    for table in CERTIN_TABLES:
        for asset_type in table.asset_types:
            by_asset_type[asset_type] = table

    for component in component_list(document):
        if as_text(component.get("type")).strip().lower() == LIBRARY_TYPE:
            continue

        asset_type = as_text(dig(component, "cryptoProperties", "assetType")).strip().lower()
        table = by_asset_type.get(asset_type)
        if table is None:
            extraction.unclassified.append(
                f"{as_text(component.get('name')) or '(unnamed)'} "
                f"(assetType='{asset_type or 'absent'}')"
            )
            continue

        extraction.tables[table.name].append(
            {field_.label: coerce_cell(field_.extract(component)) for field_ in table.fields}
        )

    return extraction


# --------------------------------------------------------------------------
# Field-capture coverage
# --------------------------------------------------------------------------


@dataclass
class CoverageRow:
    table: str
    tool: str
    status: str
    records: Any
    total_fields: int
    captured: Any
    not_captured: Any
    percentage: Any
    captured_fields: str
    missing_fields: str


def compute_coverage(
    table: CertInTable, extraction: CertInExtraction
) -> Tuple[CoverageRow, Dict[str, int]]:
    """
    Count how many CERT-In fields the tool actually populates.

    A field is 'captured' when at least one record carries a value for it.
    Also returns the per-field populated-record counts.
    """
    rows = extraction.rows_for(table.name)
    per_field = {
        field_.label: sum(1 for row in rows if is_populated(row.get(field_.label)))
        for field_ in table.fields
    }
    total = len(table.fields)

    if not extraction.supplied:
        return (
            CoverageRow(
                table=table.name,
                tool=extraction.label,
                status="File not supplied",
                records="-",
                total_fields=total,
                captured="-",
                not_captured="-",
                percentage="-",
                captured_fields="-",
                missing_fields="-",
            ),
            per_field,
        )

    captured = [label for label, count in per_field.items() if count > 0]
    missing = [label for label, count in per_field.items() if count == 0]

    if not rows:
        status = "No assets of this type"
    elif not missing:
        status = "Fully captured"
    elif not captured:
        status = "Not captured"
    else:
        status = "Partially captured"

    return (
        CoverageRow(
            table=table.name,
            tool=extraction.label,
            status=status,
            records=len(rows),
            total_fields=total,
            captured=len(captured),
            not_captured=len(missing),
            percentage=round(len(captured) / total * 100, 1) if total else 0.0,
            captured_fields=", ".join(captured) if captured else "-",
            missing_fields=", ".join(missing) if missing else "-",
        ),
        per_field,
    )




# ===========================================================================
# 3e.  CROSS-TOOL COMPARISON  (name-matched, used by the dashboard)
# ===========================================================================
#
# SCANOSS bom-refs are UUIDs; the Internal tool's are `crypto/algorithm/x@id`.
# The two schemes share no identifier space, so matching across tools is done
# on normalised asset name. This is a deliberate, visible assumption - stated
# here once and surfaced on the dashboard itself, not buried in a diff.


def normalise_name(name: Any) -> str:
    """Case/whitespace-insensitive key used to match assets across tools."""
    return re.sub(r"\s+", " ", as_text(name)).strip().lower()


@dataclass
class NameComparison:
    both: List[Dict[str, Any]] = field(default_factory=list)
    only_a: List[Dict[str, Any]] = field(default_factory=list)   # in first tool only
    only_b: List[Dict[str, Any]] = field(default_factory=list)   # in second tool only

    def counts(self) -> Dict[str, int]:
        return {
            "both": len(self.both),
            "only_a": len(self.only_a),
            "only_b": len(self.only_b),
            "total_a": len(self.both) + len(self.only_a),
            "total_b": len(self.both) + len(self.only_b),
        }


def compare_by_name(
    rows_a: List[Dict[str, Any]],
    rows_b: List[Dict[str, Any]],
    name_field_a: str,
    name_field_b: str,
) -> NameComparison:
    """Match two row lists by normalised name and bucket into both/only_a/only_b."""
    index_b: Dict[str, Dict[str, Any]] = {}
    for row in rows_b:
        key = normalise_name(row.get(name_field_b))
        if key:
            index_b.setdefault(key, row)

    result = NameComparison()
    seen_b: set = set()

    for row in rows_a:
        key = normalise_name(row.get(name_field_a))
        if key and key in index_b:
            result.both.append({"name": row.get(name_field_a), "key": key})
            seen_b.add(key)
        else:
            result.only_a.append({"name": row.get(name_field_a), "key": key})

    for row in rows_b:
        key = normalise_name(row.get(name_field_b))
        if key and key not in seen_b:
            result.only_b.append({"name": row.get(name_field_b), "key": key})

    return result


# ===========================================================================
# 3f.  DASHBOARD DATA  (single JSON contract consumed by CBOM_Dashboard.html)
# ===========================================================================

DASHBOARD_JSON_FILENAME = "dashboard_data.json"
DASHBOARD_HTML_FILENAME = "CBOM_Dashboard.html"
DASHBOARD_SCHEMA_VERSION = 2


def build_dashboard_data(
    scanoss_result: Optional[ExtractionResult],
    internal_result: Optional[ExtractionResult],
    scanoss_certin: Optional[CertInExtraction],
    internal_certin: Optional[CertInExtraction],
    scanoss_source: str,
    internal_source: str,
) -> Dict[str, Any]:
    """
    Distil everything the dashboard needs into one small, self-describing
    JSON document. No raw CycloneDX passes through here - only the derived
    figures already computed by the extractors above, so the browser never
    re-implements any parsing or matching logic.
    """
    supplied_scanoss = scanoss_result is not None
    supplied_internal = internal_result is not None

    def crypto_asset_rows(result: Optional[ExtractionResult]) -> List[Dict[str, Any]]:
        if result is None:
            return []
        for sheet in result.sheets:
            if sheet.name == SHEET_ASSETS:
                return sheet.rows
        return []

    scanoss_assets = crypto_asset_rows(scanoss_result)
    internal_assets = crypto_asset_rows(internal_result)

    asset_comparison = compare_by_name(
        scanoss_assets, internal_assets, "name", "Name"
    )
    asset_counts = {
        "scanoss_total": len(scanoss_assets),
        "internal_total": len(internal_assets),
        **asset_comparison.counts(),
    }
    efficiency = _compute_efficiency(asset_counts)
    primitive_distribution = {
        "scanoss": _primitive_distribution(scanoss_assets, "primitive"),
        "internal": _primitive_distribution(internal_assets, "Primitive"),
    }
    scan_composition = {
        "scanoss": _scan_composition(scanoss_result),
        "internal": _scan_composition(internal_result),
    }
    occurrence_distribution = {
        "scanoss": _occurrence_distribution(scanoss_assets),
        "internal": _occurrence_distribution(internal_assets),
    }

    # ---- CERT-In: component-wise + field-wise, per table -----------------
    certin_tables: Dict[str, Any] = {}
    scanoss_certin = scanoss_certin or CertInExtraction(label="SCANOSS")
    internal_certin = internal_certin or CertInExtraction(label="Internal")
    classified_scanoss_total = 0
    classified_internal_total = 0

    for table in CERTIN_TABLES:
        s_rows = scanoss_certin.rows_for(table.name)
        i_rows = internal_certin.rows_for(table.name)
        classified_scanoss_total += len(s_rows)
        classified_internal_total += len(i_rows)
        component_diff = compare_by_name(s_rows, i_rows, "Name", "Name")

        s_coverage, s_fields = compute_coverage(table, scanoss_certin)
        i_coverage, i_fields = compute_coverage(table, internal_certin)

        certin_tables[table.name] = {
            "columns": table.labels,
            "components": {
                "both": [item["name"] for item in component_diff.both],
                "scanoss_only": [item["name"] for item in component_diff.only_a],
                "internal_only": [item["name"] for item in component_diff.only_b],
                "counts": component_diff.counts(),
            },
            "field_coverage": {
                "scanoss": _coverage_to_dict(s_coverage, s_fields, supplied_scanoss),
                "internal": _coverage_to_dict(i_coverage, i_fields, supplied_internal),
            },
        }

    overall = {
        "scanoss": _overall_coverage(scanoss_certin, supplied_scanoss),
        "internal": _overall_coverage(internal_certin, supplied_internal),
    }
    classification_coverage = {
        "scanoss": _classification_coverage(
            classified_scanoss_total, len(scanoss_certin.unclassified), supplied_scanoss
        ),
        "internal": _classification_coverage(
            classified_internal_total, len(internal_certin.unclassified), supplied_internal
        ),
    }

    return {
        "schemaVersion": DASHBOARD_SCHEMA_VERSION,
        "generated": datetime.now().isoformat(timespec="seconds"),
        "sources": {
            "scanoss": os.path.basename(scanoss_source) if supplied_scanoss else None,
            "internal": os.path.basename(internal_source) if supplied_internal else None,
        },
        "assumptions": [
            "Assets are matched across tools by normalised name (case/whitespace-"
            "insensitive) because SCANOSS bom-refs are UUIDs and the Internal tool's "
            "are structured refs (crypto/algorithm/name@id) - the two identifier "
            "schemes do not overlap.",
            "Components of type 'library' are excluded from every count on this "
            "dashboard, matching the filtering rule used in the detail workbooks.",
            f"The CERT-In Algorithms table's 'List' column has no corresponding "
            f"CycloneDX field; it is populated from "
            f"{ALGORITHM_LIST_SOURCE} as a stated assumption "
            f"({'still unconfirmed' if ALGORITHM_LIST_ASSUMED else 'confirmed'}).",
            "'Occurrence count' buckets the number of source-code locations "
            "citing each asset - more occurrences means broader use in the "
            "codebase, not higher confidence in the finding itself.",
        ],
        "assetComparison": {
            "counts": asset_counts,
            "efficiency": efficiency,
            "primitiveDistribution": primitive_distribution,
            "scanComposition": scan_composition,
            "occurrenceDistribution": occurrence_distribution,
            "both": sorted({item["name"] for item in asset_comparison.both}, key=str.lower),
            "scanoss_only": sorted(
                {item["name"] for item in asset_comparison.only_a}, key=str.lower
            ),
            "internal_only": sorted(
                {item["name"] for item in asset_comparison.only_b}, key=str.lower
            ),
        },
        "certIn": {
            "tables": certin_tables,
            "overall": overall,
            "classificationCoverage": classification_coverage,
        },
    }


def _compute_efficiency(counts: Dict[str, int]) -> Dict[str, Any]:
    """
    Two distinct 'how good is each tool' views, both derived purely from
    counts already computed - no re-scanning, no new matching pass:

    - coverage_pct   : of every asset either tool found (the union), what
                       share did THIS tool find on its own? Answers
                       "how much of the combined picture does this tool see".
    - cross_validation_pct : of what THIS tool found, what share did the
                       OTHER tool also confirm? Answers "how much of this
                       tool's output is corroborated independently".

    Neither metric assumes either tool is a ground truth - they are simply
    two different lenses on the same three counts (both / only_a / only_b).
    """
    both = counts.get("both", 0)
    scanoss_total = counts.get("scanoss_total", 0)
    internal_total = counts.get("internal_total", 0)
    union = both + counts.get("only_a", 0) + counts.get("only_b", 0)

    def pct(numerator: int, denominator: int) -> float:
        return round(numerator / denominator * 100, 1) if denominator else 0.0

    return {
        "union_total": union,
        "scanoss_coverage_pct": pct(scanoss_total, union),
        "internal_coverage_pct": pct(internal_total, union),
        "scanoss_cross_validation_pct": pct(both, scanoss_total),
        "internal_cross_validation_pct": pct(both, internal_total),
    }


def _primitive_distribution(
    rows: List[Dict[str, Any]], field_name: str, top_n: int = 6
) -> List[Dict[str, Any]]:
    """
    Count assets per cryptographic primitive (ae, kdf, signature, hash, ...)
    without naming individual assets - the category breakdown a chart can
    show cleanly, keeping the long name lists optional/on-demand instead of
    the default view.
    """
    counter: Dict[str, int] = {}
    for row in rows:
        key = as_text(row.get(field_name)).strip() or "(unspecified)"
        counter[key] = counter.get(key, 0) + 1

    ranked = sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))
    top = ranked[:top_n]
    remainder = sum(count for _, count in ranked[top_n:])
    result = [{"label": label, "count": count} for label, count in top]
    if remainder:
        result.append({"label": "Other", "count": remainder})
    return result


def _scan_composition(result: Optional[ExtractionResult]) -> Dict[str, Any]:
    """
    How much of what was scanned is actually cryptographic vs. library
    components filtered out - context for the headline asset counts.
    """
    if result is None:
        return {"supplied": False, "crypto_assets": 0, "library_components": 0, "total": 0}
    crypto = result.total_rows and next(
        (len(sheet.rows) for sheet in result.sheets if sheet.name == SHEET_ASSETS), 0
    )
    libraries = len(result.removed_libraries)
    return {
        "supplied": True,
        "crypto_assets": crypto,
        "library_components": libraries,
        "total": crypto + libraries,
    }


_OCCURRENCE_BUCKETS = [(1, 1, "1"), (2, 5, "2\u20135"), (6, 10, "6\u201310"), (11, None, "11+")]


def _occurrence_distribution(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Bucket assets by how many source-code locations reference them, without
    naming individual assets - shows detection depth/breadth per tool.
    """
    counts = {label: 0 for _, _, label in _OCCURRENCE_BUCKETS}
    for row in rows:
        try:
            occurrences = int(row.get("Occurrence Count", 0) or 0)
        except (TypeError, ValueError):
            occurrences = 0
        for low, high, label in _OCCURRENCE_BUCKETS:
            if occurrences >= low and (high is None or occurrences <= high):
                counts[label] += 1
                break
    return [{"bucket": label, "count": counts[label]} for _, _, label in _OCCURRENCE_BUCKETS]


def _classification_coverage(classified: int, unclassified: int, supplied: bool) -> Dict[str, Any]:
    """
    Of the non-library crypto assets a tool found, how many could actually be
    placed into one of the four CERT-In tables (recognised assetType) versus
    left unclassified - directly relevant to CERT-In readiness.
    """
    total = classified + unclassified
    return {
        "supplied": supplied,
        "classified": classified if supplied else 0,
        "unclassified": unclassified if supplied else 0,
        "total": total if supplied else 0,
        "percentage": round(classified / total * 100, 1) if supplied and total else 0,
    }


def _coverage_to_dict(
    coverage: CoverageRow, per_field: Dict[str, int], supplied: bool
) -> Dict[str, Any]:
    return {
        "supplied": supplied,
        "status": coverage.status,
        "records": coverage.records if supplied else 0,
        "totalFields": coverage.total_fields,
        "captured": coverage.captured if supplied else 0,
        "percentage": coverage.percentage if supplied else 0,
        "fields": {label: count > 0 for label, count in per_field.items()} if supplied else {},
    }


def _overall_coverage(extraction: CertInExtraction, supplied: bool) -> Dict[str, Any]:
    if not supplied:
        return {"supplied": False, "captured": 0, "total": 0, "percentage": 0, "records": 0}
    captured = total = records = 0
    for table in CERTIN_TABLES:
        coverage, _ = compute_coverage(table, extraction)
        captured += int(coverage.captured)
        total += coverage.total_fields
        records += int(coverage.records)
    return {
        "supplied": True,
        "captured": captured,
        "total": total,
        "percentage": round(captured / total * 100, 1) if total else 0,
        "records": records,
    }


def write_dashboard_json(data: Dict[str, Any], output_dir: str) -> str:
    destination = os.path.join(output_dir, DASHBOARD_JSON_FILENAME)
    try:
        with open(destination, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, ensure_ascii=False)
    except OSError as exc:
        raise RuntimeError(f"Cannot write '{DASHBOARD_JSON_FILENAME}':\n\n{exc}") from exc
    return destination


DASHBOARD_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CBOM Comparative Dashboard — OSS Nexus</title>
<style>
  :root{
    --blue:#2563EB; --blue-dark:#1D4ED8; --blue-light:#93C5FD;
    --ink:#0F172A; --bg:#F8FAFC; --card:#FFFFFF;
    --border:#E2E8F0; --border-blue:#DBEAFE; --muted:#64748B;
    --green:#16A34A; --green-bg:#DCFCE7;
    --amber:#C2410C; --amber-bg:#FFEDD5;
    --red:#DC2626; --red-bg:#FEE2E2;
    --indigo:#4338CA; --indigo-bg:#E0E7FF;
    --navy:#0F172A;
    --radius:14px;
    --mono: ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
    --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Roboto, sans-serif;
  }
  *{box-sizing:border-box;}
  body{margin:0; background:var(--bg); color:var(--ink); font-family:var(--sans); -webkit-font-smoothing:antialiased;}
  .wrap{max-width:1220px; margin:0 auto; padding:26px 20px 70px;}

  header.top{display:flex; align-items:flex-start; justify-content:space-between; gap:20px; margin-bottom:18px; flex-wrap:wrap;}
  .brand{display:flex; align-items:baseline; gap:8px; font-weight:800; font-size:22px;}
  .brand .oss{color:var(--blue);}
  .brand .nexus{color:var(--ink);}
  .brand .tag{font-family:var(--mono); font-size:11px; font-weight:600; letter-spacing:.06em;
    color:var(--muted); text-transform:uppercase; margin-left:6px; padding:3px 8px;
    border:1px solid var(--border); border-radius:999px;}

  .upload-box{display:flex; align-items:center; gap:10px; background:var(--card);
    border:1px solid var(--border-blue); border-radius:10px; padding:10px 14px; font-size:12.5px;}
  .upload-box .btn{
    font-family:var(--sans); font-size:12.5px; font-weight:700; padding:7px 14px;
    border-radius:8px; border:1px solid var(--blue); background:var(--blue); color:#fff; cursor:pointer;
  }
  .upload-box .btn.secondary{background:#fff; color:var(--ink); border-color:var(--border);}
  #fileInput{display:none;}
  #uploadStatus{font-size:12px; margin-top:4px;}
  #uploadStatus.ok{color:var(--green);}
  #uploadStatus.err{color:var(--red);}

  h1.title{font-size:25px; margin:4px 0 4px; font-weight:800;}
  p.sub{color:var(--muted); margin:0 0 20px; font-size:14px; max-width:800px;}
  p.sub code{font-family:var(--mono); background:#F1F5F9; padding:1px 5px; border-radius:5px;}

  .pillnav{display:flex; gap:8px; flex-wrap:wrap; margin-bottom:22px; position:sticky; top:0; z-index:10;
    background:var(--bg); padding:8px 0;}
  .pillnav a{
    font-family:var(--mono); font-size:11.5px; font-weight:700; letter-spacing:.04em;
    text-transform:uppercase; padding:9px 16px; border-radius:999px; border:1px solid var(--border);
    background:var(--card); color:var(--ink); cursor:pointer; text-decoration:none; transition:.15s;
  }
  .pillnav a:hover{border-color:var(--blue); color:var(--blue);}

  .grid{display:grid; gap:14px;}
  .grid.cols-2{grid-template-columns:repeat(2,1fr);}
  .grid.cols-3{grid-template-columns:repeat(3,1fr);}
  .grid.cols-4{grid-template-columns:repeat(4,1fr);}
  @media(max-width:900px){ .grid.cols-2,.grid.cols-3,.grid.cols-4{grid-template-columns:1fr;} }

  .card{background:var(--card); border:1px solid var(--border-blue); border-radius:var(--radius); padding:16px 18px;}
  .card h3{margin:0 0 4px; font-size:12.5px; text-transform:uppercase; letter-spacing:.03em; color:var(--muted); font-weight:700;}
  .card .big{font-size:29px; font-weight:800; line-height:1.15; margin:2px 0;}
  .card .small{font-size:12px; color:var(--muted);}
  .kpi-bar{height:6px; border-radius:4px; background:#EEF2F7; margin-top:8px; overflow:hidden;}
  .kpi-bar > div{height:100%; border-radius:4px; background:var(--blue);}

  section{margin-bottom:34px; scroll-margin-top:64px;}
  section > h2.section-title{
    font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:var(--blue);
    font-weight:800; font-family:var(--mono); margin:0 0 4px;
  }
  section > .lede{font-size:14px; color:var(--muted); margin:0 0 16px; max-width:840px;}
  h3.sub-title{font-size:14.5px; font-weight:800; margin:26px 0 4px;}
  p.sub-lede{font-size:13px; color:var(--muted); margin:0 0 12px;}

  .slicer{display:flex; gap:6px; flex-wrap:wrap; margin-bottom:14px;}
  .slicer button{font-size:12px; font-weight:700; padding:6px 13px; border-radius:8px;
    border:1px solid var(--border); background:#fff; color:var(--ink); cursor:pointer;}
  .slicer button.active{background:var(--ink); color:#fff; border-color:var(--ink);}

  .chart-card{background:var(--card); border:1px solid var(--border-blue); border-radius:var(--radius); padding:16px 18px;}
  .chart-card h3{margin:0 0 2px; font-size:13px; font-weight:800; color:var(--ink);}
  .chart-card p.chart-note{font-size:12px; color:var(--muted); margin:0 0 12px;}
  svg.chart{width:100%; height:auto; overflow:visible;}
  svg.chart text{font-family:var(--sans); fill:var(--ink);}
  svg.chart .axis-label{font-size:10.5px; fill:var(--muted);}
  svg.chart .value-label{font-size:11px; font-weight:700;}
  .legend-row{display:flex; gap:16px; flex-wrap:wrap; margin-top:10px; font-size:12px; color:var(--muted);}
  .legend-row span{display:inline-flex; align-items:center; gap:6px;}
  .swatch{width:10px; height:10px; border-radius:3px; display:inline-block;}
  .bar-rect{cursor:default;}
  .bar-rect:hover{opacity:.82;}

  .heatmap-wrap{overflow-x:auto;}
  table.heatmap{border-collapse:collapse; font-size:12.5px; width:100%;}
  table.heatmap th{padding:7px 9px; font-size:10.5px; text-transform:uppercase; color:var(--muted);
    border-bottom:2px solid var(--border); text-align:left; white-space:nowrap;}
  table.heatmap td{padding:7px 9px; border-bottom:1px solid var(--border); text-align:center;}
  table.heatmap td.field-name{text-align:left; font-weight:600; white-space:nowrap;}
  .dot{display:inline-block; width:11px; height:11px; border-radius:3px;}
  .dot.yes{background:var(--green);}
  .dot.no{background:var(--red-bg); border:1.5px solid var(--red);}
  .dot.na{background:#E2E8F0;}

  details.namelist{margin-top:10px; border:1px dashed var(--border); border-radius:10px; padding:10px 14px; background:#F8FAFC;}
  details.namelist summary{cursor:pointer; font-weight:700; font-size:12.5px; color:var(--blue);}
  details.namelist ul{margin:10px 0 0; padding:0; list-style:none; max-height:220px; overflow:auto;}
  details.namelist li{padding:5px 2px; border-bottom:1px solid #EEF2F7; font-size:13px;}
  input.search{width:100%; padding:8px 11px; border-radius:8px; border:1px solid var(--border); font-size:13px; margin-top:8px;}

  details.assumptions{border:1px dashed #CBD5E1; border-radius:10px; padding:12px 16px; background:#FFFBEB;}
  details.assumptions summary{cursor:pointer; font-weight:700; font-size:13px; color:var(--amber);}
  details.assumptions ul{margin:10px 0 0; padding-left:18px; font-size:13px; color:#78350F; line-height:1.6;}

  .empty-note{color:var(--muted); font-size:13px; padding:14px; text-align:center;}
  footer.foot{margin-top:40px; padding-top:16px; border-top:1px solid var(--border);
    font-size:11.5px; color:var(--muted); text-align:center;}
  .hidden{display:none !important;}
  @media print{ .pillnav, .upload-box{display:none;} }
</style>
</head>
<body>
<div class="wrap">

  <header class="top">
    <div class="brand">
      <span class="oss">OSS</span><span class="nexus">Nexus</span>
      <span class="tag">CBOM Dashboard</span>
    </div>
    <div class="upload-box">
      <div>
        <button class="btn" id="uploadBtn">Upload dashboard_data.json</button>
        <button class="btn secondary" id="resetBtn">Reset to generated data</button>
        <button class="btn secondary" id="printBtn">Print / Save as PDF</button>
        <button class="btn secondary" id="exportCsvBtn">Export data (CSV)</button>
        <div id="uploadStatus"></div>
      </div>
      <input type="file" id="fileInput" accept="application/json,.json">
    </div>
  </header>

  <h1 class="title">CBOM Comparative Analysis</h1>
  <p class="sub">Cryptographic assets identified by SCANOSS vs. the Internal CBOM Generator,
    mapped against the CERT-In CBOM structure. Upload a different <code>dashboard_data.json</code>
    at any time to refresh every chart on this page.</p>

  <div class="pillnav">
    <a href="#sec-overview">Overview</a>
    <a href="#sec-comparative">Comparative Analysis</a>
  </div>

  <section id="sec-overview">
    <h2 class="section-title">Overview</h2>
    <p class="lede">Headline counts, how much each tool covers of the combined picture, and
      CERT-In readiness — before drilling into individual tables.</p>

    <div class="grid cols-4" id="kpiCards"></div>

    <div class="grid cols-2" style="margin-top:16px;">
      <div class="chart-card">
        <h3>Detection coverage</h3>
        <p class="chart-note">Of every distinct crypto asset either tool found (the combined
          universe), what share did each tool find on its own?</p>
        <div id="chartCoverage"></div>
      </div>
      <div class="chart-card">
        <h3>Cross-validation rate</h3>
        <p class="chart-note">Of what each tool found, what share was independently confirmed
          by the other tool?</p>
        <div id="chartCrossValidation"></div>
      </div>
    </div>

    <div class="grid cols-2" style="margin-top:14px;">
      <div class="chart-card">
        <h3>CERT-In readiness</h3>
        <p class="chart-note">Share of the 30 CERT-In fields (across all four tables) each
          tool actually populates.</p>
        <div id="chartReadiness"></div>
      </div>
      <div class="chart-card">
        <h3>Asset primitive mix</h3>
        <p class="chart-note">Cryptographic primitive breakdown per tool (algorithm/key/etc.
          category, not individual asset names).</p>
        <div id="chartPrimitive"></div>
      </div>
    </div>

    <div class="grid cols-2" style="margin-top:14px;">
      <div class="chart-card">
        <h3>Scan composition</h3>
        <p class="chart-note">Of everything each tool scanned, how much was actually
          cryptographic vs. library components filtered out.</p>
        <div id="chartScanComposition"></div>
      </div>
      <div class="chart-card">
        <h3>CERT-In classification coverage</h3>
        <p class="chart-note">Of the crypto assets each tool found, how many could be placed
          into one of CERT-In's four tables (recognised assetType) vs. left unclassified.</p>
        <div id="chartClassificationCoverage"></div>
      </div>
    </div>

    <div class="chart-card" style="margin-top:14px;">
      <h3>Detection depth</h3>
      <p class="chart-note">How many source-code locations cite each asset, bucketed per tool.
        More occurrences means broader use in the codebase, not higher confidence in the
        finding itself.</p>
      <div id="chartOccurrenceDepth"></div>
    </div>

    <details class="assumptions" style="margin-top:16px;">
      <summary>Assumptions &amp; methodology (click to expand)</summary>
      <ul id="assumptionsList"></ul>
    </details>
  </section>

  <section id="sec-comparative">
    <h2 class="section-title">Comparative Analysis</h2>
    <p class="lede">Asset overlap, CERT-In component placement, and CERT-In field capture —
      combined on one page. Use the table selector to focus on a single CERT-In table.</p>

    <h3 class="sub-title">Asset overlap</h3>
    <p class="sub-lede">All cryptographic assets (library components excluded), matched by
      normalised name across tools.</p>
    <div class="grid cols-2">
      <div class="chart-card"><h3>Assets found, by tool</h3><div id="chartAssetTotals"></div></div>
      <div class="chart-card"><h3>Overlap composition</h3><div id="chartOverlapDonut"></div></div>
    </div>
    <details class="namelist">
      <summary>View asset names (both / SCANOSS-only / Internal-only)</summary>
      <div class="grid cols-3" style="margin-top:10px;">
        <div><strong style="font-size:12.5px;">Found by both</strong><input class="search" data-list="list-both" placeholder="Filter…"><ul id="list-both"></ul></div>
        <div><strong style="font-size:12.5px;">SCANOSS only</strong><input class="search" data-list="list-scanoss-only" placeholder="Filter…"><ul id="list-scanoss-only"></ul></div>
        <div><strong style="font-size:12.5px;">Internal only</strong><input class="search" data-list="list-internal-only" placeholder="Filter…"><ul id="list-internal-only"></ul></div>
      </div>
    </details>

    <h3 class="sub-title">CERT-In · component placement</h3>
    <p class="sub-lede">Per CERT-In table, how many named components each tool placed there,
      and how many were confirmed by both.</p>
    <div class="chart-card"><h3>Components by CERT-In table</h3><div id="chartComponentsByTable"></div></div>

    <div class="slicer" id="componentSlicer"></div>
    <div id="componentDetailPanels"></div>

    <h3 class="sub-title">CERT-In · field coverage</h3>
    <p class="sub-lede">Of the fields CERT-In defines for each table, which ones each tool
      actually populates.</p>
    <div class="grid cols-2">
      <div class="chart-card"><h3>Coverage % by table</h3><div id="chartCoverageByTable"></div></div>
      <div class="chart-card"><h3>Coverage shape (radar)</h3><div id="chartRadar"></div></div>
    </div>
    <div class="chart-card" style="margin-top:14px;">
      <h3>Field-level detail</h3>
      <div class="slicer" id="fieldSlicer"></div>
      <div id="fieldHeatmapPanels"></div>
    </div>
  </section>

  <footer class="foot" id="footerNote"></footer>
</div>

<script>
(function(){
const GENERATED_DATA = __DASHBOARD_DATA__;
const COLOR_SCANOSS = "#93C5FD";
const COLOR_INTERNAL = "#1E3A8A";
const COLOR_BOTH = "#2563EB";
const PALETTE = ["#2563EB","#16A34A","#C2410C","#4338CA","#DB2777","#0EA5E9","#64748B"];

function el(tag, attrs, children){
  const e = document.createElement(tag);
  if(attrs) for(const k in attrs){
    if(k === "class") e.className = attrs[k];
    else if(k === "html") e.innerHTML = attrs[k];
    else e.setAttribute(k, attrs[k]);
  }
  (children||[]).forEach(function(c){ e.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
  return e;
}
function svgEl(tag, attrs){
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  if(attrs) for(const k in attrs) e.setAttribute(k, attrs[k]);
  return e;
}
function clear(node){ while(node.firstChild) node.removeChild(node.firstChild); }
function safe(v, d){ return (v === undefined || v === null) ? d : v; }
let currentData = GENERATED_DATA;

/* Reusable SVG chart primitives - no external chart library, so this stays
   offline-safe and iframe-safe with zero CDN dependency. */

function groupedBarChart(container, opts){
  const categories = opts.categories, series = opts.series, height = opts.height || 220,
        unit = opts.unit || "", maxOverride = opts.maxOverride || null;
  clear(container);
  const width = 640, padL = 40, padR = 16, padT = 14, padB = 34;
  const plotW = width - padL - padR, plotH = height - padT - padB;
  const maxVal = maxOverride || Math.max(1, series.reduce(function(acc,s){ return acc.concat(s.values); }, []).reduce(function(a,b){return Math.max(a,b);}, 0));
  const groupW = plotW / categories.length;
  const barW = Math.min(28, (groupW - 12) / series.length);

  const svg = svgEl("svg", {"class":"chart", viewBox:"0 0 "+width+" "+height, preserveAspectRatio:"xMidYMid meet"});

  const steps = 4;
  for(let i=0;i<=steps;i++){
    const y = padT + plotH - (plotH*i/steps);
    svg.appendChild(svgEl("line",{x1:padL,x2:width-padR,y1:y,y2:y,stroke:"#EEF2F7","stroke-width":1}));
    const label = svgEl("text",{x:padL-8,y:y+4,"text-anchor":"end","class":"axis-label"});
    label.textContent = Math.round(maxVal*i/steps) + unit;
    svg.appendChild(label);
  }

  categories.forEach(function(cat, ci){
    const groupX = padL + ci*groupW;
    series.forEach(function(s, si){
      const val = s.values[ci] || 0;
      const barH = plotH * (val/maxVal);
      const x = groupX + si*barW + (groupW - series.length*barW)/2;
      const y = padT + plotH - barH;
      const rect = svgEl("rect",{"class":"bar-rect", x:x, y:y, width:barW*0.86, height:Math.max(barH,0), rx:3, fill:s.color});
      const title = svgEl("title"); title.textContent = s.name+" — "+cat+": "+val+unit;
      rect.appendChild(title);
      svg.appendChild(rect);
      if(val>0){
        const vLabel = svgEl("text",{x:x+barW*0.43, y:y-5, "text-anchor":"middle", "class":"value-label"});
        vLabel.textContent = (unit === "%") ? formatPct(val) : (val+unit);
        svg.appendChild(vLabel);
      }
    });
    const cLabel = svgEl("text",{x:groupX+groupW/2, y:height-10, "text-anchor":"middle", "class":"axis-label"});
    cLabel.textContent = cat;
    svg.appendChild(cLabel);
  });

  container.appendChild(svg);
  const legend = el("div",{"class":"legend-row"});
  series.forEach(function(s){ legend.appendChild(el("span",{},[el("span",{"class":"swatch", style:"background:"+s.color}), s.name])); });
  container.appendChild(legend);
}

function formatPct(v){
  const n = (typeof v === "number") ? v : parseFloat(v);
  return (isNaN(n) ? 0 : n).toFixed(1) + "%";
}

function donutChart(container, opts){
  const segments = opts.segments, size = opts.size || 200,
        centerLabel = opts.centerLabel || "", centerSub = opts.centerSub || "",
        showLegend = opts.showLegend !== false;
  clear(container);
  const total = segments.reduce(function(a,s){return a+s.value;},0);
  const r = size/2 - 14, cx=size/2, cy=size/2, thickness=26;
  const svg = svgEl("svg", {"class":"chart", viewBox:"0 0 "+size+" "+size, style:"max-width:230px;"});
  let startAngle = -Math.PI/2;

  if(total === 0){
    svg.appendChild(svgEl("circle",{cx:cx,cy:cy,r:r, fill:"none", stroke:"#E2E8F0","stroke-width":thickness}));
  } else {
    segments.forEach(function(seg){
      const frac = seg.value/total;
      const endAngle = startAngle + frac*2*Math.PI;
      const largeArc = (endAngle-startAngle) > Math.PI ? 1 : 0;
      const x1 = cx + r*Math.cos(startAngle), y1 = cy + r*Math.sin(startAngle);
      const x2 = cx + r*Math.cos(endAngle), y2 = cy + r*Math.sin(endAngle);
      if(frac > 0){
        const path = svgEl("path",{
          d:"M "+x1+" "+y1+" A "+r+" "+r+" 0 "+largeArc+" 1 "+x2+" "+y2,
          fill:"none", stroke:seg.color, "stroke-width":thickness
        });
        const title = svgEl("title"); title.textContent = seg.label+": "+seg.value+" ("+(frac*100).toFixed(1)+"%)";
        path.appendChild(title);
        svg.appendChild(path);
      }
      startAngle = endAngle;
    });
  }
  const centerText = svgEl("text",{x:cx,y:cy-2,"text-anchor":"middle", style:"font-size:22px;font-weight:800;"});
  centerText.textContent = centerLabel;
  svg.appendChild(centerText);
  const subText = svgEl("text",{x:cx,y:cy+16,"text-anchor":"middle", "class":"axis-label"});
  subText.textContent = centerSub;
  svg.appendChild(subText);

  container.appendChild(svg);
  if(showLegend){
    const legend = el("div",{"class":"legend-row"});
    segments.forEach(function(s){ legend.appendChild(el("span",{},[el("span",{"class":"swatch", style:"background:"+s.color}), s.label+" ("+s.value+")"])); });
    container.appendChild(legend);
  }
}

function gaugeChart(container, opts){
  donutChart(container, {
    segments: [
      {label:"Captured", value:opts.pct, color:opts.color},
      {label:"Remaining", value:Math.max(0,100-opts.pct), color:"#E2E8F0"},
    ],
    centerLabel: formatPct(opts.pct),
    centerSub: opts.label,
    showLegend: false,
  });
  const caption = el("div",{style:"margin-top:8px; min-height:34px;"});
  caption.appendChild(el("div",{"class":"small", style:"font-weight:700;"},[opts.captionLine1||""]));
  caption.appendChild(el("div",{"class":"small"},[opts.captionLine2||""]));
  container.appendChild(caption);
}

function horizontalBarPair(container, opts){
  clear(container);
  const row = el("div",{style:"margin-bottom:4px;"});
  row.appendChild(el("div",{style:"font-size:12.5px;font-weight:700;margin-bottom:8px;"},[opts.label]));
  [{v:opts.a,name:opts.aLabel,color:COLOR_SCANOSS},{v:opts.b,name:opts.bLabel,color:COLOR_INTERNAL}].forEach(function(item){
    const track = el("div",{style:"display:flex;align-items:center;gap:8px;margin-bottom:7px;"});
    track.appendChild(el("div",{style:"width:70px;font-size:11.5px;color:var(--muted);flex-shrink:0;"},[item.name]));
    const bar = el("div",{style:"flex:1;background:#EEF2F7;border-radius:6px;height:18px;overflow:hidden;"});
    bar.appendChild(el("div",{style:"width:"+Math.min(item.v,100)+"%;background:"+item.color+";height:100%;border-radius:6px;"}));
    track.appendChild(bar);
    track.appendChild(el("div",{style:"width:44px;font-size:12px;font-weight:700;text-align:right;flex-shrink:0;"},[formatPct(item.v)]));
    row.appendChild(track);
  });
  container.appendChild(row);
}

function radarChart(container, opts){
  const axes = opts.axes, series = opts.series, size = opts.size || 280;
  clear(container);
  const cx=size/2, cy=size/2, r=size/2-46;
  const svg = svgEl("svg",{"class":"chart", viewBox:"0 0 "+size+" "+size, style:"max-width:320px;"});
  const n = axes.length;
  function angleFor(i){ return -Math.PI/2 + i*(2*Math.PI/n); }

  [0.25,0.5,0.75,1].forEach(function(frac){
    const pts = axes.map(function(_,i){
      const a = angleFor(i);
      return (cx+r*frac*Math.cos(a))+","+(cy+r*frac*Math.sin(a));
    }).join(" ");
    svg.appendChild(svgEl("polygon",{points:pts, fill:"none", stroke:"#E2E8F0","stroke-width":1}));
  });
  axes.forEach(function(axis,i){
    const a = angleFor(i);
    const x2 = cx+r*Math.cos(a), y2 = cy+r*Math.sin(a);
    svg.appendChild(svgEl("line",{x1:cx,y1:cy,x2:x2,y2:y2, stroke:"#E2E8F0","stroke-width":1}));
    const lx = cx+(r+22)*Math.cos(a), ly = cy+(r+22)*Math.sin(a);
    const t = svgEl("text",{x:lx,y:ly+4,"text-anchor":"middle", "class":"axis-label"});
    t.textContent = axis;
    svg.appendChild(t);
  });

  series.forEach(function(s){
    const pts = s.values.map(function(val,i){
      const a = angleFor(i);
      const frac = Math.max(0,Math.min(1,val/100));
      return (cx+r*frac*Math.cos(a))+","+(cy+r*frac*Math.sin(a));
    }).join(" ");
    const poly = svgEl("polygon",{points:pts, fill:s.color+"33", stroke:s.color,"stroke-width":2});
    svg.appendChild(poly);
    s.values.forEach(function(val,i){
      const a = angleFor(i);
      const frac = Math.max(0,Math.min(1,val/100));
      const px = cx+r*frac*Math.cos(a), py = cy+r*frac*Math.sin(a);
      const dot = svgEl("circle",{cx:px,cy:py,r:3,fill:s.color});
      const title = svgEl("title"); title.textContent = s.name+" — "+axes[i]+": "+val+"%";
      dot.appendChild(title);
      svg.appendChild(dot);
    });
  });

  container.appendChild(svg);
  const legend = el("div",{"class":"legend-row"});
  series.forEach(function(s){ legend.appendChild(el("span",{},[el("span",{"class":"swatch", style:"background:"+s.color}), s.name])); });
  container.appendChild(legend);
}

/* Render pipeline - callable repeatedly (initial load + upload) */

function renderDashboard(DATA){
  currentData = DATA;
  const steps = [
    ["KPI cards", renderKpis],
    ["Overview charts", renderOverviewCharts],
    ["Assumptions", renderAssumptions],
    ["Asset comparison", renderAssetSection],
    ["CERT-In components", renderComponentSection],
    ["CERT-In fields", renderFieldSection],
    ["Footer", renderFooter],
  ];
  steps.forEach(function(pair){
    try{ pair[1](DATA); }
    catch(err){ console.error("Dashboard render step failed: "+pair[0], err); }
  });
}

function renderKpis(DATA){
  const c = (DATA.assetComparison && DATA.assetComparison.counts) || {};
  const wrap = document.getElementById("kpiCards");
  clear(wrap);
  const bothN = safe(c.both,0), onlyAN = safe(c.only_a,0), onlyBN = safe(c.only_b,0);
  const cards = [
    {label:"SCANOSS assets", value: safe(c.scanoss_total,0), note: DATA.sources.scanoss ? "excludes libraries" : "file not supplied"},
    {label:"Internal assets", value: safe(c.internal_total,0), note: DATA.sources.internal ? "excludes libraries" : "file not supplied"},
    {label:"Combined unique assets", value: bothN+onlyAN+onlyBN, note:"union across both tools"},
    {label:"Found by both", value: bothN, note: "overlap of the two tools", pctBar: (bothN+onlyAN+onlyBN)>0 ? Math.round(100*bothN/(bothN+onlyAN+onlyBN)) : null},
  ];
  cards.forEach(function(card){
    const cardEl = el("div",{"class":"card"},[
      el("h3",{},[card.label]),
      el("div",{"class":"big"},[String(card.value)]),
      el("div",{"class":"small"},[card.note]),
    ]);
    if(card.pctBar!==null && card.pctBar!==undefined){
      cardEl.appendChild(el("div",{"class":"kpi-bar"},[el("div",{style:"width:"+card.pctBar+"%"})]));
    }
    wrap.appendChild(cardEl);
  });
}

function renderOverviewCharts(DATA){
  const eff = (DATA.assetComparison && DATA.assetComparison.efficiency) || {};
  horizontalBarPair(document.getElementById("chartCoverage"), {
    label: "Share of the "+safe(eff.union_total,0)+" combined unique assets each tool found",
    a: safe(eff.scanoss_coverage_pct,0), aLabel:"SCANOSS",
    b: safe(eff.internal_coverage_pct,0), bLabel:"Internal",
  });
  horizontalBarPair(document.getElementById("chartCrossValidation"), {
    label: "Share of each tool's own finds confirmed by the other tool",
    a: safe(eff.scanoss_cross_validation_pct,0), aLabel:"SCANOSS",
    b: safe(eff.internal_cross_validation_pct,0), bLabel:"Internal",
  });

  const overall = (DATA.certIn && DATA.certIn.overall) || {};
  const readinessWrap = document.getElementById("chartReadiness");
  clear(readinessWrap);
  const row = el("div",{style:"display:flex;gap:18px;flex-wrap:wrap;"});
  ["scanoss","internal"].forEach(function(key){
    const o = overall[key] || {};
    const label = key==="scanoss" ? "SCANOSS" : "Internal";
    const pct = o.supplied ? safe(o.percentage,0) : 0;
    const color = !o.supplied ? "#CBD5E1" : (pct>=70?"#16A34A":pct>=40?"#F59E0B":"#DC2626");
    const cell = el("div",{style:"flex:1;min-width:150px;text-align:center;"});
    gaugeChart(cell, {
      pct:pct, color:color, label:label,
      captionLine1: o.supplied ? (o.captured+"/"+o.total+" fields captured") : "File not supplied",
      captionLine2: o.supplied ? (o.records+" record(s)") : "",
    });
    row.appendChild(cell);
  });
  readinessWrap.appendChild(row);

  const primWrap = document.getElementById("chartPrimitive");
  clear(primWrap);
  const primRow = el("div",{style:"display:flex;gap:16px;flex-wrap:wrap;"});
  const dist = (DATA.assetComparison && DATA.assetComparison.primitiveDistribution) || {scanoss:[],internal:[]};
  [["scanoss","SCANOSS",dist.scanoss],["internal","Internal",dist.internal]].forEach(function(triple){
    const label=triple[1], items=triple[2]||[];
    const cell = el("div",{style:"flex:1;min-width:180px;text-align:center;"});
    const segs = items.map(function(it,i){ return {label:it.label, value:it.count, color:PALETTE[i%PALETTE.length]}; });
    const total = items.reduce(function(a,b){return a+b.count;},0);
    donutChart(cell, {segments: segs.length?segs:[{label:"No data",value:0,color:"#E2E8F0"}], centerLabel:String(total), centerSub:label});
    primRow.appendChild(cell);
  });
  primWrap.appendChild(primRow);

  const composition = (DATA.assetComparison && DATA.assetComparison.scanComposition) || {};
  const compWrap = document.getElementById("chartScanComposition");
  clear(compWrap);
  const compRow = el("div",{style:"display:flex;gap:16px;flex-wrap:wrap;"});
  [["scanoss","SCANOSS"],["internal","Internal"]].forEach(function(pair){
    const key=pair[0], label=pair[1];
    const sc = composition[key] || {supplied:false};
    const cell = el("div",{style:"flex:1;min-width:180px;text-align:center;"});
    if(!sc.supplied){
      donutChart(cell, {segments:[{label:"No data",value:0,color:"#E2E8F0"}], centerLabel:"—", centerSub:label, showLegend:false});
      cell.appendChild(el("div",{"class":"small"},["File not supplied"]));
    } else {
      donutChart(cell, {
        segments:[
          {label:"Crypto assets", value:sc.crypto_assets, color:"#2563EB"},
          {label:"Library components", value:sc.library_components, color:"#CBD5E1"},
        ],
        centerLabel:String(sc.total), centerSub:label,
      });
    }
    compRow.appendChild(cell);
  });
  compWrap.appendChild(compRow);

  const classCov = (DATA.certIn && DATA.certIn.classificationCoverage) || {};
  const classWrap = document.getElementById("chartClassificationCoverage");
  clear(classWrap);
  const classRow = el("div",{style:"display:flex;gap:18px;flex-wrap:wrap;"});
  ["scanoss","internal"].forEach(function(key){
    const o = classCov[key] || {supplied:false};
    const label = key==="scanoss" ? "SCANOSS" : "Internal";
    const pct = o.supplied ? safe(o.percentage,0) : 0;
    const color = !o.supplied ? "#CBD5E1" : (pct>=90?"#16A34A":pct>=60?"#F59E0B":"#DC2626");
    const cell = el("div",{style:"flex:1;min-width:150px;text-align:center;"});
    gaugeChart(cell, {
      pct:pct, color:color, label:label,
      captionLine1: o.supplied ? (o.classified+" of "+o.total+" assets classified") : "File not supplied",
      captionLine2: o.supplied ? (o.unclassified+" unclassified") : "",
    });
    classRow.appendChild(cell);
  });
  classWrap.appendChild(classRow);

  const occDist = (DATA.assetComparison && DATA.assetComparison.occurrenceDistribution) || {scanoss:[],internal:[]};
  const buckets = (occDist.scanoss && occDist.scanoss.length ? occDist.scanoss : occDist.internal || []).map(function(b){return b.bucket;});
  groupedBarChart(document.getElementById("chartOccurrenceDepth"), {
    categories: buckets.length ? buckets : ["1","2–5","6–10","11+"],
    series:[
      {name:"SCANOSS", color:COLOR_SCANOSS, values:(occDist.scanoss||[]).map(function(b){return b.count;})},
      {name:"Internal", color:COLOR_INTERNAL, values:(occDist.internal||[]).map(function(b){return b.count;})},
    ],
    height:200,
  });
}

function renderAssumptions(DATA){
  const list = document.getElementById("assumptionsList");
  clear(list);
  (DATA.assumptions||[]).forEach(function(a){ list.appendChild(el("li",{},[a])); });
}

function renderAssetSection(DATA){
  const c = (DATA.assetComparison && DATA.assetComparison.counts) || {};

  groupedBarChart(document.getElementById("chartAssetTotals"), {
    categories:["Crypto assets"],
    series:[
      {name:"SCANOSS", color:COLOR_SCANOSS, values:[safe(c.scanoss_total,0)]},
      {name:"Internal", color:COLOR_INTERNAL, values:[safe(c.internal_total,0)]},
    ],
    height:180,
  });

  donutChart(document.getElementById("chartOverlapDonut"), {
    segments:[
      {label:"SCANOSS only", value:safe(c.only_a,0), color:COLOR_SCANOSS},
      {label:"Found by both", value:safe(c.both,0), color:COLOR_BOTH},
      {label:"Internal only", value:safe(c.only_b,0), color:COLOR_INTERNAL},
    ],
    centerLabel:String(safe(c.both,0)+safe(c.only_a,0)+safe(c.only_b,0)),
    centerSub:"total unique",
  });

  function fillList(id, names){
    const ul = document.getElementById(id);
    clear(ul);
    if(!names || names.length===0){ ul.appendChild(el("li",{"class":"empty-note"},["None"])); return; }
    names.forEach(function(n){ ul.appendChild(el("li",{},[n])); });
  }
  fillList("list-both", DATA.assetComparison.both);
  fillList("list-scanoss-only", DATA.assetComparison.scanoss_only);
  fillList("list-internal-only", DATA.assetComparison.internal_only);

  document.querySelectorAll("input.search").forEach(function(input){
    input.oninput = function(){
      const list = document.getElementById(input.dataset.list);
      const q = input.value.trim().toLowerCase();
      list.querySelectorAll("li").forEach(function(li){ li.style.display = li.textContent.toLowerCase().includes(q) ? "" : "none"; });
    };
  });
}

function renderComponentSection(DATA){
  const tables = (DATA.certIn && DATA.certIn.tables) || {};
  const names = Object.keys(tables);

  groupedBarChart(document.getElementById("chartComponentsByTable"), {
    categories: names,
    series:[
      {name:"SCANOSS only", color:COLOR_SCANOSS, values:names.map(function(n){return tables[n].components.counts.only_a||0;})},
      {name:"Found by both", color:COLOR_BOTH, values:names.map(function(n){return tables[n].components.counts.both||0;})},
      {name:"Internal only", color:COLOR_INTERNAL, values:names.map(function(n){return tables[n].components.counts.only_b||0;})},
    ],
    height:240,
  });

  const slicer = document.getElementById("componentSlicer");
  const panels = document.getElementById("componentDetailPanels");
  clear(slicer); clear(panels);

  names.forEach(function(name, idx){
    const btn = el("button", {"class": idx===0?"active":""}, [name]);
    btn.onclick = function(){
      slicer.querySelectorAll("button").forEach(function(b){b.classList.remove("active");});
      btn.classList.add("active");
      panels.querySelectorAll(".panel").forEach(function(p){p.classList.add("hidden");});
      document.getElementById("comp-panel-"+name).classList.remove("hidden");
    };
    slicer.appendChild(btn);

    const t = tables[name];
    const panel = el("div",{"class":"panel"+(idx===0?"":" hidden"), id:"comp-panel-"+name});
    const details = el("details",{"class":"namelist"});
    details.appendChild(el("summary",{},["View "+name+" component names (both / SCANOSS-only / Internal-only)"]));
    const grid = el("div",{"class":"grid cols-3", style:"margin-top:10px;"});
    function col(title, arr){
      const box = el("div",{});
      box.appendChild(el("strong",{style:"font-size:12.5px;"},[title]));
      const ul = el("ul",{style:"max-height:200px;overflow:auto;margin:6px 0 0;padding:0;list-style:none;"});
      if(!arr || arr.length===0){ ul.appendChild(el("li",{"class":"empty-note"},["None"])); }
      else arr.forEach(function(n){ ul.appendChild(el("li",{style:"padding:4px 2px;border-bottom:1px solid #EEF2F7;font-size:12.5px;"},[n])); });
      box.appendChild(ul);
      return box;
    }
    grid.appendChild(col("Found by both", t.components.both));
    grid.appendChild(col("SCANOSS only", t.components.scanoss_only));
    grid.appendChild(col("Internal only", t.components.internal_only));
    details.appendChild(grid);
    panel.appendChild(details);
    panels.appendChild(panel);
  });
}

function renderFieldSection(DATA){
  const tables = (DATA.certIn && DATA.certIn.tables) || {};
  const names = Object.keys(tables);

  groupedBarChart(document.getElementById("chartCoverageByTable"), {
    categories: names,
    series:[
      {name:"SCANOSS", color:COLOR_SCANOSS, values:names.map(function(n){return tables[n].field_coverage.scanoss.supplied ? tables[n].field_coverage.scanoss.percentage : 0;})},
      {name:"Internal", color:COLOR_INTERNAL, values:names.map(function(n){return tables[n].field_coverage.internal.supplied ? tables[n].field_coverage.internal.percentage : 0;})},
    ],
    height:240, unit:"%", maxOverride:100,
  });

  radarChart(document.getElementById("chartRadar"), {
    axes: names,
    series:[
      {name:"SCANOSS", color:"#2563EB", values:names.map(function(n){return tables[n].field_coverage.scanoss.supplied?tables[n].field_coverage.scanoss.percentage:0;})},
      {name:"Internal", color:"#DC2626", values:names.map(function(n){return tables[n].field_coverage.internal.supplied?tables[n].field_coverage.internal.percentage:0;})},
    ],
  });

  const slicer = document.getElementById("fieldSlicer");
  const panels = document.getElementById("fieldHeatmapPanels");
  clear(slicer); clear(panels);

  names.forEach(function(name, idx){
    const btn = el("button", {"class": idx===0?"active":""}, [name]);
    btn.onclick = function(){
      slicer.querySelectorAll("button").forEach(function(b){b.classList.remove("active");});
      btn.classList.add("active");
      panels.querySelectorAll(".panel").forEach(function(p){p.classList.add("hidden");});
      document.getElementById("field-panel-"+name).classList.remove("hidden");
    };
    slicer.appendChild(btn);

    const t = tables[name];
    const cols = t.columns;
    const s = t.field_coverage.scanoss, i = t.field_coverage.internal;
    const panel = el("div",{"class":"panel"+(idx===0?"":" hidden"), id:"field-panel-"+name});
    const heatWrap = el("div",{"class":"heatmap-wrap"});
    const table = el("table",{"class":"heatmap"});
    table.appendChild(el("tr",{},[el("th",{},["CERT-In field"]), el("th",{},["SCANOSS"]), el("th",{},["Internal"])]));
    cols.forEach(function(fieldName){
      const sYes = s.supplied ? !!s.fields[fieldName] : null;
      const iYes = i.supplied ? !!i.fields[fieldName] : null;
      table.appendChild(el("tr",{},[
        el("td",{"class":"field-name"},[fieldName]),
        el("td",{},[dotFor(sYes)]),
        el("td",{},[dotFor(iYes)]),
      ]));
    });
    heatWrap.appendChild(table);
    panel.appendChild(heatWrap);
    panels.appendChild(panel);
  });

  function dotFor(state){
    if(state === null) return el("span",{"class":"dot na", title:"File not supplied"});
    return el("span",{"class":"dot "+(state?"yes":"no"), title: state ? "Captured" : "Not captured"});
  }
}

function renderFooter(DATA){
  const s = DATA.sources || {};
  document.getElementById("footerNote").innerHTML =
    "OSS Nexus · CBOM Comparative Dashboard · schema v" + safe(DATA.schemaVersion,1) +
    " · generated " + (DATA.generated||"").replace("T"," ").slice(0,16) +
    " · SCANOSS: " + (s.scanoss ? "<code>"+s.scanoss+"</code>" : "not supplied") +
    " · Internal: " + (s.internal ? "<code>"+s.internal+"</code>" : "not supplied");
}

/* Upload handling */

const uploadBtn = document.getElementById("uploadBtn");
const resetBtn = document.getElementById("resetBtn");
const printBtn = document.getElementById("printBtn");
const exportCsvBtn = document.getElementById("exportCsvBtn");
const fileInput = document.getElementById("fileInput");
const statusEl = document.getElementById("uploadStatus");

printBtn.addEventListener("click", function(){ window.print(); });

exportCsvBtn.addEventListener("click", function(){
  const csv = buildCsv(currentData);
  const blob = new Blob([csv], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "cbom_dashboard_export.csv";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

function csvEscape(value){
  const s = String(value === undefined || value === null ? "" : value);
  return /[",\\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function buildCsv(DATA){
  const lines = [];
  const c = (DATA.assetComparison && DATA.assetComparison.counts) || {};
  const eff = (DATA.assetComparison && DATA.assetComparison.efficiency) || {};

  lines.push(["Section","Metric","SCANOSS","Internal"].map(csvEscape).join(","));
  lines.push(["Asset totals","Crypto assets", safe(c.scanoss_total,0), safe(c.internal_total,0)].map(csvEscape).join(","));
  lines.push(["Asset totals","Found by both", safe(c.both,0), safe(c.both,0)].map(csvEscape).join(","));
  lines.push(["Asset totals","Tool-only assets", safe(c.only_a,0), safe(c.only_b,0)].map(csvEscape).join(","));
  lines.push(["Efficiency","Detection coverage %", safe(eff.scanoss_coverage_pct,0), safe(eff.internal_coverage_pct,0)].map(csvEscape).join(","));
  lines.push(["Efficiency","Cross-validation %", safe(eff.scanoss_cross_validation_pct,0), safe(eff.internal_cross_validation_pct,0)].map(csvEscape).join(","));
  lines.push([]);

  const tables = (DATA.certIn && DATA.certIn.tables) || {};
  lines.push(["CERT-In table","Metric","SCANOSS","Internal"].map(csvEscape).join(","));
  Object.keys(tables).forEach(function(name){
    const t = tables[name];
    const s = t.field_coverage.scanoss, i = t.field_coverage.internal;
    lines.push([name,"Components (only-tool)", t.components.counts.only_a||0, t.components.counts.only_b||0].map(csvEscape).join(","));
    lines.push([name,"Components (both)", t.components.counts.both||0, t.components.counts.both||0].map(csvEscape).join(","));
    lines.push([name,"Field coverage %", s.supplied?s.percentage:"", i.supplied?i.percentage:""].map(csvEscape).join(","));
    lines.push([name,"Fields captured / total", s.supplied?(s.captured+"/"+s.totalFields):"", i.supplied?(i.captured+"/"+i.totalFields):""].map(csvEscape).join(","));
  });
  lines.push([]);

  lines.push(["Asset list","Category","Name"].map(csvEscape).join(","));
  (DATA.assetComparison.both||[]).forEach(function(n){ lines.push(["Asset list","Found by both", n].map(csvEscape).join(",")); });
  (DATA.assetComparison.scanoss_only||[]).forEach(function(n){ lines.push(["Asset list","SCANOSS only", n].map(csvEscape).join(",")); });
  (DATA.assetComparison.internal_only||[]).forEach(function(n){ lines.push(["Asset list","Internal only", n].map(csvEscape).join(",")); });

  return lines.join("\\n");
}

uploadBtn.addEventListener("click", function(){ fileInput.click(); });

fileInput.addEventListener("change", function(evt){
  const file = evt.target.files && evt.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(){
    try{
      const parsed = JSON.parse(reader.result);
      if(!parsed || typeof parsed !== "object" || !parsed.assetComparison){
        throw new Error("This file doesn't look like a dashboard_data.json export (missing 'assetComparison').");
      }
      renderDashboard(parsed);
      statusEl.className = "ok";
      statusEl.textContent = "Loaded " + file.name + " — dashboard updated.";
    }catch(err){
      statusEl.className = "err";
      statusEl.textContent = "Could not load " + file.name + ": " + err.message;
    }
  };
  reader.onerror = function(){
    statusEl.className = "err";
    statusEl.textContent = "Could not read " + file.name + ".";
  };
  reader.readAsText(file);
  fileInput.value = "";
});

resetBtn.addEventListener("click", function(){
  renderDashboard(GENERATED_DATA);
  statusEl.className = "ok";
  statusEl.textContent = "Reset to the data generated with this file.";
});

renderDashboard(GENERATED_DATA);
})();
</script>
</body>
</html>
"""


def write_dashboard_html(data: Dict[str, Any], output_dir: str) -> str:
    """
    Inline the dashboard data into the single-file HTML template so the
    result is one self-contained artifact - no separate JSON to host
    alongside it, safe to drop into an <iframe> as-is.
    """
    payload = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    html = DASHBOARD_HTML_TEMPLATE.replace("__DASHBOARD_DATA__", payload)
    destination = os.path.join(output_dir, DASHBOARD_HTML_FILENAME)
    try:
        with open(destination, "w", encoding="utf-8") as handle:
            handle.write(html)
    except OSError as exc:
        raise RuntimeError(f"Cannot write '{DASHBOARD_HTML_FILENAME}':\n\n{exc}") from exc
    return destination


HEADER_FILL = "FF2E5C8A"
HEADER_FONT_COLOUR = "FFFFFFFF"
MAX_COLUMN_WIDTH = 70
MIN_COLUMN_WIDTH = 10
EXCEL_CELL_LIMIT = 32767


def write_workbook(result: ExtractionResult, output_dir: str) -> str:
    """Write one ExtractionResult to <output_dir>/<result.output_filename>."""
    if Workbook is None:
        raise RuntimeError(
            "openpyxl is not installed. Run:  pip install openpyxl"
        )

    workbook = Workbook()
    workbook.remove(workbook.active)

    for sheet_data in result.sheets:
        worksheet = workbook.create_sheet(title=sheet_data.name[:31])
        _write_sheet(worksheet, sheet_data)

    destination = os.path.join(output_dir, result.output_filename)
    try:
        workbook.save(destination)
    except PermissionError as exc:
        raise RuntimeError(
            f"Cannot write '{result.output_filename}'.\n\n"
            f"The file is most likely open in Excel - close it and try again."
        ) from exc
    return destination


def _write_sheet(worksheet: "Worksheet", sheet_data: SheetData) -> None:
    header_font = Font(bold=True, color=HEADER_FONT_COLOUR)
    header_fill = PatternFill("solid", fgColor=HEADER_FILL)
    header_alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="FFB8C4D4")
    header_border = Border(bottom=thin)

    worksheet.append(sheet_data.headers)
    for cell in worksheet[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = header_border

    widths = [len(str(header)) for header in sheet_data.headers]

    for row in sheet_data.rows:
        values: List[Any] = []
        for index, header in enumerate(sheet_data.headers):
            value = row.get(header, "")
            if isinstance(value, str) and len(value) > EXCEL_CELL_LIMIT:
                value = value[: EXCEL_CELL_LIMIT - 20] + " ...[truncated]"
            values.append(value)
            widths[index] = max(widths[index], min(len(as_text(value)), MAX_COLUMN_WIDTH))
        worksheet.append(values)

    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = max(
            MIN_COLUMN_WIDTH, min(width + 2, MAX_COLUMN_WIDTH)
        )

    worksheet.freeze_panes = "A2"
    if sheet_data.rows:
        worksheet.auto_filter.ref = (
            f"A1:{get_column_letter(len(sheet_data.headers))}{len(sheet_data.rows) + 1}"
        )


# --------------------------------------------------------------------------
# 4b.  CERT-In workbooks
# --------------------------------------------------------------------------

CERTIN_TITLE_FILL = "FF1F3864"
SECTION_FILL = "FFDCE6F1"
MUTED = "FF808080"

CERTIN_CBOM_FILENAME = "CERTIN_CBOM.xlsx"
CERTIN_COVERAGE_FILENAME = "CERTIN_Field_Coverage.xlsx"


def write_certin_workbook(
    extractions: Sequence[CertInExtraction], output_dir: str
) -> str:
    """
    One sheet per tool, each carrying the four CERT-In tables stacked in the
    order used by the CERT-In guideline (Algorithms, Keys, Protocols,
    Certificates). Tools with no file supplied still get a sheet holding the
    blank CERT-In template, so the workbook shape never changes.
    """
    workbook = Workbook()
    workbook.remove(workbook.active)

    for extraction in extractions:
        worksheet = workbook.create_sheet(title=extraction.label[:31])
        _write_certin_sheet(worksheet, extraction)

    destination = os.path.join(output_dir, CERTIN_CBOM_FILENAME)
    _save(workbook, destination, CERTIN_CBOM_FILENAME)
    return destination


def _write_certin_sheet(worksheet: "Worksheet", extraction: CertInExtraction) -> None:
    last_column = get_column_letter(CERTIN_MAX_COLUMNS)
    thin = Side(style="thin", color="FF9BB0C9")
    cell_border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # ---- title block -----------------------------------------------------
    worksheet.merge_cells(f"A1:{last_column}1")
    title = worksheet["A1"]
    title.value = f"CBOM as per CERT-In  -  {extraction.label}"
    title.font = Font(bold=True, size=14, color=HEADER_FONT_COLOUR)
    title.fill = PatternFill("solid", fgColor=CERTIN_TITLE_FILL)
    title.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    worksheet.row_dimensions[1].height = 24

    worksheet.merge_cells(f"A2:{last_column}2")
    subtitle = worksheet["A2"]
    subtitle.value = (
        f"Source: {os.path.basename(extraction.source_file)}"
        if extraction.supplied
        else "No file supplied for this tool - blank CERT-In template shown."
    )
    subtitle.font = Font(italic=True, color=MUTED, size=9)

    worksheet["A4"] = "Cryptographic Asset Type :"
    worksheet["A4"].font = Font(bold=True, size=11)

    row_index = 6

    for table in CERTIN_TABLES:
        # ---- section heading ---------------------------------------------
        heading = worksheet.cell(row=row_index, column=1, value=table.name)
        heading.font = Font(bold=True, size=12)
        row_index += 1

        # ---- header row ---------------------------------------------------
        for column_index, field_ in enumerate(table.fields, start=1):
            cell = worksheet.cell(row=row_index, column=column_index, value=field_.label)
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor=SECTION_FILL)
            cell.border = cell_border
            cell.alignment = Alignment(wrap_text=True, vertical="center")
        worksheet.row_dimensions[row_index].height = 28
        row_index += 1

        # ---- data rows ----------------------------------------------------
        rows = extraction.rows_for(table.name)
        if rows:
            for record in rows:
                for column_index, field_ in enumerate(table.fields, start=1):
                    value = record.get(field_.label, "")
                    cell = worksheet.cell(row=row_index, column=column_index, value=value)
                    cell.border = cell_border
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
                row_index += 1
        else:
            message = (
                f"No {table.name.lower()} identified in this CBOM."
                if extraction.supplied
                else "Not supplied."
            )
            worksheet.merge_cells(
                start_row=row_index, start_column=1,
                end_row=row_index, end_column=len(table.fields),
            )
            cell = worksheet.cell(row=row_index, column=1, value=message)
            cell.font = Font(italic=True, color=MUTED)
            cell.border = cell_border
            row_index += 1

        row_index += 2  # breathing room between tables

    # ---- unclassified footnote -------------------------------------------
    if extraction.unclassified:
        worksheet.cell(
            row=row_index, column=1,
            value=(
                f"Note: {len(extraction.unclassified)} component(s) carried no recognised "
                f"cryptoProperties.assetType and could not be placed in a CERT-In table: "
                + "; ".join(extraction.unclassified[:20])
            ),
        ).font = Font(italic=True, color="FFB07000", size=9)

    _autosize_certin_columns(worksheet)


def _autosize_certin_columns(worksheet: "Worksheet") -> None:
    widths = [14] * CERTIN_MAX_COLUMNS
    for row in worksheet.iter_rows(
        min_row=6, max_col=CERTIN_MAX_COLUMNS, values_only=False
    ):
        for cell in row:
            if cell.value is None or cell.column > CERTIN_MAX_COLUMNS:
                continue
            text = as_text(cell.value)
            if len(text) > 120:      # merged notes must not stretch column A
                continue
            widths[cell.column - 1] = max(widths[cell.column - 1], min(len(text) + 2, 34))
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = width


COVERAGE_SUMMARY_HEADERS = [
    "CERT-In Table",
    "Tool",
    "Status",
    "Records",
    "Total Fields",
    "Fields Captured",
    "Fields Not Captured",
    "Coverage %",
    "Captured Fields",
    "Missing Fields",
]

COVERAGE_DETAIL_HEADERS = [
    "CERT-In Table",
    "CERT-In Field",
    "CycloneDX Source Path",
    "SCANOSS - Records Populated",
    "SCANOSS - Captured",
    "Internal - Records Populated",
    "Internal - Captured",
]


def write_coverage_workbook(
    extractions: Sequence[CertInExtraction], output_dir: str
) -> str:
    """
    Two rows per CERT-In table - one for SCANOSS, one for the Internal tool -
    counting how many of that table's fields each tool actually populates,
    plus a per-field breakdown showing exactly which fields are missing.
    """
    by_label = {extraction.label: extraction for extraction in extractions}
    ordered = [by_label["SCANOSS"], by_label["Internal"]]

    workbook = Workbook()
    workbook.remove(workbook.active)

    summary = workbook.create_sheet("Coverage Summary")
    _write_header_row(summary, COVERAGE_SUMMARY_HEADERS)

    detail_rows: List[List[Any]] = []
    totals = {extraction.label: [0, 0, 0] for extraction in ordered}  # captured, total, records

    for table in CERTIN_TABLES:
        per_field_by_tool: Dict[str, Dict[str, int]] = {}
        for extraction in ordered:
            coverage, per_field = compute_coverage(table, extraction)
            per_field_by_tool[extraction.label] = per_field
            summary.append(
                [
                    coverage.table,
                    coverage.tool,
                    coverage.status,
                    coerce_cell(coverage.records),
                    coerce_cell(coverage.total_fields),
                    coerce_cell(coverage.captured),
                    coerce_cell(coverage.not_captured),
                    coerce_cell(coverage.percentage),
                    coverage.captured_fields,
                    coverage.missing_fields,
                ]
            )
            if extraction.supplied:
                totals[extraction.label][0] += int(coverage.captured)
                totals[extraction.label][1] += coverage.total_fields
                totals[extraction.label][2] += int(coverage.records)

        for field_ in table.fields:
            scanoss_count = per_field_by_tool["SCANOSS"].get(field_.label, 0)
            internal_count = per_field_by_tool["Internal"].get(field_.label, 0)
            detail_rows.append(
                [
                    table.name,
                    field_.label,
                    field_.source,
                    scanoss_count if by_label["SCANOSS"].supplied else "-",
                    _yes_no(scanoss_count, by_label["SCANOSS"].supplied),
                    internal_count if by_label["Internal"].supplied else "-",
                    _yes_no(internal_count, by_label["Internal"].supplied),
                ]
            )

    # ---- overall totals, visually separated from the eight required rows --
    summary.append([])
    for extraction in ordered:
        captured, total, records = totals[extraction.label]
        summary.append(
            [
                "TOTAL (all four tables)",
                extraction.label,
                "File not supplied" if not extraction.supplied else "Overall",
                records if extraction.supplied else "-",
                total if extraction.supplied else sum(len(t.fields) for t in CERTIN_TABLES),
                captured if extraction.supplied else "-",
                (total - captured) if extraction.supplied else "-",
                round(captured / total * 100, 1) if extraction.supplied and total else "-",
                "",
                "",
            ]
        )

    # ---- typography and number formats -----------------------------------
    for row in summary.iter_rows(min_row=2, max_row=summary.max_row):
        is_total = row[0].value and str(row[0].value).startswith("TOTAL")
        if is_total:
            for cell in row:
                cell.font = Font(bold=True)
        # Column H (index 7) is Coverage % - format numeric cells as "62.5%"
        percent_cell = row[7]
        if isinstance(percent_cell.value, (int, float)):
            percent_cell.number_format = '0.0"%"'

    _finalise_sheet(summary, COVERAGE_SUMMARY_HEADERS)

    detail = workbook.create_sheet("Field Detail")
    _write_header_row(detail, COVERAGE_DETAIL_HEADERS)
    for row in detail_rows:
        detail.append(row)
    _finalise_sheet(detail, COVERAGE_DETAIL_HEADERS)

    notes = workbook.create_sheet("Method")
    for line in _coverage_method_notes(ordered):
        notes.append([line])
    notes.column_dimensions["A"].width = 120
    notes["A1"].font = Font(bold=True, size=12)

    destination = os.path.join(output_dir, CERTIN_COVERAGE_FILENAME)
    _save(workbook, destination, CERTIN_COVERAGE_FILENAME)
    return destination


def _yes_no(count: int, supplied: bool) -> str:
    if not supplied:
        return "-"
    return "Yes" if count > 0 else "No"


def _coverage_method_notes(extractions: Sequence[CertInExtraction]) -> List[str]:
    lines = [
        "How this coverage was calculated",
        "",
        "A CERT-In field counts as CAPTURED when at least one record in that table carries a",
        "non-empty value for it. A field present in the schema but blank in every record counts",
        "as NOT captured, because it gives a reviewer nothing to assess.",
        "",
        "Records are drawn from cryptoProperties.assetType:",
        "    algorithm                -> Algorithms table",
        "    related-crypto-material  -> Keys table",
        "    protocol                 -> Protocols table",
        "    certificate              -> Certificates table",
        "",
        "Components of type 'library' are excluded, matching the filtering rule applied to the",
        "per-tool detail workbooks. Components with no recognised assetType are excluded and",
        "listed as a footnote on the corresponding CERT-In sheet.",
        "",
    ]
    if ALGORITHM_LIST_ASSUMED:
        lines += [
            "ASSUMPTION - the final Algorithms column ('List')",
            f"    Mapped to {ALGORITHM_LIST_SOURCE}.",
            "    No CycloneDX field is named 'List'. This column sits directly after 'Classical",
            "    security level', whose CycloneDX companion is nistQuantumSecurityLevel, so that",
            "    is what has been used. Confirm against the CERT-In guideline before issuing this",
            "    workbook to a client.",
            "",
        ]
    lines.append("Inputs used for this run:")
    for extraction in extractions:
        lines.append(
            f"    {extraction.label}: "
            + (os.path.basename(extraction.source_file) if extraction.supplied else "not supplied")
        )
    return lines


def _write_header_row(worksheet: "Worksheet", headers: Sequence[str]) -> None:
    worksheet.append(list(headers))
    thin = Side(style="thin", color="FFB8C4D4")
    for cell in worksheet[1]:
        cell.font = Font(bold=True, color=HEADER_FONT_COLOUR)
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        cell.border = Border(bottom=thin)
    worksheet.row_dimensions[1].height = 30


def _finalise_sheet(worksheet: "Worksheet", headers: Sequence[str]) -> None:
    widths = [len(str(header)) for header in headers]
    for row in worksheet.iter_rows(min_row=2, values_only=True):
        for index, value in enumerate(row):
            if index < len(widths) and value is not None:
                widths[index] = max(widths[index], min(len(as_text(value)), MAX_COLUMN_WIDTH))
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = max(
            MIN_COLUMN_WIDTH, min(width + 2, MAX_COLUMN_WIDTH)
        )
    worksheet.freeze_panes = "A2"


def _save(workbook: "Workbook", destination: str, filename: str) -> None:
    try:
        workbook.save(destination)
    except PermissionError as exc:
        raise RuntimeError(
            f"Cannot write '{filename}'.\n\n"
            f"The file is most likely open in Excel - close it and try again."
        ) from exc


# ===========================================================================
# 5.  ORCHESTRATION (headless-safe - importable and testable)
# ===========================================================================

ProgressCallback = Callable[[int, str], None]


def process_inputs(
    scanoss_path: Optional[str],
    internal_path: Optional[str],
    output_dir: str,
    progress: Optional[ProgressCallback] = None,
    include_certin: bool = True,
    include_dashboard_data: bool = True,
    include_dashboard_html: bool = False,
) -> Tuple[List[str], List[str]]:
    """
    Process whichever inputs were supplied.

    Returns (written_file_paths, log_messages). Raises RuntimeError with a
    user-facing message on unrecoverable failures.

    Note on include_dashboard_html: defaults to False. dashboard_data.json is
    the lightweight, cheap-to-regenerate artifact meant to be re-uploaded
    into an already-embedded CBOM_Dashboard.html via its upload button -
    there is normally no need to rebuild the (larger, styled) HTML shell on
    every run. Pass include_dashboard_html=True (or check the box / pass
    --dashboard-html) only when you need a fresh standalone HTML copy, e.g.
    the very first time, or after a template change.
    """

    def report(percent: int, message: str) -> None:
        if progress:
            progress(percent, message)

    if not scanoss_path and not internal_path:
        raise RuntimeError("Select at least one CBOM file before processing.")

    if not output_dir:
        raise RuntimeError("Select an output folder before processing.")

    if not os.path.isdir(output_dir):
        try:
            os.makedirs(output_dir, exist_ok=True)
        except OSError as exc:
            raise RuntimeError(f"Cannot create output folder:\n{output_dir}\n\n{exc}")

    jobs: List[Tuple[str, str, Callable[[Dict[str, Any]], ExtractionResult]]] = []
    if scanoss_path:
        jobs.append(("SCANOSS", scanoss_path, extract_scanoss))
    if internal_path:
        jobs.append(("Internal", internal_path, extract_internal))

    # The dashboard's CERT-In sections need CertInExtraction data even if the
    # user opted out of the standalone CERT-In workbooks.
    include_dashboard_any = include_dashboard_data or include_dashboard_html
    needs_certin_extraction = include_certin or include_dashboard_any

    written: List[str] = []
    log: List[str] = []
    certin: Dict[str, CertInExtraction] = {
        "SCANOSS": CertInExtraction(label="SCANOSS"),
        "Internal": CertInExtraction(label="Internal"),
    }
    results: Dict[str, ExtractionResult] = {}

    step = 0
    total_steps = (
        len(jobs) * 3
        + (2 if include_certin else 0)
        + (1 if include_dashboard_data else 0)
        + (1 if include_dashboard_html else 0)
    )
    total_steps = max(total_steps, 1)

    for label, path, extractor in jobs:
        step += 1
        report(int(step / total_steps * 100), f"Reading {label} file...")
        log.append(f"[{label}] Reading {os.path.basename(path)}")

        document, notes = load_cbom(path)
        log.extend(notes)

        detected = detect_flavour(document)
        if detected != "Unknown" and detected != label:
            log.append(
                f"[{label}] WARNING: this file does not look like a {label} CBOM "
                f"(detected format: {detected}). Check it was loaded into the correct slot."
            )

        spec_version = as_text(document.get("specVersion"))
        bom_format = as_text(document.get("bomFormat"))
        if bom_format and bom_format.lower() != "cyclonedx":
            log.append(f"[{label}] WARNING: bomFormat is '{bom_format}', expected CycloneDX.")
        log.append(f"[{label}] CycloneDX spec version {spec_version or 'unspecified'}")

        step += 1
        report(int(step / total_steps * 100), f"Extracting {label} components...")
        result = extractor(document)
        results[label] = result

        if result.removed_libraries:
            log.append(
                f"[{label}] Filtered out {len(result.removed_libraries)} component(s) "
                f"of type 'library':"
            )
            log.extend(f"    - {item}" for item in result.removed_libraries)
        else:
            log.append(f"[{label}] No 'library' components to filter.")

        for sheet in result.sheets:
            log.append(f"[{label}] {sheet.name}: {len(sheet.rows)} row(s)")

        if result.total_rows == 0:
            log.append(
                f"[{label}] WARNING: no rows extracted - the file may not contain "
                f"cryptographic-asset components."
            )

        if needs_certin_extraction:
            certin[label] = build_certin_extraction(label, document, path)

        step += 1
        report(int(step / total_steps * 100), f"Writing {result.output_filename}...")
        destination = write_workbook(result, output_dir)
        written.append(destination)
        log.append(f"[{label}] Wrote {destination}")

    # ---- CERT-In workbooks ------------------------------------------------
    if include_certin:
        extractions = [certin["SCANOSS"], certin["Internal"]]

        for extraction in extractions:
            if not extraction.supplied:
                log.append(
                    f"[CERT-In] {extraction.label}: no file supplied - blank template sheet "
                    f"and 'File not supplied' coverage rows will be written."
                )
                continue
            counts = ", ".join(
                f"{table.name} {len(extraction.rows_for(table.name))}"
                for table in CERTIN_TABLES
            )
            log.append(f"[CERT-In] {extraction.label}: {counts}")
            if extraction.unclassified:
                log.append(
                    f"[CERT-In] WARNING: {extraction.label} has "
                    f"{len(extraction.unclassified)} component(s) with no recognised "
                    f"cryptoProperties.assetType - excluded from all four tables:"
                )
                log.extend(f"    - {item}" for item in extraction.unclassified[:20])

        if ALGORITHM_LIST_ASSUMED:
            log.append(
                "[CERT-In] WARNING: the final Algorithms column ('List') has no matching "
                f"CycloneDX field; mapped to {ALGORITHM_LIST_SOURCE} as an assumption. "
                "Confirm before issuing to a client - see the Method sheet."
            )

        step += 1
        report(int(step / total_steps * 100), f"Writing {CERTIN_CBOM_FILENAME}...")
        destination = write_certin_workbook(extractions, output_dir)
        written.append(destination)
        log.append(f"[CERT-In] Wrote {destination}")

        step += 1
        report(int(step / total_steps * 100), f"Writing {CERTIN_COVERAGE_FILENAME}...")
        destination = write_coverage_workbook(extractions, output_dir)
        written.append(destination)
        log.append(f"[CERT-In] Wrote {destination}")

    # ---- Comparative dashboard ---------------------------------------------
    if include_dashboard_any:
        dashboard_data = build_dashboard_data(
            results.get("SCANOSS"),
            results.get("Internal"),
            certin.get("SCANOSS") if certin["SCANOSS"].supplied else None,
            certin.get("Internal") if certin["Internal"].supplied else None,
            scanoss_path or "",
            internal_path or "",
        )
        counts = dashboard_data["assetComparison"]["counts"]

        if include_dashboard_data:
            step += 1
            report(int(step / total_steps * 100), f"Writing {DASHBOARD_JSON_FILENAME}...")
            json_destination = write_dashboard_json(dashboard_data, output_dir)
            written.append(json_destination)
            log.append(f"[Dashboard] Wrote {json_destination}")
            log.append(
                f"[Dashboard] Asset comparison: {counts.get('both', 0)} found by both tools, "
                f"{counts.get('only_a', 0)} SCANOSS-only, {counts.get('only_b', 0)} Internal-only "
                f"(matched by normalised name)."
            )

        if include_dashboard_html:
            step += 1
            report(int(step / total_steps * 100), f"Writing {DASHBOARD_HTML_FILENAME}...")
            html_destination = write_dashboard_html(dashboard_data, output_dir)
            written.append(html_destination)
            log.append(f"[Dashboard] Wrote {html_destination}")
        elif include_dashboard_data:
            log.append(
                f"[Dashboard] Skipped {DASHBOARD_HTML_FILENAME} (not requested this run) - "
                f"upload the new {DASHBOARD_JSON_FILENAME} into an already-generated dashboard "
                f"to refresh it instead."
            )

    report(100, "Done.")
    return written, log


# ===========================================================================
# 6.  GUI
# ===========================================================================


def launch_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    class CBOMApp:
        def __init__(self, root: "tk.Tk") -> None:
            self.root = root
            self.root.title(f"{APP_NAME}  v{APP_VERSION}")
            self.root.geometry("880x620")
            self.root.minsize(760, 560)

            self.scanoss_var = tk.StringVar()
            self.internal_var = tk.StringVar()
            self.output_var = tk.StringVar(
                value=os.path.join(os.path.expanduser("~"), "Desktop")
                if os.path.isdir(os.path.join(os.path.expanduser("~"), "Desktop"))
                else os.getcwd()
            )
            self.certin_var = tk.BooleanVar(value=True)
            self.dashboard_json_var = tk.BooleanVar(value=True)
            self.dashboard_html_var = tk.BooleanVar(value=False)
            self.status_var = tk.StringVar(value="Ready. Select at least one CBOM file.")

            self.events: "queue.Queue[Tuple[str, Any]]" = queue.Queue()
            self.worker: Optional[threading.Thread] = None

            self._build_ui(ttk, tk)
            self.root.after(100, self._drain_events)

        # ---------------- layout ----------------
        def _build_ui(self, ttk, tk) -> None:
            style = ttk.Style()
            try:
                style.theme_use("clam")
            except Exception:
                pass
            style.configure("Header.TLabel", font=("Segoe UI", 15, "bold"))
            style.configure("Sub.TLabel", foreground="#555555")
            style.configure("Run.TButton", font=("Segoe UI", 10, "bold"))

            container = ttk.Frame(self.root, padding=16)
            container.pack(fill="both", expand=True)
            container.columnconfigure(0, weight=1)

            header = ttk.Frame(container)
            header.grid(row=0, column=0, sticky="ew")
            ttk.Label(header, text="CBOM Comparison & Analysis", style="Header.TLabel").pack(
                anchor="w"
            )
            ttk.Label(
                header,
                text="Parses CycloneDX CBOM reports from SCANOSS and the internal "
                "generator into review-ready workbooks.",
                style="Sub.TLabel",
            ).pack(anchor="w", pady=(2, 0))

            # ---- inputs ----
            inputs = ttk.LabelFrame(container, text=" Inputs ", padding=12)
            inputs.grid(row=1, column=0, sticky="ew", pady=(14, 0))
            inputs.columnconfigure(1, weight=1)

            self._file_row(
                ttk, inputs, 0, "SCANOSS CBOM (.json)", self.scanoss_var, self._browse_scanoss
            )
            self._file_row(
                ttk, inputs, 1, "Internal CBOM (.json)", self.internal_var, self._browse_internal
            )

            ttk.Label(
                inputs,
                text="Either input may be left blank - a workbook is produced for each file supplied.",
                style="Sub.TLabel",
            ).grid(row=2, column=0, columnspan=4, sticky="w", pady=(8, 0))

            # ---- output ----
            output = ttk.LabelFrame(container, text=" Output ", padding=12)
            output.grid(row=2, column=0, sticky="ew", pady=(12, 0))
            output.columnconfigure(1, weight=1)
            self._file_row(
                ttk, output, 0, "Output folder", self.output_var, self._browse_output,
                clearable=False,
            )
            ttk.Checkbutton(
                output,
                text="Also generate CERT-In workbooks  (CERTIN_CBOM.xlsx  +  "
                "CERTIN_Field_Coverage.xlsx)",
                variable=self.certin_var,
            ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(8, 0))
            ttk.Checkbutton(
                output,
                text="Also generate dashboard_data.json  (lightweight - upload it into an "
                "existing CBOM_Dashboard.html to refresh it)",
                variable=self.dashboard_json_var,
            ).grid(row=2, column=0, columnspan=4, sticky="w", pady=(4, 0))
            ttk.Checkbutton(
                output,
                text="Also (re)generate CBOM_Dashboard.html  (usually only needed once, or "
                "after a template change - not on every run)",
                variable=self.dashboard_html_var,
            ).grid(row=3, column=0, columnspan=4, sticky="w", pady=(4, 0))

            # ---- actions ----
            actions = ttk.Frame(container)
            actions.grid(row=3, column=0, sticky="ew", pady=(14, 0))
            actions.columnconfigure(1, weight=1)

            self.process_button = ttk.Button(
                actions, text="Process", style="Run.TButton", command=self._start
            )
            self.process_button.grid(row=0, column=0, ipadx=18, ipady=3)

            self.progress = ttk.Progressbar(actions, mode="determinate", maximum=100)
            self.progress.grid(row=0, column=1, sticky="ew", padx=(14, 14))

            ttk.Button(actions, text="Open output folder", command=self._open_output).grid(
                row=0, column=2
            )

            ttk.Label(container, textvariable=self.status_var).grid(
                row=4, column=0, sticky="w", pady=(10, 0)
            )

            # ---- log ----
            log_frame = ttk.LabelFrame(container, text=" Activity log ", padding=8)
            log_frame.grid(row=5, column=0, sticky="nsew", pady=(10, 0))
            container.rowconfigure(5, weight=1)
            log_frame.columnconfigure(0, weight=1)
            log_frame.rowconfigure(0, weight=1)

            self.log_widget = tk.Text(
                log_frame, height=12, wrap="none", font=("Consolas", 9),
                background="#1E1E1E", foreground="#DCDCDC", insertbackground="#DCDCDC",
                relief="flat",
            )
            self.log_widget.grid(row=0, column=0, sticky="nsew")
            scroll_y = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_widget.yview)
            scroll_y.grid(row=0, column=1, sticky="ns")
            scroll_x = ttk.Scrollbar(log_frame, orient="horizontal", command=self.log_widget.xview)
            scroll_x.grid(row=1, column=0, sticky="ew")
            self.log_widget.configure(
                yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set, state="disabled"
            )
            self.log_widget.tag_configure("warn", foreground="#F0C674")
            self.log_widget.tag_configure("error", foreground="#F08080")
            self.log_widget.tag_configure("ok", foreground="#9CD67C")

        def _file_row(self, ttk, parent, row, label, variable, command, clearable=True):
            ttk.Label(parent, text=label, width=22).grid(row=row, column=0, sticky="w", pady=4)
            entry = ttk.Entry(parent, textvariable=variable)
            entry.grid(row=row, column=1, sticky="ew", padx=(6, 6), pady=4)
            ttk.Button(parent, text="Browse...", command=command).grid(row=row, column=2, pady=4)
            if clearable:
                ttk.Button(
                    parent, text="Clear", command=lambda v=variable: v.set("")
                ).grid(row=row, column=3, padx=(6, 0), pady=4)

        # ---------------- browsing ----------------
        def _browse_json(self, title):
            return filedialog.askopenfilename(
                title=title,
                filetypes=[
                    ("CBOM files", "*.json *.cdx.json *.txt"),
                    ("JSON files", "*.json"),
                    ("All files", "*.*"),
                ],
            )

        def _browse_scanoss(self) -> None:
            path = self._browse_json("Select the SCANOSS CBOM")
            if path:
                self.scanoss_var.set(path)
                self._set_status(f"SCANOSS file selected: {os.path.basename(path)}")

        def _browse_internal(self) -> None:
            path = self._browse_json("Select the Internal tool CBOM")
            if path:
                self.internal_var.set(path)
                self._set_status(f"Internal file selected: {os.path.basename(path)}")

        def _browse_output(self) -> None:
            path = filedialog.askdirectory(title="Select the output folder")
            if path:
                self.output_var.set(path)

        def _open_output(self) -> None:
            folder = self.output_var.get().strip()
            if not folder or not os.path.isdir(folder):
                messagebox.showwarning(APP_NAME, "That output folder does not exist yet.")
                return
            try:
                if sys.platform.startswith("win"):
                    os.startfile(folder)  # type: ignore[attr-defined]
                elif sys.platform == "darwin":
                    os.system(f'open "{folder}"')
                else:
                    os.system(f'xdg-open "{folder}"')
            except Exception as exc:
                messagebox.showwarning(APP_NAME, f"Could not open the folder:\n{exc}")

        # ---------------- logging ----------------
        def _log(self, message: str, tag: str = "") -> None:
            lowered = message.lower()
            if not tag:
                if "warning" in lowered:
                    tag = "warn"
                elif "error" in lowered or "cannot" in lowered:
                    tag = "error"
                elif message.startswith("Wrote") or " Wrote " in message:
                    tag = "ok"
            self.log_widget.configure(state="normal")
            stamp = datetime.now().strftime("%H:%M:%S")
            line = f"{stamp}  {message}\n"
            if tag:
                self.log_widget.insert("end", line, tag)
            else:
                self.log_widget.insert("end", line)
            self.log_widget.see("end")
            self.log_widget.configure(state="disabled")

        def _set_status(self, message: str) -> None:
            self.status_var.set(message)

        # ---------------- run ----------------
        def _start(self) -> None:
            if self.worker and self.worker.is_alive():
                return

            scanoss = self.scanoss_var.get().strip() or None
            internal = self.internal_var.get().strip() or None
            output_dir = self.output_var.get().strip()

            for label, path in (("SCANOSS", scanoss), ("Internal", internal)):
                if path and not os.path.isfile(path):
                    messagebox.showerror(
                        APP_NAME, f"The {label} file does not exist:\n{path}"
                    )
                    return

            if not scanoss and not internal:
                messagebox.showwarning(
                    APP_NAME, "Select at least one CBOM file before processing."
                )
                return

            if not output_dir:
                messagebox.showwarning(APP_NAME, "Select an output folder before processing.")
                return

            self.process_button.configure(state="disabled")
            self.progress["value"] = 0
            self.log_widget.configure(state="normal")
            self.log_widget.delete("1.0", "end")
            self.log_widget.configure(state="disabled")
            self._log(f"Run started - {datetime.now():%Y-%m-%d %H:%M:%S}")

            self.worker = threading.Thread(
                target=self._run_job,
                args=(scanoss, internal, output_dir, bool(self.certin_var.get()),
                      bool(self.dashboard_json_var.get()), bool(self.dashboard_html_var.get())),
                daemon=True,
            )
            self.worker.start()

        def _run_job(self, scanoss, internal, output_dir, include_certin,
                     include_dashboard_data, include_dashboard_html) -> None:
            def progress(percent: int, message: str) -> None:
                self.events.put(("progress", (percent, message)))

            try:
                written, log = process_inputs(
                    scanoss, internal, output_dir, progress, include_certin,
                    include_dashboard_data, include_dashboard_html
                )
                self.events.put(("log", log))
                self.events.put(("done", written))
            except Exception as exc:  # noqa: BLE001 - surfaced to the user
                detail = str(exc) if str(exc) else traceback.format_exc()
                self.events.put(("failed", detail))

        def _drain_events(self) -> None:
            try:
                while True:
                    kind, payload = self.events.get_nowait()
                    if kind == "progress":
                        percent, message = payload
                        self.progress["value"] = percent
                        self._set_status(message)
                    elif kind == "log":
                        for line in payload:
                            self._log(line)
                    elif kind == "done":
                        self._finish_success(payload)
                    elif kind == "failed":
                        self._finish_failure(payload)
            except queue.Empty:
                pass
            self.root.after(100, self._drain_events)

        def _finish_success(self, written: Sequence[str]) -> None:
            self.progress["value"] = 100
            self.process_button.configure(state="normal")
            names = "\n".join(f"  - {os.path.basename(p)}" for p in written)
            self._set_status(f"Completed - {len(written)} workbook(s) written.")
            self._log("Run completed successfully.", "ok")
            messagebox.showinfo(
                APP_NAME,
                f"Processing complete.\n\n{len(written)} workbook(s) written to:\n"
                f"{os.path.dirname(written[0]) if written else ''}\n\n{names}",
            )

        def _finish_failure(self, detail: str) -> None:
            self.progress["value"] = 0
            self.process_button.configure(state="normal")
            self._set_status("Failed - see the activity log.")
            for line in detail.splitlines():
                self._log(line, "error")
            messagebox.showerror(APP_NAME, detail)

    root = tk.Tk()
    if Workbook is None:
        from tkinter import messagebox as mb

        mb.showerror(
            APP_NAME,
            "openpyxl is not installed.\n\nRun:  pip install openpyxl",
        )
        root.destroy()
        return
    CBOMApp(root)
    root.mainloop()


# ===========================================================================
# 7.  CLI FALLBACK
# ===========================================================================


def main(argv: Sequence[str]) -> int:
    if len(argv) > 1 and argv[1] in {"--cli", "-c"}:
        import argparse

        parser = argparse.ArgumentParser(description=APP_NAME)
        parser.add_argument("--cli", action="store_true")
        parser.add_argument("--scanoss", help="Path to the SCANOSS CBOM JSON")
        parser.add_argument("--internal", help="Path to the internal CBOM JSON")
        parser.add_argument("--out", default=os.getcwd(), help="Output folder")
        parser.add_argument(
            "--no-certin", action="store_true",
            help="Skip CERTIN_CBOM.xlsx and CERTIN_Field_Coverage.xlsx",
        )
        parser.add_argument(
            "--no-dashboard-json", action="store_true",
            help="Skip dashboard_data.json (generated by default)",
        )
        parser.add_argument(
            "--dashboard-html", action="store_true",
            help="Also (re)generate CBOM_Dashboard.html. Off by default - the HTML shell "
            "is usually built once and refreshed by uploading a new dashboard_data.json "
            "into it, not regenerated on every run.",
        )
        args = parser.parse_args(argv[1:])

        try:
            written, log = process_inputs(
                args.scanoss,
                args.internal,
                args.out,
                lambda pct, msg: print(f"[{pct:3d}%] {msg}"),
                include_certin=not args.no_certin,
                include_dashboard_data=not args.no_dashboard_json,
                include_dashboard_html=args.dashboard_html,
            )
        except Exception as exc:  # noqa: BLE001
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1

        for line in log:
            print(line)
        print("\nWritten:")
        for path in written:
            print(f"  {path}")
        return 0

    launch_gui()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
