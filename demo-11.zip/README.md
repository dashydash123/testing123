# xBOM Readiness Dashboard

One self-contained HTML file. No build step, no server, no CDN calls — open it by
double-clicking, or ship it inside an extract-and-run bundle. All parsing, scoring and
charting happen in the browser, so no BOM content leaves the machine.

## Loading documents

Three slots — **SBOM**, **AIBOM**, **CBOM**. Drop a JSON file on a slot or use its button.
You declare the type; the tool works out the format. There is no demo data in the file:
it starts empty and every figure is built from what you upload.

| Signal | Parsed as |
|---|---|
| `bomFormat: "CycloneDX"` | CycloneDX 1.4 – 1.7 |
| `spdxVersion: "SPDX-2.x"` | SPDX 2.2 / 2.3 JSON |
| `@graph` / `@context` | SPDX 3.0 JSON-LD |

Each slot reports the detected format and warns when the contents don't match — a CBOM
dropped into the AIBOM slot says so rather than silently scoring zero.

## Built against real scanner output

The `samples/` folder holds two documents taken from production tooling, and the parser is
written against their quirks rather than against the spec examples:

| Reality | Handling |
|---|---|
| `version: "Unknown"`, `publisher: "NOASSERTION"` | Treated as absent, not as a value. Placeholder-aware throughout. |
| Component `name` is the purl string | A readable name is derived from the coordinates; the full purl stays in the tooltip. |
| The same licence repeated per `acknowledgement` | Collapsed, with `concluded` preferred over `declared`. |
| purl types are hostnames (`github.com`, `www.nuget.org`) | Normalised to registry names for grouping. |
| `LicenseRef-unknown` | Classified as **undeclared**, not as a real licence and not as restricted. |
| Vulnerabilities target a purl, not a `bom-ref` | Resolved against bom-ref, purl, raw name and display name. |
| `dependencies` is a flat ref list with no edges | Detected, and Dependency Graph is scored **N/A** rather than 0%. |
| A CBOM with only algorithms — no keys, certs or protocols | Those three dimensions score **N/A** and drop out of the average. |
| Algorithms with no `parameterSetIdentifier` | Characterisation accepts `algorithmFamily`, `classicalSecurityLevel`, `ellipticCurve` or a NIST level instead. |

**N/A is the important one.** A dimension the document cannot express is not a dimension
the project is failing. It is marked N/A on the scorecard, excluded from the average, and
the reason is in the tooltip.

## What's on the dashboard

Each figure answers a question no other figure answers, and each is built to stay readable
as the input grows. Sections appear only for the BOM types you load.

**Overview**

- **Composite gauge** and **gate** — releasable or not.
- **KPI tiles with bullet bars** — value against target, with qualitative bands.
- **Readiness scorecard** — the single canonical view of all dimension scores, with N/A
  cells where a dimension does not apply. Hover for the evidence; click to filter.

**SBOM**

- **Obligation flow** *(three-stage sankey)* — origin → declared licence → what those terms
  oblige on release. The right-hand column is a release checklist, not a licence census.
- **Where the findings concentrate** — components ranked by how many findings they carry.
  The register groups by rule and the plan by fix; neither says which packages to pick up
  first, which is how remediation is actually assigned.
- **Licence concentration** *(Pareto)* — only when more than ten distinct licences exist.
- **Vulnerability ageing** — every record on a log age axis by severity, filled if open,
  with the 90-day line marked, preceded by a scan-coverage banner.
- **Upstream concentration** — only when at least three named upstreams exist and the top
  three carry 35% or more. "Unattributed" is missing data, not an upstream.
- **Mandated field conformance** — the fields an assessor asks for, including four the
  scorecard does not look at.
- **Projected readiness · SBOM** — before-and-after bars per dimension.

**AIBOM**

- **Model clearance** *(bubble quadrant)* — licence permissiveness against evidence
  completeness, with each corner labelled for what it means to a release.
- **Supply-chain posture** — models split by attested / source known / opaque, and datasets
  by governed / personal or confidential / unknown. Two questions no other AI figure asks.
- **Licence inheritance** *(matrix)* — which model was trained on which dataset and whether
  that data is stricter than the model's own terms. Models with no declared training data
  are flagged **no lineage**, so this carries the lineage question too.
- **Projected readiness · AIBOM**.

**CBOM**

- **Cryptographic function map** *(matrix)* — what cryptography the codebase performs,
  cross-cut by quantum exposure, with **Not assessed** as its own column.
- **Migration effort** — per risk band: how many algorithms, how many call sites, how many
  files. Three retired primitives in one file is an afternoon; three across ninety files is
  a programme. Replaces the per-file listing, which grew unusable at 350 algorithms.
- **Renewal runway** *(lollipop timeline, full width)* — certificates on an 18-month horizon.
- **Migration blast radius** — only when the generator records algorithm references.
- **Projected readiness · CBOM**.

**Cross-cutting**

- **Remediation plan** — every finding mapped to the fix behind it, ranked by leverage,
  with owner and a coarse effort band. The register groups by symptom; this groups by
  work. A headline states what the top three actions clear, and actions that unlock
  second-order effects say so — fixing versions also makes components matchable to
  advisory feeds.
- **Composite outlook** — the whole-picture before and after, with the gate change. Each
  BOM section carries its own **Projected readiness** panel: one bar per dimension, solid
  for today and a lighter extension for what the top actions add, with the 90% pass mark
  ticked. Bars were chosen over a slope chart because two dimensions landing on the same
  value made slope labels collide.
- **Document provenance** — whether the BOM itself can be defended in an audit: tool,
  author, timestamp, identifier, subject version, signature. Document-level only, so no
  overlap with the component scorecard.
- **Board summary** — the *Board summary* button prints a clean one-pager: overview,
  scorecard, section figures, plan and projection, with the intake and issue register
  suppressed.
- **Issue register** — findings grouped by rule, collapsed, searchable, cross-filtered.

## Licence conflicts and exploitability

Two checks run over the licence and vulnerability data that go beyond counting:

- **Licence combination conflicts** — pairs that cannot lawfully coexist in one distributed
  work (GPL-2.0 with Apache-2.0, copyleft with use-restricted terms, copyleft with
  unresolved bespoke terms). Matching works inside compound expressions, so
  `GPL-2.0-only AND MIT` is caught while `LGPL-3.0-or-later` is not misread as GPL. AGPL and
  SSPL in a shipped product get their own callout.
- **Known-exploited and EPSS enrichment** — read from the BOM when a generator carries them
  (`ratings` with an EPSS or CISA source, or `properties`). KEV items get a ring on the
  ageing chart and a critical finding, EPSS scales the dot. Neither of the production
  samples carries either field, which the dashboard states rather than hides — exploitation
  data has to be enriched in before it can prioritise anything.

## On the Vulnerability Triage score

It measures **VEX completeness against the records present**, not exposure. Read it with
three things in mind, all of which the dashboard now states rather than hides:

- **A perfect score is not safety.** Two hundred CVEs all marked `exploitable` score 100%.
- **Coverage bounds the meaning.** Components with no package URL or no real version cannot
  be matched to any advisory feed. The banner above the chart states that share — on the
  SCANOSS sample it is 5 of 15, so the vulnerability picture covers a third of the estate.
- **`not_affected` needs a justification.** CycloneDX requires one; a bare state is counted
  as untriaged and raises its own finding, because an assessor will reject it.

"Scanned and clean" and "never scanned" are also distinguished: an absent `vulnerabilities`
block and an empty one produce different N/A reasons.

## Designed for scale

Tested at 500 components / 64 vulnerabilities / 576 findings: **0.35 s to render, no
horizontal overflow and no label collisions from 1400 px down to 390 px.**

| Technique | Where |
|---|---|
| **Aggregation** | Sankey pools origins beyond the top 6 and licences beyond the top 7 into a single *other* node, so node count is bounded whatever the input. |
| **Head-and-tail** | Pareto shows the head in full and collapses the tail into one row, while the cumulative marker still describes the whole population. |
| **Combinatorial rollup** | Gap combinations has one row per *combination of missing attributes*, not per component — bounded by 2^attributes regardless of BOM size. |
| **Closed vocabularies** | The function map's rows are cryptographic primitives, a fixed set, so it holds its shape at any inventory size. |
| **Grouping** | The issue register groups findings into rules. 568 findings became 10 collapsed rows. |
| **Progressive disclosure** | Groups are collapsed by default and expand on click; only 8 groups render at a time with *show more*. |
| **Search** | Free-text filter across component and rule names. |
| **Cross-filter** | Clicking any chart element scopes the register to it, so drill-down replaces scrolling. |
| **Action rollup** | 576 findings across 11 rules reduce to 9 remediation actions, ranked by what each clears. |
| **Log scaling** | The ageing axis is logarithmic, so a five-year-old finding and a five-day-old one both sit legibly on the same chart. |

Adaptive labelling too: sankey nodes switch to a single-line label when they get short, so
the diagram never overlaps itself as slices thin out.

## Interactivity

- **Hover** anything for the number behind the mark — the components in a ribbon, why a
  dimension scores what it does, which assets a file touches.
- **Click** a scorecard cell, sankey node or ribbon, Pareto row, gap combination, function-map
  cell, hotspot directory, lineage node, quadrant bubble or severity chip to filter the
  register. The picked mark is outlined, its siblings dim, and a chip shows the filter.
- **Expand** a rule group to see every affected component; **search** to narrow further.
- A selection that yields nothing says so plainly — a clean area is a result worth seeing.

## Not yet built

**Baseline comparison** — a second upload per slot holding the previous BOM, producing
new / resolved / persisting findings and a direction of travel.

Some things are deliberately absent because a single BOM set cannot support them honestly:
a risk-trend and remediation-velocity chart needs history; a vendor questionnaire radar
needs questionnaire responses; a business-unit or period filter needs a portfolio behind it.
Framework scores for regimes that are not field-level SBOM checklists are also absent —
scoring them from a BOM would be inventing a number.

## Colours

White surfaces, `#2563EB` primary, mint for complete states, and the amber / red / violet /
teal accent family. Semantic colours are consistent across every figure — green permissive,
teal weak copyleft, amber strong copyleft, red use-restricted, violet needs-review, slate
undeclared — so a colour means the same thing everywhere. All of it is in the `:root` block.

## Files

| File | Contents |
|---|---|
| `xbom-readiness-dashboard.html` | The dashboard. |
| `samples/sample-sbom-scanoss.cdx.json` | Real SCANOSS output — 15 components, placeholder versions, duplicated licences, flat dependency list, purl-targeted CVEs. |
| `samples/sample-cbom-pynacl.cdx.json` | Real internal generator output — CycloneDX 1.7, algorithms only, source evidence, no parameter sets. |
| `samples/sample-sbom.cdx.json`, `sample-aibom.cdx.json`, `sample-cbom.cdx.json` | Synthetic CycloneDX covering the paths the production samples don't reach (keys, certificates, protocols, models, datasets). |
| `samples/sample-sbom.spdx.json`, `sample-aibom.spdx3.json` | SPDX 2.3 and SPDX 3.0 equivalents. |

## Extending it

Seven labelled sections in one script: intake and normalisation, licence classification,
evaluators, analysis, charts, render, interaction and wiring.

- **New format** — write `fromX(raw)` returning the internal model and add a signal to
  `detectFormat()`. Nothing downstream changes.
- **New dimension** — one `dim(label, short, done, total, wording, sub, naReason)` call. Pass
  a total of zero with a reason and it becomes N/A automatically.
- **New figure** — compute its data in `analyse()` (aggregate there, not in the renderer),
  build the markup in section 5, add a `box()` to the relevant section in `render()`.
- **New finding rule** — push `{sev, rule, dim, ref, detail}`. The register groups by `rule`
  on its own, so a rule that fires 400 times still costs one row.
- **Licence rules** — the regexes in `licenceClass()`. Unrecognised expressions land in
  *needs review*, never silently in permissive.
