@echo off
REM ===================================================================
REM  Build CBOM_Analyzer.exe  (single file, no console window)
REM  Run this from a Windows command prompt in the folder that
REM  contains cbom_analyzer.py
REM ===================================================================

echo [1/3] Installing build dependencies...
python -m pip install --upgrade pip
python -m pip install openpyxl pyinstaller
if errorlevel 1 goto :failed

echo.
echo [2/3] Building executable...
pyinstaller --onefile --windowed ^
    --name CBOM_Analyzer ^
    --hidden-import openpyxl ^
    --hidden-import openpyxl.cell._writer ^
    --collect-submodules openpyxl ^
    --exclude-module pandas ^
    --exclude-module numpy ^
    --exclude-module matplotlib ^
    cbom_analyzer.py
if errorlevel 1 goto :failed

echo.
echo [3/3] Done.
echo Executable written to:  %CD%\dist\CBOM_Analyzer.exe
echo (Copy that single file anywhere - no Python install required.)
pause
exit /b 0

:failed
echo.
echo BUILD FAILED - see the messages above.
pause
exit /b 1
