# xBOM Readiness Dashboard

One self-contained HTML file. No build step, no server, no CDN calls — open it by
double-clicking, or ship it inside an extract-and-run bundle. All parsing, scoring and
charting happen in the browser, so no BOM content leaves the machine.

## Files

| File | Format | Contents |
|---|---|---|
| `xbom-readiness-dashboard.html` | — | The dashboard. All five samples are embedded, so it demos with zero setup. |
| `samples/sample-sbom.cdx.json` | CycloneDX 1.6 | Container image, 12 components, licence and provenance gaps, 2 CVEs. |
| `samples/sample-aibom.cdx.json` | CycloneDX 1.6 | 3 models, 2 datasets, 4 libraries, one unresolved licence, one research-only model. |
| `samples/sample-cbom.cdx.json` | CycloneDX 1.6 | 5 algorithms, 3 keys, 3 protocols, 3 certificates — incl. SHA-1, TLS 1.1, ML-KEM-768. |
| `samples/sample-sbom.spdx.json` | SPDX 2.3 | 9 packages, NOASSERTION licences, GPL-with-exception, a `LicenseRef` restricted font. |
| `samples/sample-aibom.spdx3.json` | SPDX 3.0 | AI and dataset profiles — `ai_AIPackage`, `dataset_DatasetPackage`, relationship-based licensing. |

## Loading documents

Three slots — **SBOM**, **AIBOM**, **CBOM** — one document each. Drop a file on a slot or
use its Upload button. You say which BOM type it is; the tool works out the format.

Each slot shows the detected format, the subject and the item count once loaded, and warns
you when the contents don't match:

- *No AIBOM assets found in this document* — you loaded the wrong file into the slot.
- *Also carries CBOM assets* — a merged xBOM; load the same file into that slot too.

Slots are independent. Add, replace or remove one and every figure recomputes.

## Input formats

Each file is sniffed independently, so the three slots can hold three different formats.

| Signal | Parsed as |
|---|---|
| `bomFormat: "CycloneDX"` | CycloneDX 1.4–1.6 |
| `spdxVersion: "SPDX-2.x"` | SPDX 2.2 / 2.3 JSON |
| `@graph` / `@context` | SPDX 3.0 JSON-LD |

Everything normalises into one internal model — `{id, name, version, type, purl, licenses[],
supplier, refs[], model, dataset, crypto}` — and the evaluators only ever see that model.
Adding a format means writing one `fromX()` function; nothing downstream changes.

**What each format can carry:**

| | CycloneDX 1.6 | SPDX 2.3 | SPDX 3.0 |
|---|---|---|---|
| SBOM | full | full | full |
| AIBOM | `machine-learning-model` + `modelCard` | inferred from `pkg:huggingface/` and `pkg:dataset/` purls | `ai_AIPackage`, `dataset_DatasetPackage` |
| CBOM | `cryptographic-asset` + `cryptoProperties` | not representable | not representable |
| Vulnerabilities | `vulnerabilities[]` with VEX analysis | not representable | not representable |

Where a BOM type can't exist in the source format the dashboard says so rather than
scoring a false zero — load an SPDX SBOM on its own and a note appears explaining that
cryptography coverage needs a CycloneDX CBOM.

## What's on the dashboard

- **Gauge + gate** — composite coverage and a pass/conditional/blocked verdict.
- **KPI tiles** — items in scope, licence coverage against a 95% target, undeclared
  licences, obligations attached (strong / weak / restricted), blocking findings. Two more
  appear when a CBOM is loaded: days to next certificate expiry, and quantum-safe algorithm
  ratio. The tile set adapts to what you gave it.
- **Coverage matrix** — BOM type × dimension heatmap, colour intensity scaled to coverage.
- **Per-panel radar** — the five dimensions of each BOM type at a glance, numbered to match
  the rows beneath it.
- **Licence risk distribution** — every licence expression classified as permissive, weak
  copyleft, strong copyleft, use-restricted or undeclared, as a 100% stacked bar.
- **Component mix donut** — libraries, models, datasets, crypto assets, OS packages.
- **Widest gaps to target** — every dimension across every panel, ranked by distance from
  the 90% pass threshold, with a tick marking the threshold. This is the work queue.
- **Identification funnel** — declared → versioned → resolvable (purl) → licensed →
  attributed, with the drop-off at each step. Shows where evidence is actually being lost.
- **Licence risk distribution** — every licence expression classified as permissive, weak
  copyleft, strong copyleft, use-restricted or undeclared, as a 100% stacked bar.
- **Obligations by component type** — the same classification split across libraries,
  models, datasets, OS packages, so you can see whether the risk sits in code or in weights.
- **Package ecosystems** — component counts by purl type (pypi, npm, maven, deb, apk…),
  with unresolved coordinates called out as their own bar.
- **Component mix donut** — libraries, models, datasets, crypto assets, OS packages.
- **Findings by severity** — stacked bars per BOM type.
- **Certificate expiry timeline** *(CBOM)* — every certificate placed on an 18-month
  horizon, coloured by urgency, undated ones shown on a dashed track.
- **Vulnerability posture** *(when the BOM carries CVEs)* — severity donut plus triage count.
- **Findings table** — every finding names the component and the reason.

Charts are hand-drawn SVG and CSS. No chart library, nothing to fetch. Figures that would
be empty for what you loaded are not rendered — a CBOM on its own shows no licence
distribution or ecosystem breakdown, because crypto assets carry neither.

## Scoring

Coverage per dimension = share of declared items carrying the required evidence.

| Panel | Dimensions |
|---|---|
| SBOM | purl + version · declared licences · dependency relationships · CVE triage · supplier attribution |
| AIBOM | model metadata · model licences · dataset terms or governance · library licences · provenance references |
| CBOM | algorithm primitives + parameter sets · key size and state · protocol versions · certificate validity windows · NIST quantum security level |

Thresholds: **≥ 90% pass**, **50–89% partial**, **< 50% fail**. Panel coverage is the mean of
its dimensions; composite is the mean across panels. The gate reads **blocked** on any
critical or high finding, **conditional** below 85% composite, **clear** otherwise.

## Licence risk classes

| Class | Matches |
|---|---|
| Permissive | MIT, Apache, BSD, ISC, Zlib, CC0, CC-BY-4.0, CDLA-Permissive |
| Weak copyleft | LGPL, MPL, EPL, CDDL, CC-BY-SA, ODbL |
| Strong copyleft | GPL-2/3, AGPL, SSPL, OSL, EUPL |
| Use-restricted | non-commercial, CC-BY-NC, research-only, RAIL, no-derivatives, bare `LicenseRef-` |
| Undeclared | empty, `NOASSERTION`, `NONE` |

Anything unrecognised falls to use-restricted rather than permissive, so unknown terms
surface instead of quietly passing.

## Extending it

The script is in seven labelled sections: intake and normalisation, licence classification,
classification and evaluators, analysis and KPIs, charts, render, wiring.

- **New format** — write `fromX(raw)` returning the internal model, add a signal to
  `detectFormat()`. Nothing else changes.
- **New dimension** — one `dim(label, short, done, total, wording, sub)` call. Meter, radar
  axis, matrix cell and panel average all follow.
- **New BOM type** (HBOM, SaaSBOM, QBOM) — a rule in `classify()`, an `evalXBOM()` returning
  `{key, title, kind, count, dims, findings}`, and one line in `analyse()`.
- **New KPI** — push `{k, v, d, bar?, tone?}` onto `kpis` in `analyse()`.
- **New figure** — compute its data in `analyse()`, build the markup with `hbars()`,
  `stackRows()`, `donut()`, `funnelChart()` or `certTimeline()`, and add the box to `rowA`
  or `rowB` in `render()`. Both rows auto-fit, so nothing else needs adjusting.
- **Licence rules** — the regexes in `licenceClass()`.
- **Thresholds** — the `rate()` helper.

`Export report` writes the whole analysis — sections, dimensions, coverage, KPIs, licence
mix, findings — as JSON for downstream reporting.

To rebuild after editing the samples, re-inline them into the `SAMPLES` constant at the top
of the script.
