# CBOM Comparison & Analysis Tool

Desktop utility that turns CycloneDX Cryptography Bills of Materials into
review-ready Excel workbooks. Supports CBOMs from **SCANOSS crypto-finder**
and the **internal CBOM Generator**, together or individually.

---

## Files

| File | Purpose |
|---|---|
| `cbom_analyzer.py` | The entire application (GUI + parser + Excel writer) |
| `build_exe.bat` | One-click PyInstaller build for a standalone `.exe` |
| `requirements.txt` | Runtime dependency (`openpyxl`) |

---

## Running from source

```bat
pip install -r requirements.txt
python cbom_analyzer.py
```

A headless mode is included for scripting and batch runs:

```bat
python cbom_analyzer.py --cli --scanoss scanoss.json --internal internal.json --out C:\Reports
```

Either `--scanoss` or `--internal` may be omitted.

## Building the executable

Double-click `build_exe.bat`, or run:

```bat
pip install openpyxl pyinstaller
pyinstaller --onefile --windowed --name CBOM_Analyzer cbom_analyzer.py
```

The result is `dist\CBOM_Analyzer.exe` — a single file, no Python required on
the target machine. Expect roughly 15–25 MB and a 3–8 second first launch
(the onefile bundle unpacks to `%TEMP%` on start).

> **Corporate build note:** some endpoint agents quarantine freshly built
> PyInstaller binaries because they are unsigned. If EY policy requires it, get
> the artifact code-signed, or distribute the `.py` plus `requirements.txt` and
> let users run it under an approved Python install.

---

## Outputs

| Inputs supplied | Workbooks produced |
|---|---|
| SCANOSS only | `SCANOSS_Output.xlsx` |
| Internal only | `Internal_Output.xlsx` |
| Both | `SCANOSS_Output.xlsx` **and** `Internal_Output.xlsx` |

Every workbook contains exactly three sheets:

1. `Crypto Assets`
2. `Occurrences`
3. `Asset Name - Properties`

Sheet 3 is named with a hyphen rather than a slash because Excel forbids
`/ \ ? * [ ] :` in sheet names.

---

## Field mapping

### SCANOSS — Crypto Assets

| Column | CycloneDX source |
|---|---|
| bom-ref | `component["bom-ref"]` |
| type | `component.type` |
| name | `component.name` |
| description | `component.description` |
| assetType | `cryptoProperties.assetType` |
| primitive | `cryptoProperties.algorithmProperties.primitive` |
| parameterSetIdentifier | `…algorithmProperties.parameterSetIdentifier` |
| executionEnvironment | `…algorithmProperties.executionEnvironment` |
| implementationPlatform | `…algorithmProperties.implementationPlatform` |
| cryptoFunctions | `…algorithmProperties.cryptoFunctions` (joined) |
| oid | `cryptoProperties.oid` |
| relatedCryptoMaterialType | `cryptoProperties.relatedCryptoMaterialProperties.type` |
| scanossCryptoFunction | `properties[name = "scanoss:cryptoFunction"].value` |
| Occurrence Count | `len(evidence.occurrences)` |
| Identity Evidence Count | `len(evidence.identity)` |

### Internal — Crypto Assets

Adds `Group`, `Version`, `PURL`, `Protocol Type`
(`cryptoProperties.protocolProperties.type`), `Certificate Subject`
(`cryptoProperties.certificateProperties.subjectName`) and `Property Count`
(`len(properties)`).

### Occurrences

One row per `evidence.occurrences[]` entry. The Internal sheet additionally
carries `Offset`.

### Sheet 3

* **SCANOSS** — flattened `evidence.identity[]`, one row per
  `identity[] × methods[]` pair.
* **Internal** — flattened `component.properties[]`, one row per name/value pair.

---

## Filtering rules

Any component whose `type` is `library` is dropped from **Crypto Assets**, and
its rows are then removed from **Occurrences** and **Sheet 3** by matching on
`bom-ref` *or* component name. The activity log names every component removed
this way, so the deletion is auditable rather than silent.

In the pynacl samples this removes `libsodium` from the Internal workbook
(6 components → 5 assets, 16 → 13 occurrences, 15 → 12 property rows). The
SCANOSS sample has no `library` components, so nothing is filtered there.

---

## Malformed-input handling

The supplied Internal sample is **not valid JSON** — the EdDSA `bom-ref` is
unquoted in three places:

```json
"bom-ref": crypto/algorithm/eddsa@1.3.101.112,
```

`json.load()` rejects this outright. The loader therefore retries with a
repair pass covering unquoted scalars, unquoted array elements, trailing
commas, comments, and a UTF-8 BOM. Repairs are **reported in the activity
log**, never applied silently — the underlying generator bug still needs
fixing at source.

Other defensive behaviour:

* Missing input → that workbook is simply not produced; no crash.
* Empty file, or JSON that cannot be repaired → clear error naming the line
  and column.
* A file loaded into the wrong slot → format-detection warning
  (`scanoss:` vs `cbom:` property prefixes, tool metadata).
* Output file open in Excel → explicit "close it and try again" message
  rather than a `PermissionError` traceback.
* Cells beyond Excel's 32,767-character limit are truncated with a marker.
* Nested `components[]` arrays are flattened, so sub-components are not lost.

---

## Verified against the samples

| | Crypto Assets | Occurrences | Sheet 3 |
|---|---|---|---|
| `SCANOSS_Output.xlsx` | 7 | 21 | 11 |
| `Internal_Output.xlsx` | 5 | 13 | 12 |
